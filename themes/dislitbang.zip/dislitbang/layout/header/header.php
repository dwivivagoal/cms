<header id="ekit-header">
    <div data-elementor-type="post" data-elementor-id="4390" class="elementor elementor-4390" data-elementor-settings="[]">
        <div class="elementor-inner">
            <div class="elementor-section-wrap">
                <!-- START SECTION FIRST -->
                <section data-id="52f1d1a" class="elementor-element elementor-element-52f1d1a sports-breaking-content elementor-section-boxed elementor-section-height-default elementor-section-height-default elementor-section elementor-top-section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}" data-element_type="section">
                    <div class="elementor-container elementor-column-gap-default">
                    	<div class="elementor-row">
                            <div data-id="0143d5a" class="elementor-element elementor-element-0143d5a elementor-column elementor-col-100 elementor-top-column" data-element_type="column">
                                <div class="elementor-column-wrap  elementor-element-populated">
                                    <div class="elementor-widget-wrap">
                                        <div data-id="1f0fafd" class="elementor-element elementor-element-1f0fafd elementor-hidden-tablet elementor-hidden-phone elementor-hidden-desktop elementor-widget elementor-widget-vinazine-breaking-slider-post" data-element_type="vinazine-breaking-slider-post.default">
                                            <div class="elementor-widget-container">
			      			<div class="ts-breaking-news media breaking-sliders-item">
                                                    <h2 class="breaking-title"><i class="fa fa-bolt"></i> Breaking News :</h2>
                                                    <div class="breaking-news-content owl-carousel media-body vinkmag-breaking-slider owl-loaded">
							<div class="owl-stage-outer">
                                                            <div class="owl-stage" style="transform: translate3d(0px, 0px, 0px); transition: all 0s ease 0s;">
                                                                <div class="owl-item">
                                                                    <div class="breaking-post-content">
									<p><a href="http://vinkmag.xpeedstudio.com/sports/2018/01/04/talent-crisis-gives-aaron-finch-his-test-match-chance/">Talent crisis gives Aaron Finch his Test-match</a></p>
                                                                    </div>
                                                                </div>
                                                                
                                                                <div class="owl-item">
                                                                    <div class="breaking-post-content">
									<p><a href="http://vinkmag.xpeedstudio.com/sports/2018/01/04/how-did-it-go-so-wrong-for-ferrari-in-singapore-2/">How did it go so wrong for Ferrari in Singapore?</a></p>
                                                                    </div>
                                                                </div>
                                                                <div class="owl-item">
                                                                    <div class="breaking-post-content">
									<p><a href="http://vinkmag.xpeedstudio.com/sports/2018/01/04/bernard-the-only-positive-everton-crumble-all-over-the-pitch/">Bernard the only positive, Everton crumble all over</a></p>
                                                                    </div>
                                                                </div>
                                                                <div class="owl-item">
                                                                    <div class="breaking-post-content">
									<p><a href="http://vinkmag.xpeedstudio.com/sports/2018/01/04/greenough-prison-break-reveal-caused/">Greenough Prison break reveal caused</a></p>
                                                                    </div>
                                                                </div>
                                                                <div class="owl-item">
                                                                    <div class="breaking-post-content">
									<p><a href="http://vinkmag.xpeedstudio.com/sports/2019/01/05/vontae-davis-quit-on-the-bills-at-halftime-changed-into/">Vontae Davis Quit on the Bills at Halftime, Changed into</a></p>
                                                                    </div>
                                                                </div>
                                                                <div class="owl-item">
                                                                    <div class="breaking-post-content">
									<p><a href="http://vinkmag.xpeedstudio.com/sports/2018/12/07/186/">Youth vaping an epidemic with crackdown coming</a></p>
                                                                    </div>
                                                                </div>
                                                                <div class="owl-item">
                                                                    <div class="breaking-post-content">
									<p><a href="http://vinkmag.xpeedstudio.com/sports/2018/12/07/how-did-it-go-so-wrong-for-ferrari-in-singapore/">How did it go so wrong for Ferrari in Singapore?</a></p>
                                                                    </div>
                                                                </div>
                                                                <div class="owl-item">
                                                                    <div class="breaking-post-content">
									<p><a href="http://vinkmag.xpeedstudio.com/sports/2018/12/07/the-clock-is-ticking-for-e-cig-companies-underage-users/">The clock is ticking for e-cig companies underage users</a></p>
                                                                    </div>
                                                                </div>
                                                                <div class="owl-item"><div class="breaking-post-content">
									<p><a href="http://vinkmag.xpeedstudio.com/sports/2018/08/14/backward-leg-allows-young-cancer-survivor-to-dance-4/">Backward leg allows young cancer survivor to dance</a></p>
								</div>
                                                                </div>
                                                                <div class="owl-item"><div class="breaking-post-content">
									<p><a href="http://vinkmag.xpeedstudio.com/sports/2018/07/14/tesla-just-lost-its-head-of-global-just-finance-2/">Tesla just lost its head of global just finance</a></p>
								</div>
                                                                </div>
                                                                <div class="owl-item"><div class="breaking-post-content">
									<p><a href="http://vinkmag.xpeedstudio.com/sports/2018/04/08/the-clock-is-ticking-for-e-cig-companies-underage-users-2/">Clock is companies underage ticking for e-cig  users</a></p>
								</div>
                                                                </div>
                                                                <div class="owl-item"><div class="breaking-post-content">
									<p><a href="http://vinkmag.xpeedstudio.com/sports/2018/01/14/theyre-back-kennedy-darlingnamed-to-return-to/">They’re back! Kennedy Darling,named to return to</a></p>
								</div></div>
                                                                <div class="owl-item"><div class="breaking-post-content">
									<p><a href="http://vinkmag.xpeedstudio.com/sports/2018/01/07/plans-to-ride-out-hurricane-the-florence-on-a-boat/">plans to ride out Hurricane the Florence on a boat</a></p>
								</div></div>
                                                                <div class="owl-item"><div class="breaking-post-content">
									<p><a href="http://vinkmag.xpeedstudio.com/sports/2017/01/08/theye-back-kennedy-darlings-return/">Theye back return to you Kennedy Darlings</a></p>
								</div></div>
                                                            </div>
                                                        </div>
                                                        <div class="owl-nav">
                                                            <button role="presentation" class="owl-prev"><span aria-label="prev">‹</span></button>
                                                            <button role="presentation" class="owl-next"><span aria-label="next">›</span></button>
                                                        </div>
                                                        <div class="owl-dots disabled"></div>                                                            
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
			</div>
                    </div>
		</section>
				
                                    
                <!-- START SECTION SECOND -->                                
                <section data-id="d0674be" class="elementor-element elementor-element-d0674be elementor-section-content-middle nav-transparent elementor-section-boxed elementor-section-height-default elementor-section-height-default elementor-section elementor-top-section" data-element_type="section">
                    <div class="elementor-container elementor-column-gap-default">
                        <div class="elementor-row">
                            <div data-id="67953a7" class="elementor-element elementor-element-67953a7 elementor-column elementor-col-16 elementor-top-column" data-element_type="column">

                                <div class="elementor-column-wrap  elementor-element-populated">
                                    <div class="elementor-widget-wrap">
                                        <div data-id="8c4b726" class="elementor-element elementor-element-8c4b726 elementor-widget elementor-widget-vinazine-logo" data-element_type="vinazine-logo.default">
                                            <div class="elementor-widget-container">
                                                <div class="vinkmag-widget-logo">
                                                    <a href="{SITE_URL}">
                                                        <img src="{THEMES_PAGE}/assets/images/logo/logo_dislitbangad_small.png" alt="Dislitbang TNI-AD" height="40">
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                                <div data-id="2283562" class="elementor-element elementor-element-2283562 menu-bg-white elementor-column elementor-col-66 elementor-top-column" data-element_type="column">
                                    <div class="elementor-column-wrap  elementor-element-populated">
                                        <div class="elementor-widget-wrap">
                                            <div data-id="50f2178" class="elementor-element elementor-element-50f2178 elementor-widget elementor-widget-ekit-nav-menu" data-element_type="ekit-nav-menu.default">
                                            <div class="elementor-widget-container">
                                                <!-- START MOBILE MENU -->                                                
                                                <!-- button MENU -->
                                                <div id="ekit-megamenu-main-menu" class="ekit-menu-container ekit-menu-po-left">
                                                    <ul id="main-menu" class="ekit-menu ekit-menu-simple ekit-menu-init" data-smartmenus-id="15499485175871423">
                                                        <li id="menu-item-4395" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-1515 current_page_item menu-item-4395 nav-item active"><a href="{SITE_URL}" class="ekit-menu-nav-link active">Beranda</a></li>
                                                        <li id="menu-item-4396" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-4396 nav-item"><a href="http://vinkmag.xpeedstudio.com/sports/category/cricket/" class="ekit-menu-nav-link">Profile</a></li>
                                                        <li id="menu-item-4397" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-4397 nav-item"><a href="http://vinkmag.xpeedstudio.com/sports/category/football/" class="ekit-menu-nav-link">Berita</a></li>
                                                        <li id="menu-item-3828" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-3828 nav-item"><a href="http://vinkmag.xpeedstudio.com/sports/category/sports/" class="ekit-menu-nav-link">Kegiatan</a></li>
                                                        <li id="menu-item-4398" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-4398 nav-item ekit-menu-dropdown">
                                                            <a href="http://vinkmag.xpeedstudio.com/sports/#" class="ekit-menu-nav-link ekit-menu-dropdown-toggle has-submenu" id="ekit-menu-15499485175871423-1" aria-haspopup="true" aria-controls="ekit-menu-15499485175871423-2" aria-expanded="false">Capaian<span class="sub-arrow"></span></a>
                                                            <ul class="ekit-has-submenu" id="ekit-menu-15499485175871423-2" role="group" aria-hidden="true" aria-labelledby="ekit-menu-15499485175871423-1" aria-expanded="false">
                                                                <li id="menu-item-4401" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-4401 nav-item ekit-menu-dropdown">
                                                                    <a href="http://vinkmag.xpeedstudio.com/sports/#" class="dropdown-item has-submenu" id="ekit-menu-15499485175871423-3" aria-haspopup="true" aria-controls="ekit-menu-15499485175871423-4" aria-expanded="false">Artikel<span class="sub-arrow"></span></a>
                                                                    <ul class="ekit-has-submenu" id="ekit-menu-15499485175871423-4" role="group" aria-hidden="true" aria-labelledby="ekit-menu-15499485175871423-3" aria-expanded="false">
                                                                        <li id="menu-item-4405" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-4405 nav-item"><a href="http://vinkmag.xpeedstudio.com/sports/category/cricket/" class=" dropdown-item">Category Style 1</a></li>
                                                                        <li id="menu-item-4406" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-4406 nav-item"><a href="http://vinkmag.xpeedstudio.com/sports/category/sketing/" class=" dropdown-item">Category Style 2</a></li>
                                                                    </ul>
                                                                </li>
                                                                <li id="menu-item-4402" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-4402 nav-item ekit-menu-dropdown"><a href="http://vinkmag.xpeedstudio.com/sports/#" class="dropdown-item has-submenu" id="ekit-menu-15499485175871423-5" aria-haspopup="true" aria-controls="ekit-menu-15499485175871423-6" aria-expanded="false">Post Formats<span class="sub-arrow"></span></a>
                                                                    <ul class="ekit-has-submenu" id="ekit-menu-15499485175871423-6" role="group" aria-hidden="true" aria-labelledby="ekit-menu-15499485175871423-5" aria-expanded="false">
                                                                        <li id="menu-item-4403" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-4403 nav-item"><a href="http://vinkmag.xpeedstudio.com/sports/2019/01/11/martavis-bryant-is-way-higher-on-jon-gruden-than-gruden-is-on-bryant/" class=" dropdown-item">Post Style 1</a></li>
                                                                        <li id="menu-item-4404" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-4404 nav-item"><a href="http://vinkmag.xpeedstudio.com/sports/2019/01/05/vontae-davis-quit-on-the-bills-at-halftime-changed-into/" class=" dropdown-item">Pot Style 2</a>	</li>
                                                                    </ul>
                                                                </li>
                                                                <li id="menu-item-4407" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-4407 nav-item ekit-menu-dropdown"><a href="http://vinkmag.xpeedstudio.com/sports/#" class="dropdown-item has-submenu" id="ekit-menu-15499485175871423-7" aria-haspopup="true" aria-controls="ekit-menu-15499485175871423-8" aria-expanded="false">Pages<span class="sub-arrow"></span></a>
                                                                    <ul class="ekit-has-submenu" id="ekit-menu-15499485175871423-8" role="group" aria-hidden="true" aria-labelledby="ekit-menu-15499485175871423-7" aria-expanded="false">
                                                                        <li id="menu-item-4408" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-4408 nav-item"><a href="http://vinkmag.xpeedstudio.com/sports/author/vinkmag/" class=" dropdown-item">Author</a></li>
                                                                        <li id="menu-item-4409" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-4409 nav-item"><a href="http://vinkmag.xpeedstudio.com/sports/pagenotfound" class=" dropdown-item">404</a>	</li>
                                                                    </ul>
                                                                </li>
                                                            </ul>
                                                        </li>
                                                    </ul>
                                                    <div class="nav-identity-panel">
                                                        <button class="menu-close" type="button">X</button>
                                                    </div>
                                                </div>
                                                <div class="ekit-menu-overlay"></div>		
                                            </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div data-id="01073e8" class="elementor-element elementor-element-01073e8 elementor-column elementor-col-16 elementor-top-column" data-element_type="column">
                                    <div class="elementor-column-wrap  elementor-element-populated">
                                        <div class="elementor-widget-wrap">

                                            <div data-id="8945c4f" class="elementor-element elementor-element-8945c4f elementor-hidden-tablet elementor-hidden-phone elementor-widget elementor-widget-vinazine-nav-search" data-element_type="vinazine-nav-search.default">
                                                <div class="elementor-widget-container">

                                                    <div class="header-search-icon">
                                                        <a href="http://vinkmag.xpeedstudio.com/sports/#modal-popup-2" class="navsearch-button nav-search-button xs-modal-popup"><i class="icon icon-search"></i></a>
                                                    </div>
                                                    <!-- xs modal -->
                                                    <div class="zoom-anim-dialog mfp-hide modal-searchPanel ts-search-form" id="modal-popup-2">
                                                        <div class="modal-dialog modal-lg">
                                                            <div class="modal-content">
                                                                <div class="xs-search-panel">

                                                                    <form method="get" action="http://vinkmag.xpeedstudio.com/sports/" class="vinkmag-serach">
                                                                            <div class="input-group">
                                                                                    <input class="form-control text-center" type="search" name="s" placeholder="Type and hit ENTER" value="">
                                                                                    <div class="input-group-append">
                                                                                            <span class="nav-search-close-button header-search-btn-toggle d-none" tabindex="0">✕</span>
                                                                                    </div>
                                                                            </div>
                                                                    </form>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!-- End xs modal --><!-- end language switcher strart -->
                                                </div>
                                            </div>
                                        </div>
                                        
                                    </div>
                                </div>
                        </div>
                    </div>
                </section>
                
            </div>
        </div>
    </div>
</header>