<section data-id="67355ce" class="elementor-element elementor-element-67355ce elementor-section-boxed elementor-section-height-default elementor-section-height-default elementor-section elementor-top-section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}" data-element_type="section">
    <div class="elementor-container elementor-column-gap-default">
        <div class="elementor-row">
            
            {POPULAR_IMAGE_LIST}
            <div data-id="bfeff20" class="elementor-element elementor-element-bfeff20 elementor-column elementor-col-25 elementor-top-column" data-element_type="column">
                <div class="elementor-column-wrap  elementor-element-populated">
                    <div class="elementor-widget-wrap">
                        <div data-id="113a319" class="elementor-element elementor-element-113a319 elementor-widget elementor-widget-vinazine-post-grid" data-element_type="vinazine-post-grid.default">
                            <div class="elementor-widget-container">
			        
                                <div class="grid-item grid-sm ">
                                    <div class="ts-overlay-style featured-post post-184 post type-post status-publish format-standard has-post-thumbnail hentry category-cricket category-football category-sketing category-sports">
                                        <div class="item item-before" style="background-image:url({image})">
                                           <div class="gradient-overlay"></div>
                                           <a class="img-link" href="{link}"></a>
                                           <div class="ts-post-thumb">
                                                    </div>
                                           <div class="overlay-post-content">
                                              <div class="post-content">
                                                 <h3 class="post-title">
                                                    <a href="{link}">
                                                    {title}</a>
                                                 </h3>
                                                 <ul class="post-meta-info">
                                                                                  <li>
                                                       <i class="fa fa-clock-o"></i>{publish_date} </li>

                                                                </ul>
                                              </div>
                                           </div>
                                        </div>
                                    </div>
                                </div>
                                
                            </div>
			</div>
                    </div>
		</div>
            </div>
            {/POPULAR_IMAGE_LIST}
            
	</div>
    </div>
</section>