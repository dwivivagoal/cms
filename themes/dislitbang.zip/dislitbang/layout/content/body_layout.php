                    <div data-elementor-type="post" data-elementor-id="1515" class="elementor elementor-1515" data-elementor-settings="[]">
			<div class="elementor-inner">
				<div class="elementor-section-wrap">
                                    
                                    {SLIDER_SECTION}
                                    
                                    
                                </div>
                        </div>
                    </div>    
		