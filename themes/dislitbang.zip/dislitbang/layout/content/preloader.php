        <div id="preloader" class="hidden loaded">
		<div class="spinner">
			<div class="double-bounce1"></div>
			<div class="double-bounce2"></div>
		</div>
		<div class="preloader-cancel-btn-wraper">
			<a href="{SITE_URL}" class="btn btn-primary preloader-cancel-btn">
				Cancel Preloader			
                        </a>
		</div>
	</div>