<footer id="ekit-footer">
    <div class="footer-width-fixer">		
        <div data-elementor-type="post" data-elementor-id="4128" class="elementor elementor-4128" data-elementor-settings="[]">
            <div class="elementor-inner">
                <div class="elementor-section-wrap">
            
                    <section data-id="a77fae8" class="elementor-element elementor-element-a77fae8 custom-footer-menu elementor-section-boxed elementor-section-height-default elementor-section-height-default elementor-section elementor-top-section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}" data-element_type="section">
                        <div class="elementor-container elementor-column-gap-default">
                            <div class="elementor-row">
                                <div data-id="a847e29" class="elementor-element elementor-element-a847e29 elementor-column elementor-col-33 elementor-top-column" data-element_type="column">
                                    <div class="elementor-column-wrap  elementor-element-populated">

                                        <div class="elementor-widget-wrap">
                                            <div data-id="75c0cd6" class="elementor-element elementor-element-75c0cd6 footer-menu xs-center elementor-widget elementor-widget-wp-widget-nav_menu" data-element_type="wp-widget-nav_menu.default">
                                                <div class="elementor-widget-container">
                                                    <div class="menu-footer-left-menu-container">
                                                        <ul id="menu-footer-left-menu" class="menu">
                                                            <li id="menu-item-4381" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-1515 current_page_item menu-item-4381"><a href="{SITE_URL}">Beranda</a></li>
                                                            <li id="menu-item-4382" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-4382"><a href="#">Profile</a></li>
                                                            <li id="menu-item-4383" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-4383"><a href="#">Berita</a></li>
                                                        </ul>
                                                    </div>		
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div data-id="3902c0d" class="elementor-element elementor-element-3902c0d elementor-column elementor-col-33 elementor-top-column" data-element_type="column">
                                    <div class="elementor-column-wrap  elementor-element-populated">
                                        <div class="elementor-widget-wrap">
                                            <div data-id="eaa65e6" class="elementor-element elementor-element-eaa65e6 elementor-widget elementor-widget-vinazine-logo" data-element_type="vinazine-logo.default">
                                                <div class="elementor-widget-container">
                                                    <div class="vinkmag-widget-logo">
                                                        <a href="{SITE_URL}">
                                                            <img src="{THEMES_PAGE}/assets/images/logo/logo_dislitbangad_small.png" alt="Sports">
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div data-id="f2698d0" class="elementor-element elementor-element-f2698d0 elementor-column elementor-col-33 elementor-top-column" data-element_type="column">
                                <div class="elementor-column-wrap  elementor-element-populated">
                                    <div class="elementor-widget-wrap">
                                        <div data-id="abb41e3" class="elementor-element elementor-element-abb41e3 footer-menu text-right xs-center elementor-widget elementor-widget-wp-widget-nav_menu" data-element_type="wp-widget-nav_menu.default">
                                            <div class="elementor-widget-container">
                                                <div class="menu-footer-right-menu-container">
                                                    <ul id="menu-footer-right-menu" class="menu">
                                                        <li id="menu-item-4385" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-4385"><a href="#">Artikel</a></li>
                                                        <li id="menu-item-4386" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-4386"><a href="#">Galeri</a></li>
                                                        <li id="menu-item-4387" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-4387"><a href="#">Video</a></li>
                                                    </ul>
                                                </div>		
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                </div>
                            </div>
                        </div>
                    </section>
                                        
                    <section data-id="f15e381" class="elementor-element elementor-element-f15e381 elementor-section-boxed elementor-section-height-default elementor-section-height-default elementor-section elementor-top-section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}" data-element_type="section">
                                                        <div class="elementor-container elementor-column-gap-default">
                                        <div class="elementor-row">
                                        <div data-id="3a37ac0" class="elementor-element elementor-element-3a37ac0 elementor-column elementor-col-33 elementor-top-column" data-element_type="column">
                                <div class="elementor-column-wrap  elementor-element-populated">
                                                <div class="elementor-widget-wrap">
                                        <div data-id="5a5f4e5" class="elementor-element elementor-element-5a5f4e5 xs-center elementor-widget elementor-widget-text-editor" data-element_type="text-editor.default">
                                        <div class="elementor-widget-container">
                                                <div class="elementor-text-editor elementor-clearfix"><p>© Dislitbang TNI-AD, 2019</p></div>
                                        </div>
                                        </div>
                                                        </div>
                                </div>
                        </div>

                        <div data-id="2dc6ff7" class="elementor-element elementor-element-2dc6ff7 elementor-column elementor-col-33 elementor-top-column" data-element_type="column">
                                <div class="elementor-column-wrap  elementor-element-populated">
                                                <div class="elementor-widget-wrap">
                                        <div data-id="27d232a" class="elementor-element elementor-element-27d232a elementor-shape-rounded elementor-widget elementor-widget-social-icons" data-element_type="social-icons.default">
                                        <div class="elementor-widget-container">
                                                <div class="elementor-social-icons-wrapper">
                                                                <a class="elementor-icon elementor-social-icon elementor-social-icon-facebook" href="#" target="_blank">
                                                <span class="elementor-screen-only">Facebook</span>
                                                <i class="fa fa-facebook"></i>
                                        </a>
                                                                <a class="elementor-icon elementor-social-icon elementor-social-icon-twitter" href="#" target="_blank">
                                                <span class="elementor-screen-only">Twitter</span>
                                                <i class="fa fa-twitter"></i>
                                        </a>
                                                                <a class="elementor-icon elementor-social-icon elementor-social-icon-google-plus" href="#" target="_blank">
                                                <span class="elementor-screen-only">Google-plus</span>
                                                <i class="fa fa-google-plus"></i>
                                        </a>
                                                                <a class="elementor-icon elementor-social-icon elementor-social-icon-youtube" href="#" target="_blank">
                                                <span class="elementor-screen-only">Youtube</span>
                                                <i class="fa fa-youtube"></i>
                                        </a>
                                                                <a class="elementor-icon elementor-social-icon elementor-social-icon-tumblr" href="#" target="_blank">
                                                <span class="elementor-screen-only">Tumblr</span>
                                                <i class="fa fa-tumblr"></i>
                                        </a>
                                                                <a class="elementor-icon elementor-social-icon elementor-social-icon-instagram" href="#" target="_blank">
                                                <span class="elementor-screen-only">Instagram</span>
                                                <i class="fa fa-instagram"></i>
                                        </a>
                                                </div>
                                        </div>
                                        </div>
                                    </div>
                                </div>
                        </div>

                        <div data-id="c802d28" class="elementor-element elementor-element-c802d28 elementor-column elementor-col-33 elementor-top-column" data-element_type="column">
                                <div class="elementor-column-wrap  elementor-element-populated">
                                    <div class="elementor-widget-wrap">
                                        <div data-id="04887d6" class="elementor-element elementor-element-04887d6 footer-menu text-right xs-center elementor-widget elementor-widget-wp-widget-nav_menu" data-element_type="wp-widget-nav_menu.default">
                                            <div class="elementor-widget-container">
                                                <div class="menu-footer-menu-container">
                                                    <ul id="menu-footer-menu" class="menu">
                                                        <li id="menu-item-4388" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-4388"><a href="#">Visi Misi</a></li>
                                                        <li id="menu-item-4424" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-4424"><a href="#">Sejarah</a></li>
                                                        <li id="menu-item-4425" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-4425"><a href="#">Profile</a></li>
                                                    </ul>
                                                </div>		
                                            </div>
                                        </div>
                                    </div>
                                </div>
                        </div>

                        </div>
                        </div>
                        </section>
		</div>
            </div>
        </div>
    </div>		
</footer>