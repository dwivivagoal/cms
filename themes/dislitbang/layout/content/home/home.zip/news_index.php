<section data-id="9f5b354" class="elementor-element elementor-element-9f5b354 elementor-section-boxed elementor-section-height-default elementor-section-height-default elementor-section elementor-top-section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}" data-element_type="section">
    <div class="elementor-container elementor-column-gap-default">
        <div class="elementor-row">
		<div data-id="5d7b65f" class="elementor-element elementor-element-5d7b65f elementor-column elementor-col-100 elementor-top-column" data-element_type="column">
			<div class="elementor-column-wrap  elementor-element-populated">
                            <div class="elementor-widget-wrap">
				<div data-id="aa37d6d" class="elementor-element elementor-element-aa37d6d elementor-hidden-tablet elementor-hidden-phone elementor-widget elementor-widget-image" data-element_type="image.default">
				<div class="elementor-widget-container">
					<div class="elementor-image">
                                        <img width="970" height="90" src="{THEMES_PAGE}/assets/images/redad.png" class="attachment-full size-full" alt="" srcset="http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/12/redad.png 970w, http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/12/redad-300x28.png 300w, http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/12/redad-768x71.png 768w" sizes="(max-width: 970px) 100vw, 970px">											</div>
				</div>
				</div>
                            </div>
			</div>
		</div>
        </div>
    </div>
</section>



<section data-id="602a3a1" class="elementor-element elementor-element-602a3a1 elementor-section-boxed elementor-section-height-default elementor-section-height-default elementor-section elementor-top-section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}" data-element_type="section">
    <div class="elementor-container elementor-column-gap-default">
        <div class="elementor-row">
            
            <div data-id="63b26e0" class="elementor-element elementor-element-63b26e0 elementor-column elementor-col-33 elementor-top-column" data-element_type="column">
                <div class="elementor-column-wrap  elementor-element-populated">
                    <div class="elementor-widget-wrap">
                        <div data-id="98546b4" class="elementor-element elementor-element-98546b4 elementor-widget elementor-widget-vinazine-post-list" data-element_type="vinazine-post-list.default">
                            <div class="elementor-widget-container">
			        
                                <div class="widgets ts-grid-box widgets-populer-post  grid-no-shadow">
                                    
                                    {LATEST_HEADLINE_BYCAT_LIST1}
                                    <div class="item grid-md ">
                                            <div class="ts-overlay-style post-190 post type-post status-publish format-standard has-post-thumbnail hentry category-cricket category-sketing category-sports tag-sports">
                                                <div class="item">
                                                <div class="ts-post-thumb">

                                                                                                <a class="post-cat" href="{link_cat}" style="color:#ffffff; background-color:#d72924; border-left-color:#d72924">
                                                                        {kategori}	</a>
                                                                                <a href="{link}">
                                                                        <img width="850" height="560" src="{image}" class="attachment-full size-full wp-post-image" alt="" srcset="{image} 850w, {image} 300w, {image} 768w" sizes="(max-width: 850px) 100vw, 850px">         </a>

                                                </div>

                                                <div class="overlay-post-content">
                                                        <div class="post-content">
                                                                <h3 class="post-title">
                                                                        <a href="{link}">{title}</a>
                                                                </h3>
                                                                <ul class="post-meta-info">
                                                                                                                                                        <li>
                                                                                <i class="fa fa-clock-o"></i>{publish_date}</li>


                                                                </ul>
                                                        </div>
                                                </div>
                                            </div>
                                        </div>                                        
                                    </div>
                                    {/LATEST_HEADLINE_BYCAT_LIST1}    
                                                
                                    {LATEST_BYCAT_LIST1}                                                
                                    <div class="post-content media">
                                            <a href="{link}">
                                                <img class="d-flex sidebar-img" src="{image}" alt="{title}">
                                            </a>
                                            
                                            <div class="media-body ">
                                                <h4 class="post-title">
                                                    <a href="{link}">  {title}</a>
                                                </h4>
                                                
                                                <span class="post-date-info">
                                                      <i class="fa fa-clock-o"></i>
                                                      {publish_date}</span>
                                                                                            
                                            </div>
                                    </div>
                                    {/LATEST_BYCAT_LIST1}
                                    
                                    
                            </div>
                        </div>
                    </div>		
                </div>
            </div>
        </div>
        
	
        
        <div data-id="6f63593" class="elementor-element elementor-element-6f63593 elementor-column elementor-col-33 elementor-top-column" data-element_type="column">
			<div class="elementor-column-wrap  elementor-element-populated">
                            <div class="elementor-widget-wrap">
				<div data-id="ba60484" class="elementor-element elementor-element-ba60484 elementor-widget elementor-widget-vinazine-post-list" data-element_type="vinazine-post-list.default">
                                    <div class="elementor-widget-container">
			        
                                        <div class="widgets ts-grid-box widgets-populer-post  grid-no-shadow">
                                                
                                                {LATEST_HEADLINE_BYCAT_LIST2}    
                                                <div class="item grid-md ">
                                                    <div class="ts-overlay-style post-184 post type-post status-publish format-standard has-post-thumbnail hentry category-cricket category-football category-sketing category-sports">
                                                        <div class="item">
                                                                <div class="ts-post-thumb">
                                                                    <a class="post-cat" href="{link_cat}" style="color:#ffffff; background-color:#d72924; border-left-color:#d72924">
                                                                                        {kategori}		</a>
                                                                    <a href="{link}">
                                                                    <img width="850" height="560" src="{image}" class="attachment-full size-full wp-post-image" alt="" srcset="{image} 850w, {image} 300w, {image} 768w" sizes="(max-width: 850px) 100vw, 850px">         </a>

                                                                </div>
                                                                <div class="overlay-post-content">
                                                                        <div class="post-content">
                                                                                <h3 class="post-title">
                                                                                        <a href="{link}">{title}</a>
                                                                                </h3>
                                                                                <ul class="post-meta-info">
                                                                                        <li>
                                                                                        <i class="fa fa-clock-o"></i>{publish_date}</li>


                                                                                </ul>
                                                                        </div>
                                                                </div>
                                                        </div>

                                                    </div>                                        
                                                </div>
                                                {/LATEST_HEADLINE_BYCAT_LIST2}    
                                                
                                                {LATEST_BYCAT_LIST2}
                                                <div class="post-content media">
                                                    <a href="{link}">
                                                        <img class="d-flex sidebar-img" src="{image}" alt="{title}">
                                                    </a>

                                                    <div class="media-body ">
                                                        <h4 class="post-title">
                                                            <a href="{link}">  {title}</a>

                                                        </h4>
                                                                                                           <span class="post-date-info">
                                                              <i class="fa fa-clock-o"></i>
                                                              {publish_date}                                            </span>

                                                    </div>
                                                </div>
                                                {/LATEST_BYCAT_LIST2}
                                                        
                                                                                                
                                    </div>
                                </div>
                            </div>
			</div>
		</div>
            </div>
				
            
            <div data-id="9f8def4" class="elementor-element elementor-element-9f8def4 elementor-column elementor-col-33 elementor-top-column" data-element_type="column">
                <div class="elementor-column-wrap  elementor-element-populated">
                    <div class="elementor-widget-wrap">
                        <div data-id="0f80ab2" class="elementor-element elementor-element-0f80ab2 elementor-widget elementor-widget-vinazine-post-list" data-element_type="vinazine-post-list.default">
                            <div class="elementor-widget-container">
			        
                                <div class="widgets ts-grid-box widgets-populer-post  grid-no-shadow">
                                    
                                    <h2 class="ts-title block-title-style1 float-left">
                                    <span class="title-before"></span>
                                    Berita Terbaru</h2>
                                    <div class="clearfix"></div>
  
                                    {LATEST_HEADLINE_LIST}
                                    <div class="item grid-sm ">
                                        <div class="ts-overlay-style post-186 post type-post status-publish format-standard has-post-thumbnail hentry category-cricket category-sketing category-sports category-surfing tag-sports">
                                            <div class="item">
                                                <div class="ts-post-thumb">
                                                    <a class="post-cat" href="{link_cat}" style="color:#ffffff; background-color:#d72924; border-left-color:#d72924">
                                                    {kategori}</a>
                                                    <a href="{link}">
                                                    <img width="850" height="560" src="{image}" class="attachment-full size-full wp-post-image" alt="" srcset="{image} 850w, {image} 300w, {image} 768w" sizes="(max-width: 850px) 100vw, 850px"></a>

                                                </div>
                                                <div class="overlay-post-content">
                                                    <div class="post-content">
                                                        <h3 class="post-title">
                                                            <a href="{link}">{title}</a>
                                                        </h3>
                                                        <ul class="post-meta-info">
                                                            <li>
                                                                <i class="fa fa-clock-o"></i>{publish_date}</li>


                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>                                        
                                    </div>  
                                    {/LATEST_HEADLINE_LIST}
                                    
                                    {LATEST_LIST}
                                    <div class="post-content media">
                                                <a href="{link}">
                                                    <img class="d-flex sidebar-img" src="{image}" alt="{title}">
                                                </a>

                                                <div class="media-body ">
                                                    <h4 class="post-title">
                                                        <a href="{title}">  {title}...</a>
                                                    </h4>
                                                    <span class="post-date-info">
                                                          <i class="fa fa-clock-o"></i>
                                                          {publish_date}</span>
                                                </div>
                                    </div>
                                    {/LATEST_LIST}                                                                                                  

                                
                                                                                                
                                </div>
                            </div>
			</div>
                    </div>
		</div>
            </div>
	</div>
    </div>
</section>