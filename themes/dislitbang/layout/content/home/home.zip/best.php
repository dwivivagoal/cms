
<section data-id="5ac5bc4" class="elementor-element elementor-element-5ac5bc4 elementor-section-boxed elementor-section-height-default elementor-section-height-default elementor-section elementor-top-section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}" data-element_type="section">
    <div class="elementor-container elementor-column-gap-default">
        <div class="elementor-row">
            <div data-id="05b13e5" class="elementor-element elementor-element-05b13e5 elementor-column elementor-col-100 elementor-top-column" data-element_type="column">
                <div class="elementor-column-wrap  elementor-element-populated">
                    <div class="elementor-widget-wrap">
                        <div data-id="f8d7cd0" class="elementor-element elementor-element-f8d7cd0 elementor-widget elementor-widget-vinazine-video-post-tab" data-element_type="vinazine-video-post-tab.default">
				<div class="elementor-widget-container">
			        
                    <div class="row">
                        <div class="col-lg-8 pr-0">
                            <div class="tab-content clearfix">

                                    <div class="tab-pane fade in active" id="video-tab-f8d7cd0-1">
                                        <div class="video-item" style="background-image: url(http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/gallery3-600x398.jpg)">
                                            <div class="post-video">
                                                <a href="https://youtu.be/6_P8RUqGQbM" class="ts-play-btn">
                                                        <i class="fa fa-play" aria-hidden="true"></i>
                                                </a>
                                            </div>                                
                                        </div>
                                    </div>

                                    <div class="tab-pane fade " id="video-tab-f8d7cd0-2">
                                        <div class="video-item" style="background-image: url(http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/health1-600x398.jpg)">
                                            <div class="post-video">
                                                    <a href="https://www.youtube.com/watch?v=UuXUfx2Mtvs" class="ts-play-btn">
                                                        <i class="fa fa-play" aria-hidden="true"></i>
                                                    </a>
                                            </div>                                
                                        </div>
                                    </div>

                                    <div class="tab-pane fade " id="video-tab-f8d7cd0-3">
                                        <div class="video-item" style="background-image: url(http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/music1-600x398.jpg)">
                                            <div class="post-video">
                                                    <a href="https://www.youtube.com/watch?v=UuXUfx2Mtvs" class="ts-play-btn">
                                                            <i class="fa fa-play" aria-hidden="true"></i>
                                                    </a>
                                            </div>                                
                                        </div>
                                    </div>

                                    <div class="tab-pane fade " id="video-tab-f8d7cd0-4">
                                        <div class="video-item" style="background-image: url(http://vinkmag.xpeedstudio.com/sports/wp-content/themes/vinazine/assets/images/default_thumb.jpg)">
                                            <div class="post-video">
                                                    <a href="https://www.youtube.com/watch?v=vlDzYIIOYmM" class="ts-play-btn">
                                                            <i class="fa fa-play" aria-hidden="true"></i>
                                                    </a>
                                            </div>                                
                                        </div>
                                    </div>

                                    <div class="tab-pane fade " id="video-tab-f8d7cd0-5">
                                        <div class="video-item" style="background-image: url(http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/health9-600x398.jpg)">
                                            <div class="post-video">
                                                <a href="https://youtu.be/6_P8RUqGQbM" class="ts-play-btn">
                                                        <i class="fa fa-play" aria-hidden="true"></i>
                                                </a>
                                            </div>                                
                                        </div>
                                    </div>

                                    <div class="tab-pane fade " id="video-tab-f8d7cd0-6">
                                        <div class="video-item" style="background-image: url(http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/health7-600x398.jpg)">
                                            <div class="post-video">
                                                    <a href="https://youtu.be/tO01J-M3g0U" class="ts-play-btn">
                                                            <i class="fa fa-play" aria-hidden="true"></i>
                                                    </a>
                                            </div>                                
                                        </div>
                                    </div>

                            </div>
                        </div>
                
                <div class="col-lg-4 pl-0">
                    <div class="video-tab-list bg-dark-item video-tab-scrollbar mCustomScrollbar _mCS_1" id="video-tab-scrollbar"><div id="mCSB_1" class="mCustomScrollBox mCS-light mCSB_vertical mCSB_inside" style="max-height: none;" tabindex="0"><div id="mCSB_1_container" class="mCSB_container" style="position:relative; top:0; left:0;" dir="ltr">
                        <ul class="nav nav-pills post-tab-list">
                                                    <li class="active">
                                <a href="http://vinkmag.xpeedstudio.com/sports/#video-tab-f8d7cd0-1" data-toggle="tab">
                                    <div class="post-content media">
                                        <img class="d-flex sidebar-img mCS_img_loaded" src="{THEMES_PAGE}/assets/images/gallery3-455x300.jpg" alt="Martavis Bryant Is Way Higher on Jon Gruden Than Gruden Is on Bryant">
                                        <div class="media-body align-self-center">
                                            <h4 class="post-title">
                                                Martavis Bryant Is Way Higher on Jon Gruden Than Gruden Is on Bryant                                            </h4>
                                        </div>
                                    </div>
                                </a>
                            </li>
                                                    <li class="">
                                <a href="http://vinkmag.xpeedstudio.com/sports/#video-tab-f8d7cd0-2" data-toggle="tab">
                                    <div class="post-content media">
                                        <img class="d-flex sidebar-img mCS_img_loaded" src="{THEMES_PAGE}/assets/images/health1-455x300.jpg" alt="Backward leg allows young cancer survivor to dance">
                                        <div class="media-body align-self-center">
                                            <h4 class="post-title">
                                                Backward leg allows young cancer survivor to dance                                            </h4>
                                        </div>
                                    </div>
                                </a>
                            </li>
                                                    <li class="">
                                <a href="http://vinkmag.xpeedstudio.com/sports/#video-tab-f8d7cd0-3" data-toggle="tab">
                                    <div class="post-content media">
                                        <img class="d-flex sidebar-img mCS_img_loaded" src="{THEMES_PAGE}/assets/images/music1-455x300.jpg" alt="Tesla just lost its head of global just finance">
                                        <div class="media-body align-self-center">
                                            <h4 class="post-title">
                                                Tesla just lost its head of global just finance                                            </h4>
                                        </div>
                                    </div>
                                </a>
                            </li>
                                                    <li class="">
                                <a href="http://vinkmag.xpeedstudio.com/sports/#video-tab-f8d7cd0-4" data-toggle="tab">
                                    <div class="post-content media">
                                        <img class="d-flex sidebar-img mCS_img_loaded" src="{THEMES_PAGE}/assets/images/default_thumb.jpg" alt="They’re back! Kennedy Darling,named to return to">
                                        <div class="media-body align-self-center">
                                            <h4 class="post-title">
                                                They’re back! Kennedy Darling,named to return to                                            </h4>
                                        </div>
                                    </div>
                                </a>
                            </li>
                                                    <li class="">
                                <a href="http://vinkmag.xpeedstudio.com/sports/#video-tab-f8d7cd0-5" data-toggle="tab">
                                    <div class="post-content media">
                                        <img class="d-flex sidebar-img mCS_img_loaded" src="{THEMES_PAGE}/assets/images/health9-455x300.jpg" alt="Plans to ride out Hurricane the Florence on a boat">
                                        <div class="media-body align-self-center">
                                            <h4 class="post-title">
                                                Plans to ride out Hurricane the Florence on a boat                                            </h4>
                                        </div>
                                    </div>
                                </a>
                            </li>
                                                    <li class="">
                                <a href="http://vinkmag.xpeedstudio.com/sports/#video-tab-f8d7cd0-6" data-toggle="tab">
                                    <div class="post-content media">
                                        <img class="d-flex sidebar-img mCS_img_loaded" src="{THEMES_PAGE}/assets/images/health7-455x300.jpg" alt="Theye back return to you Kennedy Darlings">
                                        <div class="media-body align-self-center">
                                            <h4 class="post-title">
                                                Theye back return to you Kennedy Darlings                                            </h4>
                                        </div>
                                    </div>
                                </a>
                            </li>
                                                </ul>
                    </div><div id="mCSB_1_scrollbar_vertical" class="mCSB_scrollTools mCSB_1_scrollbar mCS-light mCSB_scrollTools_vertical" style="display: block;"><a href="http://vinkmag.xpeedstudio.com/sports/#" class="mCSB_buttonUp" oncontextmenu="return false;" style="display: block;"></a><div class="mCSB_draggerContainer"><div id="mCSB_1_dragger_vertical" class="mCSB_dragger" style="position: absolute; min-height: 30px; display: block; height: 255px; max-height: 340px; top: 0px;" oncontextmenu="return false;"><div class="mCSB_dragger_bar" style="line-height: 30px;"></div></div><div class="mCSB_draggerRail"></div></div><a href="http://vinkmag.xpeedstudio.com/sports/#" class="mCSB_buttonDown" oncontextmenu="return false;" style="display: block;"></a></div></div></div>
                </div>
            </div>
        
      		</div>
				</div>
						</div>
			</div>
		</div>
						</div>
			</div>
		</section>