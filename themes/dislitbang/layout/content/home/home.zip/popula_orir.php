<section data-id="127c2e4" class="elementor-element elementor-element-127c2e4 elementor-section-boxed elementor-section-height-default elementor-section-height-default elementor-section elementor-top-section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}" data-element_type="section">
    <div class="elementor-container elementor-column-gap-default">
        
        <div class="elementor-row">
            
            <div data-id="95a744d" class="elementor-element elementor-element-95a744d elementor-column elementor-col-66 elementor-top-column" data-element_type="column">
                <div class="elementor-column-wrap  elementor-element-populated">
                    <div class="elementor-widget-wrap">
                        
                        <div data-id="2717f7c" class="elementor-element elementor-element-2717f7c elementor-widget elementor-widget-vinazine-post-tab-2" data-element_type="vinazine-post-tab-2.default">
                            <div class="elementor-widget-container">
			        
                                <div class="ts-grid-box tabs-item mb-30 bg-dark-item white-text ">
                                    <div class="clearfix ts-tab-style">

                                        <h2 class="ts-title block-title-style1 float-left">
                                        <span class="title-before"></span>
                                        Most  Read</h2>

                                        <ul class="tab-menu-item nav float-right" role="tablist" id="vinkmagposttab22717f7cTab">
                                                {KATEGORI_LIST}
                                                <li class="nav-item">
                                                    <a class="nav-link" href="#tab-{alias}" role="tab" data-toggle="tab">{title}</a>
                                                </li>
                                                {/KATEGORI_LIST}

                                                
                                        </ul>
                                    </div>
                                    <div class="tab-content ts-tabs-content" id="vinkmagposttab22717f7cTabContent">
                                        {KATEGORI_LIST_CONTENT}
                                        <div role="tabpanel" class="tab-pane fade" id="tab-{alias}">
                                            <div class="row">
                                            {title}
                                            </div>
                                        </div>
                                        
                                        {/KATEGORI_LIST_CONTENT}
                                        

                                        <div role="tabpanel" class="tab-pane fade show active" id="tab-2717f7c1">
                                            <div class="row">

                                                <div class="col-lg-7">
                                                    <div class="tab-content featured-post"  >

                                                        <div class="tab-pane ts-overlay-style fade show active" id="nav-post-tab-2717f7c-11" role="tabpanel" aria-labelledby="nav-2717f7c-11-tab">
                                                            <div class="ts-overlay-style featured-post post-172 post type-post status-publish format-video has-post-thumbnail hentry category-video post_format-post-format-video">
                                                                <div class="item" style="background-image:url(http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/health7-600x398.jpg)">
                                                                   <a class="img-link" href="http://vinkmag.xpeedstudio.com/sports/2017/01/08/theye-back-kennedy-darlings-return/"></a>
                                                                   <div class="overlay-post-content">
                                                                      <div class="post-content">

                                                                         <h3 class="post-title">
                                                                            <a href="http://vinkmag.xpeedstudio.com/sports/2017/01/08/theye-back-kennedy-darlings-return/">
                                                                            Theye back return to you Kennedy Darlings            </a>
                                                                         </h3>
                                                                         <ul class="post-meta-info">
                                                                                                    <li>
                                                                               <i class="fa fa-clock-o"></i>January 8, 2017            </li>

                                                                                           <li class="active">
                                                                                  <i class="icon-fire"></i>
                                                                                  96               </li>

                                                                         </ul>
                                                                      </div>
                                                                   </div>
                                                                </div>
                                                            </div>					
                                                        </div>

                                                        <div class="tab-pane ts-overlay-style fade " id="nav-post-tab-2717f7c-21" role="tabpanel" aria-labelledby="nav-2717f7c-21-tab">
                                                            <div class="ts-overlay-style featured-post post-4374 post type-post status-publish format-video has-post-thumbnail hentry category-video post_format-post-format-video">
                                                                <div class="item" style="background-image:url(http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/health9-600x398.jpg)">
                                                                   <a class="img-link" href="http://vinkmag.xpeedstudio.com/sports/2018/01/11/plans-to-ride-out-hurricane-the-florence-on-a-boat-2/"></a>
                                                                   <div class="overlay-post-content">
                                                                      <div class="post-content">

                                                                         <h3 class="post-title">
                                                                            <a href="http://vinkmag.xpeedstudio.com/sports/2018/01/11/plans-to-ride-out-hurricane-the-florence-on-a-boat-2/">
                                                                            Plans to ride out Hurricane the Florence on a boat            </a>
                                                                         </h3>
                                                                         <ul class="post-meta-info">
                                                                                                    <li>
                                                                               <i class="fa fa-clock-o"></i>January 11, 2018            </li>

                                                                                           <li class="active">
                                                                                  <i class="icon-fire"></i>
                                                                                  9               </li>

                                                                         </ul>
                                                                      </div>
                                                                   </div>
                                                                </div>
                                                            </div>					
                                                        </div>

                                                        <div class="tab-pane ts-overlay-style fade " id="nav-post-tab-2717f7c-31" role="tabpanel" aria-labelledby="nav-2717f7c-31-tab">
                                                                        <div class="ts-overlay-style featured-post post-3722 post type-post status-publish format-video hentry category-video post_format-post-format-video">
                                                                    <div class="item" style="background-image:url(http://vinkmag.xpeedstudio.com/sports/wp-content/themes/vinazine/assets/images/default_thumb.jpg)">
                                                                       <a class="img-link" href="http://vinkmag.xpeedstudio.com/sports/2018/01/14/theyre-back-kennedy-darlingnamed-to-return-to/"></a>
                                                                       <div class="overlay-post-content">
                                                                          <div class="post-content">

                                                                             <h3 class="post-title">
                                                                                <a href="http://vinkmag.xpeedstudio.com/sports/2018/01/14/theyre-back-kennedy-darlingnamed-to-return-to/">
                                                                                They’re back! Kennedy Darling,named to return to            </a>
                                                                             </h3>
                                                                             <ul class="post-meta-info">
                                                                                                        <li>
                                                                                   <i class="fa fa-clock-o"></i>January 14, 2018            </li>

                                                                                               <li class="active">
                                                                                      <i class="icon-fire"></i>
                                                                                      67               </li>

                                                                             </ul>
                                                                          </div>
                                                                       </div>
                                                                    </div>
                                                                    </div>					
                                                        </div>
                                                    </div>

                                                </div>


                                                <div class="col-lg-5">
                                                        <div class="nav post-list-box"   role="tablist">
                                                                                                        <a class="nav-item nav-link active" 
                                                                        id="nav-2717f7c-11-tab" 
                                                                        data-toggle="tab" 
                                                                        href="#nav-post-tab-2717f7c-11" role="tab" aria-controls="nav-post-tab-2717f7c-11"
                                                                        aria-selected="true">
                                                                                <div class="post-content media">
                                                                                <img 
                                                                                        class="d-flex" 
                                                                                        src="http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/health7-455x300.jpg" 
                                                                                        alt="Theye back return to you Kennedy Darlings">
                                                                                        <div class="media-body align-self-center">
                                                                                                <h4 class="post-title">

                                                                                                        Theye back return to you Kennedy Darlings								</h4>
                                                                                                <span class="post-date-info">
                                                                                                        <i class="fa fa-clock-o"></i>
                                                                                                        January 8, 2017								</span>
                                                                                        </div>
                                                                                </div>
                                                                        </a>
                                                                                                        <a class="nav-item nav-link " 
                                                                        id="nav-2717f7c-21-tab" 
                                                                        data-toggle="tab" 
                                                                        href="#nav-post-tab-2717f7c-21" role="tab" aria-controls="nav-post-tab-2717f7c-21"
                                                                        aria-selected="true">
                                                                                <div class="post-content media">
                                                                                <img 
                                                                                        class="d-flex" 
                                                                                        src="http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/health9-455x300.jpg" 
                                                                                        alt="Plans to ride out Hurricane the Florence on a boat">
                                                                                        <div class="media-body align-self-center">
                                                                                                <h4 class="post-title">

                                                                                                        Plans to ride out Hurricane the Florence on a boat								</h4>
                                                                                                <span class="post-date-info">
                                                                                                        <i class="fa fa-clock-o"></i>
                                                                                                        January 11, 2018								</span>
                                                                                        </div>
                                                                                </div>
                                                                        </a>
                                                                                                        <a class="nav-item nav-link " 
                                                                        id="nav-2717f7c-31-tab" 
                                                                        data-toggle="tab" 
                                                                        href="#nav-post-tab-2717f7c-31" role="tab" aria-controls="nav-post-tab-2717f7c-31"
                                                                        aria-selected="true">
                                                                                <div class="post-content media">
                                                                                <img 
                                                                                        class="d-flex" 
                                                                                        src="http://vinkmag.xpeedstudio.com/sports/wp-content/themes/vinazine/assets/images/default_thumb.jpg" 
                                                                                        alt="They’re back! Kennedy Darling,named to return to">
                                                                                        <div class="media-body align-self-center">
                                                                                                <h4 class="post-title">

                                                                                                        They’re back! Kennedy Darling,named to return to								</h4>
                                                                                                <span class="post-date-info">
                                                                                                        <i class="fa fa-clock-o"></i>
                                                                                                        January 14, 2018								</span>
                                                                                        </div>
                                                                                </div>
                                                                        </a>

                                                        </div>
                                                </div>

                                            </div>

                                        </div>

                                        <div role="tabpanel" class="tab-pane fade " id="tab-2717f7c2">
                                <div class="row">
                                        <div class="col-lg-7">
                                                <div class="tab-content featured-post"  >
                                                                                                <div class="tab-pane ts-overlay-style fade show active" id="nav-post-tab-2717f7c-12" role="tabpanel" aria-labelledby="nav-2717f7c-12-tab">
                                                                        <div class="ts-overlay-style featured-post post-190 post type-post status-publish format-standard has-post-thumbnail hentry category-cricket category-sketing category-sports tag-sports">
                        <div class="item" style="background-image:url(http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/sports1-600x398.jpg)">
                           <a class="img-link" href="http://vinkmag.xpeedstudio.com/sports/2018/01/07/plans-to-ride-out-hurricane-the-florence-on-a-boat/"></a>
                           <div class="overlay-post-content">
                              <div class="post-content">

                                 <h3 class="post-title">
                                    <a href="http://vinkmag.xpeedstudio.com/sports/2018/01/07/plans-to-ride-out-hurricane-the-florence-on-a-boat/">
                                    plans to ride out Hurricane the Florence on a boat            </a>
                                 </h3>
                                 <ul class="post-meta-info">
                                                            <li>
                                       <i class="fa fa-clock-o"></i>January 7, 2018            </li>

                                                   <li class="active">
                                          <i class="icon-fire"></i>
                                          68               </li>

                                 </ul>
                              </div>
                           </div>
                        </div>
                        </div>					</div>
                                                                                                <div class="tab-pane ts-overlay-style fade " id="nav-post-tab-2717f7c-22" role="tabpanel" aria-labelledby="nav-2717f7c-22-tab">
                                                                        <div class="ts-overlay-style featured-post post-4154 post type-post status-publish format-standard has-post-thumbnail hentry category-cricket category-football category-sports category-surfing">
                        <div class="item" style="background-image:url(http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/health7-600x398.jpg)">
                           <a class="img-link" href="http://vinkmag.xpeedstudio.com/sports/2018/03/01/marriott-has-new-rewards-offerings-and-you-dont-need/"></a>
                           <div class="overlay-post-content">
                              <div class="post-content">

                                 <h3 class="post-title">
                                    <a href="http://vinkmag.xpeedstudio.com/sports/2018/03/01/marriott-has-new-rewards-offerings-and-you-dont-need/">
                                    Marriott has new rewards offerings and you don&#8217;t need            </a>
                                 </h3>
                                 <ul class="post-meta-info">
                                                            <li>
                                       <i class="fa fa-clock-o"></i>March 1, 2018            </li>

                                                   <li class="active">
                                          <i class="icon-fire"></i>
                                          95               </li>

                                 </ul>
                              </div>
                           </div>
                        </div>
                        </div>					</div>
                                                                                                <div class="tab-pane ts-overlay-style fade " id="nav-post-tab-2717f7c-32" role="tabpanel" aria-labelledby="nav-2717f7c-32-tab">
                                                                        <div class="ts-overlay-style featured-post post-3718 post type-post status-publish format-standard has-post-thumbnail hentry category-cricket category-football category-sketing category-sports category-surfing tag-sports">
                        <div class="item" style="background-image:url(http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/sports3-600x398.jpg)">
                           <a class="img-link" href="http://vinkmag.xpeedstudio.com/sports/2018/04/08/the-clock-is-ticking-for-e-cig-companies-underage-users-2/"></a>
                           <div class="overlay-post-content">
                              <div class="post-content">

                                 <h3 class="post-title">
                                    <a href="http://vinkmag.xpeedstudio.com/sports/2018/04/08/the-clock-is-ticking-for-e-cig-companies-underage-users-2/">
                                    Clock is companies underage ticking for e-cig  users            </a>
                                 </h3>
                                 <ul class="post-meta-info">
                                                            <li>
                                       <i class="fa fa-clock-o"></i>April 8, 2018            </li>

                                                   <li class="active">
                                          <i class="icon-fire"></i>
                                          16               </li>

                                 </ul>
                              </div>
                           </div>
                        </div>
                        </div>					</div>
                                                                                </div>
                                        </div>
                                        <div class="col-lg-5">
                                                <div class="nav post-list-box"   role="tablist">
                                                                                                <a class="nav-item nav-link active" 
                                                                id="nav-2717f7c-12-tab" 
                                                                data-toggle="tab" 
                                                                href="#nav-post-tab-2717f7c-12" role="tab" aria-controls="nav-post-tab-2717f7c-12"
                                                                aria-selected="true">
                                                                        <div class="post-content media">
                                                                        <img 
                                                                                class="d-flex" 
                                                                                src="http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/sports1-455x300.jpg" 
                                                                                alt="plans to ride out Hurricane the Florence on a boat">
                                                                                <div class="media-body align-self-center">
                                                                                        <h4 class="post-title">

                                                                                                plans to ride out Hurricane the Florence on a boat								</h4>
                                                                                        <span class="post-date-info">
                                                                                                <i class="fa fa-clock-o"></i>
                                                                                                January 7, 2018								</span>
                                                                                </div>
                                                                        </div>
                                                                </a>
                                                                                                <a class="nav-item nav-link " 
                                                                id="nav-2717f7c-22-tab" 
                                                                data-toggle="tab" 
                                                                href="#nav-post-tab-2717f7c-22" role="tab" aria-controls="nav-post-tab-2717f7c-22"
                                                                aria-selected="true">
                                                                        <div class="post-content media">
                                                                        <img 
                                                                                class="d-flex" 
                                                                                src="http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/health7-455x300.jpg" 
                                                                                alt="Marriott has new rewards offerings and you don&#8217;t need">
                                                                                <div class="media-body align-self-center">
                                                                                        <h4 class="post-title">

                                                                                                Marriott has new rewards offerings and you don&#8217;t need								</h4>
                                                                                        <span class="post-date-info">
                                                                                                <i class="fa fa-clock-o"></i>
                                                                                                March 1, 2018								</span>
                                                                                </div>
                                                                        </div>
                                                                </a>
                                                                                                <a class="nav-item nav-link " 
                                                                id="nav-2717f7c-32-tab" 
                                                                data-toggle="tab" 
                                                                href="#nav-post-tab-2717f7c-32" role="tab" aria-controls="nav-post-tab-2717f7c-32"
                                                                aria-selected="true">
                                                                        <div class="post-content media">
                                                                        <img 
                                                                                class="d-flex" 
                                                                                src="http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/sports3-455x300.jpg" 
                                                                                alt="Clock is companies underage ticking for e-cig  users">
                                                                                <div class="media-body align-self-center">
                                                                                        <h4 class="post-title">

                                                                                                Clock is companies underage ticking for e-cig users								</h4>
                                                                                        <span class="post-date-info">
                                                                                                <i class="fa fa-clock-o"></i>
                                                                                                April 8, 2018								</span>
                                                                                </div>
                                                                        </div>
                                                                </a>
                                                                                </div>
                                        </div>
                                </div>
                                </div>

                                        <div role="tabpanel" class="tab-pane fade " id="tab-2717f7c3">
                                <div class="row">
                                        <div class="col-lg-7">
                                                <div class="tab-content featured-post"  >
                                                                                                <div class="tab-pane ts-overlay-style fade show active" id="nav-post-tab-2717f7c-13" role="tabpanel" aria-labelledby="nav-2717f7c-13-tab">
                                                                        <div class="ts-overlay-style featured-post post-4154 post type-post status-publish format-standard has-post-thumbnail hentry category-cricket category-football category-sports category-surfing">
                        <div class="item" style="background-image:url(http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/health7-600x398.jpg)">
                           <a class="img-link" href="http://vinkmag.xpeedstudio.com/sports/2018/03/01/marriott-has-new-rewards-offerings-and-you-dont-need/"></a>
                           <div class="overlay-post-content">
                              <div class="post-content">

                                 <h3 class="post-title">
                                    <a href="http://vinkmag.xpeedstudio.com/sports/2018/03/01/marriott-has-new-rewards-offerings-and-you-dont-need/">
                                    Marriott has new rewards offerings and you don&#8217;t need            </a>
                                 </h3>
                                 <ul class="post-meta-info">
                                                            <li>
                                       <i class="fa fa-clock-o"></i>March 1, 2018            </li>

                                                   <li class="active">
                                          <i class="icon-fire"></i>
                                          95               </li>

                                 </ul>
                              </div>
                           </div>
                        </div>
                        </div>					</div>
                                                                                                <div class="tab-pane ts-overlay-style fade " id="nav-post-tab-2717f7c-23" role="tabpanel" aria-labelledby="nav-2717f7c-23-tab">
                                                                        <div class="ts-overlay-style featured-post post-3718 post type-post status-publish format-standard has-post-thumbnail hentry category-cricket category-football category-sketing category-sports category-surfing tag-sports">
                        <div class="item" style="background-image:url(http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/sports3-600x398.jpg)">
                           <a class="img-link" href="http://vinkmag.xpeedstudio.com/sports/2018/04/08/the-clock-is-ticking-for-e-cig-companies-underage-users-2/"></a>
                           <div class="overlay-post-content">
                              <div class="post-content">

                                 <h3 class="post-title">
                                    <a href="http://vinkmag.xpeedstudio.com/sports/2018/04/08/the-clock-is-ticking-for-e-cig-companies-underage-users-2/">
                                    Clock is companies underage ticking for e-cig  users            </a>
                                 </h3>
                                 <ul class="post-meta-info">
                                                            <li>
                                       <i class="fa fa-clock-o"></i>April 8, 2018            </li>

                                                   <li class="active">
                                          <i class="icon-fire"></i>
                                          16               </li>

                                 </ul>
                              </div>
                           </div>
                        </div>
                        </div>					</div>
                                                                                                <div class="tab-pane ts-overlay-style fade " id="nav-post-tab-2717f7c-33" role="tabpanel" aria-labelledby="nav-2717f7c-33-tab">
                                                                        <div class="ts-overlay-style featured-post post-158 post type-post status-publish format-standard has-post-thumbnail hentry category-cricket category-football category-sketing category-sports category-surfing tag-sports">
                        <div class="item" style="background-image:url(http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/sports5-600x398.jpg)">
                           <a class="img-link" href="http://vinkmag.xpeedstudio.com/sports/2018/12/07/the-clock-is-ticking-for-e-cig-companies-underage-users/"></a>
                           <div class="overlay-post-content">
                              <div class="post-content">

                                 <h3 class="post-title">
                                    <a href="http://vinkmag.xpeedstudio.com/sports/2018/12/07/the-clock-is-ticking-for-e-cig-companies-underage-users/">
                                    The clock is ticking for e-cig companies underage users            </a>
                                 </h3>
                                 <ul class="post-meta-info">
                                                            <li>
                                       <i class="fa fa-clock-o"></i>December 7, 2018            </li>

                                                   <li class="active">
                                          <i class="icon-fire"></i>
                                          29               </li>

                                 </ul>
                              </div>
                           </div>
                        </div>
                        </div>					</div>
                                                                                </div>
                                        </div>
                                        <div class="col-lg-5">
                                                <div class="nav post-list-box"   role="tablist">
                                                                                                <a class="nav-item nav-link active" 
                                                                id="nav-2717f7c-13-tab" 
                                                                data-toggle="tab" 
                                                                href="#nav-post-tab-2717f7c-13" role="tab" aria-controls="nav-post-tab-2717f7c-13"
                                                                aria-selected="true">
                                                                        <div class="post-content media">
                                                                        <img 
                                                                                class="d-flex" 
                                                                                src="http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/health7-455x300.jpg" 
                                                                                alt="Marriott has new rewards offerings and you don&#8217;t need">
                                                                                <div class="media-body align-self-center">
                                                                                        <h4 class="post-title">

                                                                                                Marriott has new rewards offerings and you don&#8217;t need								</h4>
                                                                                        <span class="post-date-info">
                                                                                                <i class="fa fa-clock-o"></i>
                                                                                                March 1, 2018								</span>
                                                                                </div>
                                                                        </div>
                                                                </a>
                                                                                                <a class="nav-item nav-link " 
                                                                id="nav-2717f7c-23-tab" 
                                                                data-toggle="tab" 
                                                                href="#nav-post-tab-2717f7c-23" role="tab" aria-controls="nav-post-tab-2717f7c-23"
                                                                aria-selected="true">
                                                                        <div class="post-content media">
                                                                        <img 
                                                                                class="d-flex" 
                                                                                src="http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/sports3-455x300.jpg" 
                                                                                alt="Clock is companies underage ticking for e-cig  users">
                                                                                <div class="media-body align-self-center">
                                                                                        <h4 class="post-title">

                                                                                                Clock is companies underage ticking for e-cig users								</h4>
                                                                                        <span class="post-date-info">
                                                                                                <i class="fa fa-clock-o"></i>
                                                                                                April 8, 2018								</span>
                                                                                </div>
                                                                        </div>
                                                                </a>
                                                                                                <a class="nav-item nav-link " 
                                                                id="nav-2717f7c-33-tab" 
                                                                data-toggle="tab" 
                                                                href="#nav-post-tab-2717f7c-33" role="tab" aria-controls="nav-post-tab-2717f7c-33"
                                                                aria-selected="true">
                                                                        <div class="post-content media">
                                                                        <img 
                                                                                class="d-flex" 
                                                                                src="http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/sports5-455x300.jpg" 
                                                                                alt="The clock is ticking for e-cig companies underage users">
                                                                                <div class="media-body align-self-center">
                                                                                        <h4 class="post-title">

                                                                                                The clock is ticking for e-cig companies underage users								</h4>
                                                                                        <span class="post-date-info">
                                                                                                <i class="fa fa-clock-o"></i>
                                                                                                December 7, 2018								</span>
                                                                                </div>
                                                                        </div>
                                                                </a>
                                                                                </div>
                                        </div>
                                </div>
                                </div>

                                        <div role="tabpanel" class="tab-pane fade " id="tab-2717f7c4">
                                <div class="row">
                                        <div class="col-lg-7">
                                                <div class="tab-content featured-post"  >
                                                                                                <div class="tab-pane ts-overlay-style fade show active" id="nav-post-tab-2717f7c-14" role="tabpanel" aria-labelledby="nav-2717f7c-14-tab">
                                                                        <div class="ts-overlay-style featured-post post-190 post type-post status-publish format-standard has-post-thumbnail hentry category-cricket category-sketing category-sports tag-sports">
                        <div class="item" style="background-image:url(http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/sports1-600x398.jpg)">
                           <a class="img-link" href="http://vinkmag.xpeedstudio.com/sports/2018/01/07/plans-to-ride-out-hurricane-the-florence-on-a-boat/"></a>
                           <div class="overlay-post-content">
                              <div class="post-content">

                                 <h3 class="post-title">
                                    <a href="http://vinkmag.xpeedstudio.com/sports/2018/01/07/plans-to-ride-out-hurricane-the-florence-on-a-boat/">
                                    plans to ride out Hurricane the Florence on a boat            </a>
                                 </h3>
                                 <ul class="post-meta-info">
                                                            <li>
                                       <i class="fa fa-clock-o"></i>January 7, 2018            </li>

                                                   <li class="active">
                                          <i class="icon-fire"></i>
                                          68               </li>

                                 </ul>
                              </div>
                           </div>
                        </div>
                        </div>					</div>
                                                                                                <div class="tab-pane ts-overlay-style fade " id="nav-post-tab-2717f7c-24" role="tabpanel" aria-labelledby="nav-2717f7c-24-tab">
                                                                        <div class="ts-overlay-style featured-post post-4154 post type-post status-publish format-standard has-post-thumbnail hentry category-cricket category-football category-sports category-surfing">
                        <div class="item" style="background-image:url(http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/health7-600x398.jpg)">
                           <a class="img-link" href="http://vinkmag.xpeedstudio.com/sports/2018/03/01/marriott-has-new-rewards-offerings-and-you-dont-need/"></a>
                           <div class="overlay-post-content">
                              <div class="post-content">

                                 <h3 class="post-title">
                                    <a href="http://vinkmag.xpeedstudio.com/sports/2018/03/01/marriott-has-new-rewards-offerings-and-you-dont-need/">
                                    Marriott has new rewards offerings and you don&#8217;t need            </a>
                                 </h3>
                                 <ul class="post-meta-info">
                                                            <li>
                                       <i class="fa fa-clock-o"></i>March 1, 2018            </li>

                                                   <li class="active">
                                          <i class="icon-fire"></i>
                                          95               </li>

                                 </ul>
                              </div>
                           </div>
                        </div>
                        </div>					</div>
                                                                                                <div class="tab-pane ts-overlay-style fade " id="nav-post-tab-2717f7c-34" role="tabpanel" aria-labelledby="nav-2717f7c-34-tab">
                                                                        <div class="ts-overlay-style featured-post post-3718 post type-post status-publish format-standard has-post-thumbnail hentry category-cricket category-football category-sketing category-sports category-surfing tag-sports">
                        <div class="item" style="background-image:url(http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/sports3-600x398.jpg)">
                           <a class="img-link" href="http://vinkmag.xpeedstudio.com/sports/2018/04/08/the-clock-is-ticking-for-e-cig-companies-underage-users-2/"></a>
                           <div class="overlay-post-content">
                              <div class="post-content">

                                 <h3 class="post-title">
                                    <a href="http://vinkmag.xpeedstudio.com/sports/2018/04/08/the-clock-is-ticking-for-e-cig-companies-underage-users-2/">
                                    Clock is companies underage ticking for e-cig  users            </a>
                                 </h3>
                                 <ul class="post-meta-info">
                                                            <li>
                                       <i class="fa fa-clock-o"></i>April 8, 2018            </li>

                                                   <li class="active">
                                          <i class="icon-fire"></i>
                                          16               </li>

                                 </ul>
                              </div>
                           </div>
                        </div>
                        </div>					</div>
                                                                                </div>
                                        </div>
                                        <div class="col-lg-5">
                                                <div class="nav post-list-box"   role="tablist">
                                                                                                <a class="nav-item nav-link active" 
                                                                id="nav-2717f7c-14-tab" 
                                                                data-toggle="tab" 
                                                                href="#nav-post-tab-2717f7c-14" role="tab" aria-controls="nav-post-tab-2717f7c-14"
                                                                aria-selected="true">
                                                                        <div class="post-content media">
                                                                        <img 
                                                                                class="d-flex" 
                                                                                src="http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/sports1-455x300.jpg" 
                                                                                alt="plans to ride out Hurricane the Florence on a boat">
                                                                                <div class="media-body align-self-center">
                                                                                        <h4 class="post-title">

                                                                                                plans to ride out Hurricane the Florence on a boat								</h4>
                                                                                        <span class="post-date-info">
                                                                                                <i class="fa fa-clock-o"></i>
                                                                                                January 7, 2018								</span>
                                                                                </div>
                                                                        </div>
                                                                </a>
                                                                                                <a class="nav-item nav-link " 
                                                                id="nav-2717f7c-24-tab" 
                                                                data-toggle="tab" 
                                                                href="#nav-post-tab-2717f7c-24" role="tab" aria-controls="nav-post-tab-2717f7c-24"
                                                                aria-selected="true">
                                                                        <div class="post-content media">
                                                                        <img 
                                                                                class="d-flex" 
                                                                                src="http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/health7-455x300.jpg" 
                                                                                alt="Marriott has new rewards offerings and you don&#8217;t need">
                                                                                <div class="media-body align-self-center">
                                                                                        <h4 class="post-title">

                                                                                                Marriott has new rewards offerings and you don&#8217;t need								</h4>
                                                                                        <span class="post-date-info">
                                                                                                <i class="fa fa-clock-o"></i>
                                                                                                March 1, 2018								</span>
                                                                                </div>
                                                                        </div>
                                                                </a>
                                                                                                <a class="nav-item nav-link " 
                                                                id="nav-2717f7c-34-tab" 
                                                                data-toggle="tab" 
                                                                href="#nav-post-tab-2717f7c-34" role="tab" aria-controls="nav-post-tab-2717f7c-34"
                                                                aria-selected="true">
                                                                        <div class="post-content media">
                                                                        <img 
                                                                                class="d-flex" 
                                                                                src="http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/sports3-455x300.jpg" 
                                                                                alt="Clock is companies underage ticking for e-cig  users">
                                                                                <div class="media-body align-self-center">
                                                                                        <h4 class="post-title">

                                                                                                Clock is companies underage ticking for e-cig users								</h4>
                                                                                        <span class="post-date-info">
                                                                                                <i class="fa fa-clock-o"></i>
                                                                                                April 8, 2018								</span>
                                                                                </div>
                                                                        </div>
                                                                </a>
                                                                                </div>

                                        </div>
                                </div>
                                </div>
                                    </div>

                                </div>
                                
                                
                            </div>
			</div>
                                            
                                            
				<div data-id="8dd5c8d" class="elementor-element elementor-element-8dd5c8d elementor-hidden-tablet elementor-hidden-phone elementor-widget elementor-widget-image" data-element_type="image.default">
				<div class="elementor-widget-container">
					<div class="elementor-image">
										<img width="815" height="120" src="http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/banner_content.jpg" class="attachment-full size-full" alt="banner_content" srcset="http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/banner_content.jpg 815w, http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/banner_content-300x44.jpg 300w, http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/banner_content-768x113.jpg 768w" sizes="(max-width: 815px) 100vw, 815px" />											</div>
				</div>
				</div>
				
                                            
                                            
                                            
                                            
                                            <div data-id="9c7db1c" class="elementor-element elementor-element-9c7db1c elementor-widget elementor-widget-vinazine-block-title" data-element_type="vinazine-block-title.default">
				<div class="elementor-widget-container">
			    <div class="title-area">
        
      <h2 class="ts-title block-title-style1 float-left">
      <span class="title-before"></span>
      The Best of 2018      </h2>
                     <div class="clearfix"></div>
            
    </div>
    		</div>
				</div>
				<section data-id="89e0c6d" class="elementor-element elementor-element-89e0c6d elementor-section-boxed elementor-section-height-default elementor-section-height-default elementor-section elementor-inner-section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
				<div class="elementor-row">
				<div data-id="77caea7" class="elementor-element elementor-element-77caea7 elementor-column elementor-col-50 elementor-inner-column" data-element_type="column">
			<div class="elementor-column-wrap  elementor-element-populated">
					<div class="elementor-widget-wrap">
				<div data-id="dcfd67d" class="elementor-element elementor-element-dcfd67d elementor-widget elementor-widget-vinazine-post-grid" data-element_type="vinazine-post-grid.default">
				<div class="elementor-widget-container">
			        
                              <div class="grid-item grid-md ">
                                            <div class="ts-overlay-style featured-post post-190 post type-post status-publish format-standard has-post-thumbnail hentry category-cricket category-sketing category-sports tag-sports">
   <div class="item item-before" style="background-image:url(http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/sports1-600x398.jpg)">
      <div class="gradient-overlay"></div>
      <a class="img-link" href="http://vinkmag.xpeedstudio.com/sports/2018/01/07/plans-to-ride-out-hurricane-the-florence-on-a-boat/"></a>
      <div class="ts-post-thumb">
          
                        <a 
               class="post-cat" 
               href="http://vinkmag.xpeedstudio.com/sports/category/cricket/"
               style="color:#ffffff; background-color:#d72924; border-left-color:#d72924"
               >
               Cricket            </a>
               </div>
      <div class="overlay-post-content">
         <div class="post-content">
            <h3 class="post-title">
               <a href="http://vinkmag.xpeedstudio.com/sports/2018/01/07/plans-to-ride-out-hurricane-the-florence-on-a-boat/">
               plans to ride out Hurricane the Florence on a boat               </a>
            </h3>
            <ul class="post-meta-info">
                                             <li>
                  <i class="fa fa-clock-o"></i>January 7, 2018               </li>
               
                           </ul>
         </div>
      </div>
   </div>
</div>
                        
                    

                  </div>
                    


      		</div>
				</div>
						</div>
			</div>
		</div>
				<div data-id="3f4e049" class="elementor-element elementor-element-3f4e049 elementor-column elementor-col-50 elementor-inner-column" data-element_type="column">
			<div class="elementor-column-wrap  elementor-element-populated">
					<div class="elementor-widget-wrap">
				<div data-id="5d4782a" class="elementor-element elementor-element-5d4782a elementor-widget elementor-widget-vinazine-post-list" data-element_type="vinazine-post-list.default">
				<div class="elementor-widget-container">
			        
                                                    <div class="ts-grid-item-2  grid-no-shadow ">
                                                                                                            <div class="item grid-sm ">
                                            

		    <div class="ts-post-thumb">
        <a href="http://vinkmag.xpeedstudio.com/sports/2018/12/07/186/">
            <img 
                class="img-fluid" 
                src="http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/sports2-455x300.jpg" 
                alt="Youth vaping an epidemic with crackdown coming">
        </a>
    </div>
		<div class="post-content">
		
		<h3 class="post-title">
          <a href="http://vinkmag.xpeedstudio.com/sports/2018/12/07/186/">Youth vaping an epidemic with crackdown coming</a>		
      </h3>
		<ul class="post-meta-info">
									<li>
				<i class="fa fa-clock-o"></i>December 7, 2018			</li>
					</ul>
	</div>                                        </div>
                                                                                                                                                  <div class="item">
                                             <div class="post-content">
                                                <h4 class="post-title">
                                                      <a href="http://vinkmag.xpeedstudio.com/sports/2018/12/07/the-clock-is-ticking-for-e-cig-companies-underage-users/">  The clock is ticking for e-cig companies underage users</a>
                                                </h4>
                                                                                                   <span>
                                                      <i class="fa fa-clock-o"></i> December 7, 2018                                                   </span>
                                                                                              </div>
                                          </div>
                                                                                                                                                  <div class="item">
                                             <div class="post-content">
                                                <h4 class="post-title">
                                                      <a href="http://vinkmag.xpeedstudio.com/sports/2018/04/08/the-clock-is-ticking-for-e-cig-companies-underage-users-2/">  Clock is companies underage ticking for e-cig users</a>
                                                </h4>
                                                                                                   <span>
                                                      <i class="fa fa-clock-o"></i> April 8, 2018                                                   </span>
                                                                                              </div>
                                          </div>
                                                                                                </div>
                                      		</div>
				</div>
						</div>
			</div>
		</div>
						</div>
			</div>
		</section>
						</div>
			</div>
		</div>
				<div data-id="452b435" class="elementor-element elementor-element-452b435 elementor-column elementor-col-33 elementor-top-column" data-element_type="column">
			<div class="elementor-column-wrap  elementor-element-populated">
					<div class="elementor-widget-wrap">
				<div data-id="e9e5415" class="elementor-element elementor-element-e9e5415 elementor-widget elementor-widget-vinazine-block-title" data-element_type="vinazine-block-title.default">
				<div class="elementor-widget-container">
			    <div class="title-area">
        
      <h2 class="ts-title block-title-style1 float-left">
      <span class="title-before"></span>
      Follow Us      </h2>
                     <div class="clearfix"></div>
            
    </div>
    		</div>
				</div>
				<div data-id="d42071b" class="elementor-element elementor-element-d42071b elementor-widget elementor-widget-wp-widget-apsc_widget" data-element_type="wp-widget-apsc_widget.default">
				<div class="elementor-widget-container">
			<div class="apsc-icons-wrapper clearfix apsc-theme-2" >
                <div class="apsc-each-profile">
                                        <a  class="apsc-facebook-icon clearfix" href="https://facebook.com/xpeedstudio" target="_blank" >
                            <div class="apsc-inner-block">
                                <span class="social-icon"><i class="fa fa-facebook apsc-facebook"></i><span class="media-name">Facebook</span></span>
                                <span class="apsc-count">12K</span><span class="apsc-media-type">Fans</span>
                            </div>
                        </a>
                                        </div>            <div class="apsc-each-profile">
                                        <a  class="apsc-twitter-icon clearfix"  href="https://twitter.com/xpeedstudio" target="_blank"  >
                            <div class="apsc-inner-block">
                                <span class="social-icon"><i class="fa fa-twitter apsc-twitter"></i><span class="media-name">Twitter</span></span>
                                <span class="apsc-count">860</span><span class="apsc-media-type">Followers</span>
                            </div>
                        </a>
                                </div>            <div class="apsc-each-profile">
                                        <a  class="apsc-google-plus-icon clearfix" href="https://plus.google.com/111082030153424480495" target="_blank"  >
                            <div class="apsc-inner-block">
                                <span class="social-icon"><i class="apsc-googlePlus fa fa-google-plus"></i><span class="media-name">google+</span></span>
                                <span class="apsc-count">12</span><span class="apsc-media-type">Followers</span>
                            </div>
                        </a>
                                    </div>            
                                            
                                            <div class="apsc-each-profile">
                                                                <a  class="apsc-instagram-icon clearfix" href="https://instagram.com/xpeeder" target="_blank"   >
                                                    <div class="apsc-inner-block">
                                                        <span class="social-icon"><i class="apsc-instagram fa fa-instagram"></i><span class="media-name">Instagram</span></span>
                                                        <span class="apsc-count">64</span><span class="apsc-media-type">Followers</span>
                                                    </div>
                                                </a>
                                            </div>            
                                            
                                            <div class="apsc-each-profile">
                                                                <a class="apsc-youtube-icon clearfix" href="https://www.youtube.com/channel/UCJp-j8uvirVgez7TDAmfGYA" target="_blank"  >
                                                    <div class="apsc-inner-block">
                                                        <span class="social-icon"><i class="apsc-youtube fa fa-youtube"></i><span class="media-name">Youtube</span></span>
                                                        <span class="apsc-count">89</span><span class="apsc-media-type">Subscriber</span>
                                                    </div>
                                                </a>
                                            </div>            
                                            <div class="apsc-each-profile">
                                                                <a class="apsc-dribble-icon clearfix" href="https://dribbble.com/xpeedstudio" target="_blank" >
                                                    <div class="apsc-inner-block">
                                                        <span class="social-icon"><i class="apsc-dribbble fa fa-dribbble"></i><span class="media-name">dribble</span></span>
                                                        <span class="apsc-count">0</span><span class="apsc-media-type">Followers</span>
                                                    </div>
                                                </a>
                                                    
                                            </div>
                                        </div>

                                    </div>
				</div>
				
                                            
                                <div data-id="c472816" class="elementor-element elementor-element-c472816 elementor-widget elementor-widget-vinazine-post-list-tab" data-element_type="vinazine-post-list-tab.default">
                                    <div class="elementor-widget-container">
			        
     
                                        <div class="post-list-item widgets grid-no-shadow ">
                                            <ul class="nav nav-tabs" role="tablist">
                                                <li role="presentation">
                                                    <a class="active" href="#home" aria-controls="home" role="tab" data-toggle="tab">
                                                        <i class="fa fa-clock-o"></i>
                                                        RECENT                    </a>
                                                </li>
                                                <li role="presentation">
                                                    <a href="#profile" aria-controls="profile" role="tab" data-toggle="tab">
                                                        <i class="fa fa-heart"></i>
                                                        FAVORITES                    </a>
                                                </li>
                                            </ul>
            
            
                                            <div class="tab-content">
                                                <div role="tabpanel" class="tab-pane active ts-grid-box post-tab-list" id="home">
                                                    <div class="post-content media">    
                                                        <img 
                                                            class="d-flex sidebar-img" 
                                                            src="http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/gallery3-455x300.jpg" 
                                                            alt="Martavis Bryant Is Way Higher on Jon Gruden Than Gruden Is on Bryant">
                                                        <div class="media-body">
                                                            <span class="post-tag">
                                                                                            <a 
                                                                href="http://vinkmag.xpeedstudio.com/sports/category/video/"
                                                                style="color:#d72924"
                                                                >
                                                                Video                                </a>
                                                            </span>
                                                            <h4 class="post-title">
                                                            <a href="http://vinkmag.xpeedstudio.com/sports/2019/01/11/martavis-bryant-is-way-higher-on-jon-gruden-than-gruden-is-on-bryant/">Martavis Bryant Is Way...</a>
                                                            </h4>
                                                        </div>
                                                    </div>
                                    
                                                    <div class="post-content media">    
                                                        <img 
                                                            class="d-flex sidebar-img" 
                                                            src="http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/sports4-455x300.jpg" 
                                                            alt="Vontae Davis Quit on the Bills at Halftime, Changed into">
                                                        <div class="media-body">
                                                            <span class="post-tag">
                                                                                            <a 
                                                                href="http://vinkmag.xpeedstudio.com/sports/category/cricket/"
                                                                style="color:#d72924"
                                                                >
                                                                Cricket                                </a>
                                                            </span>
                                                            <h4 class="post-title">
                                                            <a href="http://vinkmag.xpeedstudio.com/sports/2019/01/05/vontae-davis-quit-on-the-bills-at-halftime-changed-into/">Vontae Davis Quit on...</a>
                                                            </h4>
                                                        </div>
                                                    </div>
                                    
                                                    <div class="post-content media">    
                                                        <img 
                                                            class="d-flex sidebar-img" 
                                                            src="http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/sports2-455x300.jpg" 
                                                            alt="Youth vaping an epidemic with crackdown coming">
                                                        <div class="media-body">
                                                            <span class="post-tag">
                                                                                            <a 
                                                                href="http://vinkmag.xpeedstudio.com/sports/category/cricket/"
                                                                style="color:#d72924"
                                                                >
                                                                Cricket                                </a>
                                                            </span>
                                                            <h4 class="post-title">
                                                            <a href="http://vinkmag.xpeedstudio.com/sports/2018/12/07/186/">Youth vaping an epidemic...</a>
                                                            </h4>
                                                        </div>
                                                    </div>
                                    
                                                    <div class="post-content media">    
                                                        <img 
                                                            class="d-flex sidebar-img" 
                                                            src="http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/sports4-455x300.jpg" 
                                                            alt="How did it go so wrong for Ferrari in Singapore?">
                                                        <div class="media-body">
                                                            <span class="post-tag">
                                                                                            <a 
                                                                href="http://vinkmag.xpeedstudio.com/sports/category/football/"
                                                                style="color:#e21e22"
                                                                >
                                                                Football                                </a>
                                                            </span>
                                                            <h4 class="post-title">
                                                            <a href="http://vinkmag.xpeedstudio.com/sports/2018/12/07/how-did-it-go-so-wrong-for-ferrari-in-singapore/">How did it go...</a>
                                                            </h4>
                                                        </div>
                                                    </div>
                                                    
                                                </div>
                
                                                <div role="tabpanel" class="tab-pane ts-grid-box post-tab-list" id="profile">
                                                    <div class="post-content media">    
                                                        <img 
                                                            class="d-flex sidebar-img" 
                                                            src="http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/health7-455x300.jpg" 
                                                            alt="Theye back return to you Kennedy Darlings">
                                                        <div class="media-body">
                                                            <span class="post-tag">
                                                                                                <a 
                                                                href="http://vinkmag.xpeedstudio.com/sports/category/video/"
                                                                style="color:#d72924"
                                                                >
                                                                Video                                    </a>
                                                            </span>
                                                            <h4 class="post-title">
                                                                <a href="http://vinkmag.xpeedstudio.com/sports/2017/01/08/theye-back-kennedy-darlings-return/">Theye back return to...</a>
                                                            </h4>
                                                        </div>
                                                    </div>
                    
                                                    <div class="post-content media">    
                                                        <img 
                                                            class="d-flex sidebar-img" 
                                                            src="http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/sports2-455x300.jpg" 
                                                            alt="Youth vaping an epidemic with crackdown coming">
                                                        <div class="media-body">
                                                            <span class="post-tag">
                                                                                                <a 
                                                                href="http://vinkmag.xpeedstudio.com/sports/category/cricket/"
                                                                style="color:#d72924"
                                                                >
                                                                Cricket                                    </a>
                                                            </span>
                                                            <h4 class="post-title">
                                                                <a href="http://vinkmag.xpeedstudio.com/sports/2018/12/07/186/">Youth vaping an epidemic...</a>
                                                            </h4>
                                                        </div>
                                                    </div>
                    
                                                    <div class="post-content media">    
                                                            <img 
                                                                class="d-flex sidebar-img" 
                                                                src="http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/featured3-455x300.png" 
                                                                alt="Bernard the only positive, Everton crumble all over">
                                                            <div class="media-body">
                                                                <span class="post-tag">
                                                                                                    <a 
                                                                    href="http://vinkmag.xpeedstudio.com/sports/category/feature/"
                                                                    style="color:#d72924"
                                                                    >
                                                                    Racing                                    </a>
                                                                </span>
                                                                <h4 class="post-title">
                                                                    <a href="http://vinkmag.xpeedstudio.com/sports/2018/01/04/bernard-the-only-positive-everton-crumble-all-over-the-pitch/">Bernard the only positive,...</a>
                                                                </h4>
                                                            </div>
                                                        </div>
                                                    
                                                        <div class="post-content media">    
                                                            <img 
                                                                class="d-flex sidebar-img" 
                                                                src="http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/gallery3-455x300.jpg" 
                                                                alt="Martavis Bryant Is Way Higher on Jon Gruden Than Gruden Is on Bryant">
                                                            <div class="media-body">
                                                                <span class="post-tag">
                                                                                                    <a 
                                                                    href="http://vinkmag.xpeedstudio.com/sports/category/video/"
                                                                    style="color:#d72924"
                                                                    >
                                                                    Video                                    </a>
                                                                </span>
                                                                <h4 class="post-title">
                                                                    <a href="http://vinkmag.xpeedstudio.com/sports/2019/01/11/martavis-bryant-is-way-higher-on-jon-gruden-than-gruden-is-on-bryant/">Martavis Bryant Is Way...</a>
                                                                </h4>
                                                            </div>
                                                     </div>
                                                            
                                                </div>
                
                                            </div>
                                        </div>
        


                                    </div>
				</div>
                                            
				<div data-id="d109220" class="elementor-element elementor-element-d109220 elementor-widget elementor-widget-vinazine-category-list" data-element_type="vinazine-category-list.default">
                                    <div class="elementor-widget-container">
                                        <div class="ts-grid-box widgets category-list-item  grid-no-shadow">

                                                    <h2 class="ts-title block-title-style1 float-left">
                                                    <span class="title-before"></span>
                                                    Topics      </h2>
                                                    <div class="clearfix"></div>

                                                <ul class="category-list">
                                                                            <li><a href="http://vinkmag.xpeedstudio.com/sports/category/surfing/">Surfing<span style="color:#ffffff; background-color:#d72924; border-left-color:#d72924">4</span></a></li>                        <li><a href="http://vinkmag.xpeedstudio.com/sports/category/sports/">Sports<span style="color:#ffffff; background-color:#d72924; border-left-color:#d72924">7</span></a></li>                        <li><a href="http://vinkmag.xpeedstudio.com/sports/category/sketing/">Sketing<span style="color:#ffffff; background-color:#d72924; border-left-color:#d72924">6</span></a></li>                        <li><a href="http://vinkmag.xpeedstudio.com/sports/category/football/">Football<span style="color:#ffffff; background-color:#e21e22; border-left-color:#e21e22">5</span></a></li>                        <li><a href="http://vinkmag.xpeedstudio.com/sports/category/cricket/">Cricket<span style="color:#ffffff; background-color:#d72924; border-left-color:#d72924">6</span></a></li>                </ul>
                                            </div>

                                    </div>
				</div>
                                            
                                            
                                            
				<div data-id="efe3e3f" class="elementor-element elementor-element-efe3e3f elementor-hidden-tablet elementor-hidden-phone elementor-widget elementor-widget-image" data-element_type="image.default">
				<div class="elementor-widget-container">
					<div class="elementor-image">
										<img width="255" height="280" src="http://vinkmag.xpeedstudio.com/sports/wp-content/uploads/sites/8/2018/10/sidebar-banner1.jpg" class="attachment-large size-large" alt="" />											</div>
				</div>
				</div>
                                            
			</div>
                </div>
		
                                
            </div>

        </div>

    </div>
    
</section>